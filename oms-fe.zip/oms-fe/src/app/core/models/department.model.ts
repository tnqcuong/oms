export class Department{
    Id : number = 0;
    Name : string = '';
    Description: string = '';
}
