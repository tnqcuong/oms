import { BankTransaction } from "./bank-transaction.model";
import { LMSTransaction } from "./lms-transaction.model";

export class MatchingTransaction {
  bankStatemenTrxInfo: BankTransaction = new BankTransaction();
  lmsTrxInfo: LMSTransaction = new LMSTransaction();
}

