export class LMSTransaction {
  id: number = 0;
  refNo: string = '';
  bankCode: string = '';
  trxDt: string = '';
  valueDt: string = '';
  cif: string = '';
  paymode: string = '';
  drAmt: number = 0;
  crAmt: number = 0;
  loanNo: string = '';
  statusCode: number = 0;
  subStatusCode: number = 0;
  remark: string = '';
  remarkNote: string = '';
  selected?:boolean = false;
}
