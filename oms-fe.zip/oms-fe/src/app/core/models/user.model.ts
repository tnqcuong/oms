export class User {
    constructor() {
        this.userId = null || 0;
        this.userName = null || '';
        this.password = null || '';
        this.emailId = null || '';
        this.birthDate = null|| new Date;
        this.token = null || '';
    }

    userId: number;
    userName: string;
    password: string;
    emailId: string;
    birthDate: Date;
    token: string;
}
