export interface SearchType {
  searchKey: String;
  searchValue: String;
}
