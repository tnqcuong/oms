export class searchSelect {
  id?: string;
  value?: string;
}
