import { Injectable } from '@angular/core';
import { User } from 'src/app/core/models/user.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { SessionService } from 'src/app/core/services/session.service';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
/**
 * user service class
 */
export class UserDataService {
  users: User[] = [];
  dataToken = '';
  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {
    let user = {
      userId: 1,
      userName: 'admin',
      password: 'admin',
      emailId: 'admin@admin.com',
      birthDate: new Date('10/28/1992'),
      token: '',
    };
  }

  /**
   * get user by user name and password
   * @param userName
   * @param password
   */
  getUserByUserNameAndPassword(
    userName: string,
    password: string
  ): Observable<any> {
    const user: User = {
      userName: '',
      password: '',
      emailId: '',
      birthDate: new Date(),
      token: '',
      userId: 0,
    };
    const DataUser = {
      userName: userName,
      password: password,
    };
    const body = JSON.stringify(DataUser);
    return this.http.post<any>(
      environment.apiUrl_Auto + environmentAPI.login,
      body
    );
  }
}
