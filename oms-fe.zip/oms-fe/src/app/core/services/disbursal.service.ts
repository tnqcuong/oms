import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { SessionService } from 'src/app/core/services/session.service';

@Injectable({
  providedIn: 'root',
})
export class DisbursalService {
  user = this.sessionService.getItem('currentUser');

  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {}

  getHeaderParams() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'access-token': this.user.token,
    });
  }

  getDisbTransactionMatching(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl + environmentAPI.disbursalMatchingTrx,
      {
        headers: headers,
        params: params,
      }
    );
  }

  getDisbTransactionPendingBank(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl + environmentAPI.disbursalUnMatchingTrx,
      {
        headers: headers,
        params: params,
      }
    );
  }

  getDisbTransactionPendingLMS(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      {
        headers: headers,
        params: params,
      }
    );
  }

  getPartnerCommonInfo(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    return this.http.get(
      environment.apiUrl + environmentAPI.partnerCommonInfo,
      {
        headers: headers,
        params: params,
      }
    );
  }

  PostRetryBank(params_bankCode: any): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI.reTry,
      {},
      {
        headers: headers,
        params: params,
      }
    );
  }

  downloadFile(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI.report,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  getMatchingTransaction(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.disbursalMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getDisbUnMatchingTransactionForBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.disbursalUnMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getUnMatchingTransactionForLMS(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      { headers: headerParams, params: params }
    );
  }

  updateMatchingTrxStatus(
    isUnMatch: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_isUnmatch', isUnMatch);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.disbursalMatchingTrx,
      body,
      { headers: headerParams, params: params }
    );
  }

  updateUnMatchingTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.disbursalUnMatchingTrx,
      body,
      { headers: headerParams }
    );
  }

  updateUnMatchingLMSTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      body,
      { headers: headerParams }
    );
  }
}
