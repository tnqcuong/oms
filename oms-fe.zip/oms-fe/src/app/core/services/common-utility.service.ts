import { Injectable } from '@angular/core';
import { MetaData } from '../models/meta-data.model';
import { SearchType } from '../models/searchType.model';

@Injectable({
  providedIn: 'root',
})
export class CommonUtilityService {
  bankList: MetaData[] = [];
  bankDisbList: MetaData[] = [];
  bankTrxStatusList: MetaData[] = [];
  lmsTrxStatusList: MetaData[] = [];
  nonBankTrxStatusList: MetaData[] = [];
  nonLmsTrxStatusList: MetaData[] = [];
  disbBankTrxStatusList: MetaData[] = [];
  disbLmsTrxStatusList: MetaData[] = [];
  uploadFileStatusList: MetaData[] = [];
  searchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_payMode', searchValue: 'Payment Mode' },
    { searchKey: '_des', searchValue: 'Description' },
  ];

  disbMatchingSearchType: SearchType[] = [
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_des', searchValue: 'Description' },
  ];

  bankSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_des', searchValue: 'Description' },
  ];

  lmsSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_payMode', searchValue: 'Payment Mode' },
    { searchKey: '_des', searchValue: 'Description' },
  ];


  constructor() {}

  isEmptyObj(obj : object) {
    for(let prop in obj) {
      if(obj.hasOwnProperty(prop)) {
        return false;
      }
    }
    return JSON.stringify(obj) === JSON.stringify({});
  }

}
