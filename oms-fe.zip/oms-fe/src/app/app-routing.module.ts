import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './layout/error/error.component';
import { LayoutComponent } from './layout/layout.component';
import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'main',
    component: LayoutComponent,
    children: [
      {
        path: 'dashboard',
        loadChildren: () =>
          import('src/app/features/dashboard/dashboard.module').then(
            (m) => m.DashboardModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 'reconciliation',
        loadChildren: () =>
          import('src/app/features/reconciliation/reconciliation.module').then(
            (m) => m.ReconciliationModule
          ),
        canActivate: [AuthGuard],
        // data: {roles: [Role.]}
      },
      {
        path: 'auto-debit',
        loadChildren: () =>
          import('src/app/features/auto-debit/auto-debit.module').then(
            (m) => m.ReconciliationListModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 'forceclause',
        loadChildren: () =>
          import('src/app/features/forceclause/forceclause.module').then(
            (m) => m.ForceclauseListModule
          ),
        canActivate: [AuthGuard],
      },
    ],
  },
  {
    path: 'login',
    loadChildren: () =>
      import('src/app/features/login/login.module').then((m) => m.LoginModule),
  },
  {
    path: '**',
    redirectTo: 'error',
  },
  {
    path: 'error',
    component: ErrorComponent,
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      anchorScrolling: 'enabled',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
