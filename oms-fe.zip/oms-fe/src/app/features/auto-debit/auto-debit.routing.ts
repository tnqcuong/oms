import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutoDebitComponent } from './auto-debit.component';

const routes: Routes = [
  {
    path: 'list',
    component: AutoDebitComponent,
  },
  {
    path: 'registrantion',
    loadChildren: () =>
      import(
        'src/app/features/auto-debit/auto-debit-resistrantion/auto-debit-resistrantion.module'
      ).then((m) => m.AutoDebitRegistrantionModule),
  },
  {
    path: 'formAndHard',
    loadChildren: () =>
      import(
        'src/app/features/auto-debit/auto-debit-form-and-hard/auto-debit-form-and-hard.module'
      ).then((m) => m.AutoDebitFormAndHardModule),
  },
  {
    path: 'formAndReceived',
    loadChildren: () =>
      import(
        'src/app/features/auto-debit/auto-debit-form-and-received/auto-debit-form-and-received.module'
      ).then((m) => m.AutoDebitFormAndReceivedModule),
  },
  {
    path: 'resultsAtBank',
    loadChildren: () =>
      import(
        'src/app/features/auto-debit/auto-debit-results-bank/auto-debit-results-bank.module'
      ).then((m) => m.AutoDebitRegistrantionModule),
  },
  {
    path: 'smsSendingList',
    loadChildren: () =>
      import(
        'src/app/features/auto-debit/auto-debit-sms-sending-list/auto-debit-sms-sending-list.module'
      ).then((m) => m.AutoDebitSmsModule),
  },
  {
    path: 'report',
    loadChildren: () =>
      import(
        'src/app/features/auto-debit/auto-debit-report/auto-debit-report.module'
      ).then((m) => m.AutoDebitReportModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AutoDebitListRoutingModule {}
