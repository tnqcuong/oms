import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoDebitFormAndHardComponent } from './auto-debit-form-and-hard.component';
import { AutoDebitFormAndHardRoutingModule } from './auto-debit-form-and-hard.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
  imports: [
    CommonModule,
    AutoDebitFormAndHardRoutingModule,
    AppCommonModule,
    NgxPaginationModule
  ],
  declarations: [AutoDebitFormAndHardComponent],
})
export class AutoDebitFormAndHardModule {}
