import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoDebitReportComponent } from './auto-debit-report.component';
import { AutoDebitReportRoutingModule } from './auto-debit-report.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    AutoDebitReportRoutingModule,
    AppCommonModule,
    NgxPaginationModule,
  ],
  declarations: [
    AutoDebitReportComponent,
  ],
})
export class AutoDebitReportModule {}
