import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutoDebitReportComponent } from './auto-debit-report.component';

const routes: Routes = [
  {
    path: '',
    component: AutoDebitReportComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AutoDebitReportRoutingModule {}
