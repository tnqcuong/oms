import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoDebitResultsBankComponent } from './auto-debit-results-bank.component';
import { AutoDeBitResultsRoutingModule } from './auto-debit-results-bank.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    AutoDeBitResultsRoutingModule,
    AppCommonModule,
    NgxPaginationModule,
  ],
  declarations: [AutoDebitResultsBankComponent],

})
export class AutoDebitRegistrantionModule {}
