import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitResultsBankComponent } from './auto-debit-results-bank.component';

describe('AutoDebitResultsBankComponent', () => {
  let component: AutoDebitResultsBankComponent;
  let fixture: ComponentFixture<AutoDebitResultsBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitResultsBankComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitResultsBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
