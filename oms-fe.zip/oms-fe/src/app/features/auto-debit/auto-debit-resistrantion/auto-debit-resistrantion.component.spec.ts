import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitResistrantionComponent } from './auto-debit-resistrantion.component';

describe('AutoDebitResistrantionComponent', () => {
  let component: AutoDebitResistrantionComponent;
  let fixture: ComponentFixture<AutoDebitResistrantionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitResistrantionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitResistrantionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
