import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { AutoDebitComponent } from 'src/app/features/auto-debit/auto-debit.component';
import { AutoDebitListRoutingModule } from 'src/app/features/auto-debit/auto-debit.routing';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    AutoDebitListRoutingModule,
    HeaderBreadCrumbModule,
  ],
  declarations: [AutoDebitComponent],
})
export class ReconciliationListModule {}
