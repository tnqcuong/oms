import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';
import { ExcelService } from 'src/app/core/services/excel.service';
import {
  GetSMS,
  searchRegistrantion,
  RegistrantionList,
  GetRegistrxReceivedHard,
  GetPushRegistrx,
} from 'src/app/core/models/Auto-debit.model';
import { AutoDeBitService } from 'src/app/features/auto-debit/auto-debit.service';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { LoaderService } from 'src/app/core/services/loader.service';
import { RouteStateService } from 'src/app//core/services/route-state.service';
@Component({
  selector: 'app-auto-debit-sms-sending-list',
  templateUrl: './auto-debit-sms-sending-list.component.html',
  styleUrls: ['./auto-debit-sms-sending-list.component.sass'],
  providers: [ConfirmationService],
})
export class AutoDebitSmsSendingListComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: any;
  _lookupCodeId = '';

  _valueSrech = '';

  _arrBank: MetaData[] = [];

  dateValue: Date = new Date();

  _startOf = moment(this.dateValue).startOf('month').format('DD/MM/YYYY');

  _endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');

  _arrGetSMS: GetSMS[] = [];
  _countGetSMS = 0;
  loading: boolean = false;
  _pageGetSMS = 1;
  _tableSizeGetSMS = 50;

  _lookupCodeId_SMS = '';
  _lookupCodeId_SendSMS = '';
  _valueSrech_SMS = '';
  _firstDueDt = new Date();

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _listsearchRegistrantion: searchRegistrantion[] = [
    {
      id: '_branch',
      value: 'BRANCH',
    },
    {
      id: '_roUser',
      value: 'RO USER',
    },
    {
      id: '_bank',
      value: 'BANK',
    },
  ];
  _listsearCheckSendSMS: searchRegistrantion[] = [
    {
      id: 'Y',
      value: 'Sent SMS',
    },
    {
      id: 'N',
      value: 'No Sent SMS',
    },
  ];

  _arrRegistrantionList: RegistrantionList[] = [];
  _countRegistrantionList = 0;
  _pageRegistrantionList = 1;
  _tableSizeRegistrantionList = 50;
  _firstDueDt_Registrantion: Date = new Date();
  _loadingRegistrantionSMS: boolean = false;

  _AD_TYPE = '';
  _doc36 = '';

  _endDt = new Date(moment(this.DayNow).endOf('month').format('MM/DD/YYYY'));
  _startDt = new Date(
    moment(this.DayNow).startOf('month').format('MM/DD/YYYY')
  );

  dateDialog: boolean = false;

  submitted: boolean = false;

  _arrGetRegistrxSMS: GetRegistrxReceivedHard[] = [];
  _countGetRegistrxSMS = 0;
  _pageGetRegistrxSMS = 1;
  _tableSizeGetRegistrxSMS = 50;
  _statusMap = 4;
  _loadingSMS: boolean = false;

  _startOfResult = new Date(
    moment(this.DayNow).startOf('month').format('MM/DD/YYYY')
  );
  _endOfResult = new Date(
    moment(this.DayNow).endOf('month').format('MM/DD/YYYY')
  );

  _endBankResultDt = new Date();
  _startBankResultDt = new Date(
    this._endBankResultDt.getFullYear(),
    this._endBankResultDt.getMonth(),
    1
  );
  _lookupCodeId_Result_SMS = '';
  _valueSrech_Result_SMS = '';
  _listsearchBankResult: searchRegistrantion[] = [
    {
      //   id: '_receiveUser',
      //   value: 'RECEIVED USER',
      // },
      // {
      //   id: '_bank',
      //   value: 'BANK',
    },
  ];
  _loadingSMSResultBanks: boolean = false;

  _checkedAll_RegistrantionList = false;

  _pushArr_RegistrantionList: GetPushRegistrx[] = [];

  _checkedAll_arrGetSMS = false;

  _pushArr_arrGetSMS: GetPushRegistrx[] = [];

  _checkedAll_RegistrxSMS = false;

  _pushArr_RegistrxSMS: GetPushRegistrx[] = [];

  startIndex: number = 0;
  endIndex: number = 0;

  constructor(
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private autosev: AutoDeBitService,
    private exclesev: ExcelService,
    private loaderService: LoaderService,
    private routeStateService: RouteStateService
  ) {}

  ngOnInit(): void {
    this.fetchGetUnregistrx();
    this.fetchGetSmsNoRegis();
    this.fetchGetRegistrxSMS();
  }

  fetchGetUnregistrx() {
    this.loaderService.onLoading();
    this.autosev
      .GetUnregistrx(
        this._lookupCodeId,
        this._valueSrech,

        this._AD_TYPE,
        this._doc36,

        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),

        this._tableSizeRegistrantionList,
        this._pageRegistrantionList,
        moment(this._firstDueDt_Registrantion).format('DD/MM/YYYY')
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this._arrRegistrantionList = [];
            this._loadingRegistrantionSMS = false;
            this.loaderService.offLoading();
          } else {
            this._arrRegistrantionList = [];
            this._arrRegistrantionList = data?.result?.data;
            this._countRegistrantionList = data?.result?.count;
            this._loadingRegistrantionSMS = true;
            this.loaderService.offLoading();
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Registrantion List',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'No Data Registrantion List'
          );
          this.loaderService.offLoading();
        }
      );
  }
  fetchGetSmsNoRegis() {
    this.loaderService.onLoading();
    this.autosev
      .fetchGetSmsNoRegis(
        this._lookupCodeId_SMS,
        this._valueSrech_SMS,

        moment(this._firstDueDt).format('DD/MM/YYYY'),
        this._lookupCodeId_SendSMS,
        this._tableSizeGetSMS,
        this._pageGetSMS
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this._arrGetSMS = [];
            this._loadingSMS = false;
            this.loaderService.offLoading();
          } else {
            this._arrGetSMS = data?.result?.data;
            this._countGetSMS = data?.result?.count;
            this._loadingSMS = true;
            this.loaderService.offLoading();
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'SMS',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'SMS NO DATA'
          );
          this.loaderService.offLoading();
        }
      );
  }
  fetchGetRegistrxSMS() {
    this.loaderService.onLoading();
    this.autosev
      .GetRegistrxReceivedBank(
        this._lookupCodeId_Result_SMS,
        this._valueSrech_Result_SMS,

        moment(this._startOfResult).format('DD/MM/YYYY'),
        moment(this._endOfResult).format('DD/MM/YYYY'),

        this._statusMap,

        moment(this._startBankResultDt).format('DD/MM/YYYY'),
        moment(this._endBankResultDt).format('DD/MM/YYYY'),

        this._tableSizeGetRegistrxSMS,
        this._pageGetRegistrxSMS
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this._arrGetRegistrxSMS = [];
            this._loadingSMSResultBanks = false;
            this.loaderService.offLoading();
          } else {
            this._arrGetRegistrxSMS = [];
            this._arrGetRegistrxSMS = data?.result?.data;
            this._countGetRegistrxSMS = data?.result?.count;
            this._loadingSMSResultBanks = true;
            this.loaderService.offLoading();
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Registrantion List',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'No Data SMS List'
          );
          this.loaderService.offLoading();
        }
      );
  }

  onPageChangeTable(event: any) {
    this._pageRegistrantionList = event;
    this.fetchGetUnregistrx();
  }
  onPageChangeTableSMS(event: any) {
    this._pageGetSMS = event;
    this.fetchGetSmsNoRegis();
  }
  onPageChangeTableSMSResultBank(event: any) {
    this._pageGetRegistrxSMS = event;
    this.fetchGetRegistrxSMS();
  }

  getDataSearchSMS() {
    this._pageGetSMS = 1;
    this.fetchGetSmsNoRegis();
  }
  getDataSearchResultBankSMS() {
    this._pageGetRegistrxSMS = 1;
    this.fetchGetRegistrxSMS();
  }
  getDataSearchGetUnregistrxSMS() {
    this._pageRegistrantionList = 1;
    this.fetchGetUnregistrx();
  }

  onChangeSendSMS() {
    this._pageGetSMS = 1;
    this.fetchGetSmsNoRegis();
  }

  confirmUnregistrxSMS() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed Excel Regis?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.ExportUnregistrx();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  confirmSMS() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed Sms?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.Export();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }

  ExportSMSResultBank() {
    // call api
    this.loaderService.onLoading();
    this.autosev
      .downloadFileAPI_Result_Bank_SMS(
        this._lookupCodeId_Result_SMS,
        this._valueSrech_Result_SMS,

        moment(this._startOfResult).format('DD/MM/YYYY'),
        moment(this._endOfResult).format('DD/MM/YYYY'),

        this._statusMap,

        moment(this._startBankResultDt).format('DD/MM/YYYY'),
        moment(this._endBankResultDt).format('DD/MM/YYYY')
      )
      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'export_StatusMap4',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.toastService.addSingle(
            'success',
            'Export',
            'Success Export File'
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          var actual = JSON.parse(atob(base64String));

          this.toastService.addSingle(
            'error',
            'Export',
            actual.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }
  ExportUnregistrx() {
    // call api
    this.loaderService.onLoading();
    this.autosev
      .downloadFileAPI_Registration(
        this._lookupCodeId,
        this._valueSrech,

        this._AD_TYPE,
        this._doc36,
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        moment(this._firstDueDt_Registrantion).format('DD/MM/YYYY')
      )
      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'export_registration_SMS',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.toastService.addSingle(
            'success',
            'Export',
            'Success Export File'
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          var actual = JSON.parse(atob(base64String));

          this.toastService.addSingle(
            'error',
            'Export',
            actual.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.autosev
      .downloadFileAPI_SmsNoRegis(
        this._lookupCodeId_SMS,
        this._valueSrech_SMS,

        moment(this._firstDueDt).format('DD/MM/YYYY'),
        this._lookupCodeId_SendSMS
      )
      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'export_Sms_Send_List',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.toastService.addSingle(
            'success',
            'Export',
            'Success Export File'
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          var actual = JSON.parse(atob(base64String));

          this.toastService.addSingle(
            'error',
            'Export',
            actual.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }

  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }

  RegisterforAutoDebit() {
    this.fetchGetRegistrxSMS();
  }

  toggleVisibility_RegistrantionList(
    event: any,
    row_RegistrantionList: any,
    i: any
  ) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrRegistrantionList[i].checked = true;
        }
      } else {
        this._arrRegistrantionList.forEach((trx) => {
          if (trx.loanNo === row_RegistrantionList.loanNo) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrRegistrantionList.forEach((trx) => {
        if (trx.loanNo === row_RegistrantionList.loanNo) {
          trx.checked = false;
        }
      });
    }
  }
  toggleAll_RegistrantionList(event: any) {
    this._checkedAll_RegistrantionList = event.target.checked;
    const checked = event.target.checked;
    this._arrRegistrantionList.map((item: any) => {
      item.checked = checked;
    });
  }
  SubmitDataSend_RegistrantionList() {
    this._pushArr_RegistrantionList = [];
    let action = 0;
    this._arrRegistrantionList.map((item: any) => {
      if (item.checked == true) {
        const data = {
          loanNo: item.loanNo,
        };
        this._pushArr_RegistrantionList.push(data);
        action = 1;
      }
    });
    this.loaderService.onLoading();
    if (action == 1) {
      this.autosev
        .PostSmsRegistration_List(this._pushArr_RegistrantionList)
        .subscribe(
          (data) => {
            this._pageGetSMS = 1;
            this._pageRegistrantionList = 1;
            this.fetchGetUnregistrx();
            this.fetchGetSmsNoRegis();
            this.toastService.addSingle('success', 'Submit', 'Success Record');
            this.loaderService.offLoading();
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Submit',
              error.error.exceptionMessage
                ? error.error.exceptionMessage
                : 'Error Record'
            );
            this.loaderService.offLoading();
          }
        );
    } else {
      this.toastService.addSingle('error', 'Submit', 'Change Record');
      this.loaderService.offLoading();
    }
    this._checkedAll_RegistrantionList = false;
  }

  // GetSMS
  toggleVisibility_arrGetSMS(event: any, row_GetSMSList: any, i: any) {
    // let row = row_GetSMSList;
    // if (event.target.checked == true) {
    //   row.checked = event.target.checked;
    // } else {
    //   row.checked = event.target.checked;
    // }
    const checked = event.target.checked;
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrGetSMS[i].checked = true;
          if (this._arrGetSMS[i]?.smsDueDt) {
            this._arrGetSMS[i].checked = false;
          }
        }
      } else {
        this._arrGetSMS.forEach((trx) => {
          if (trx.loanNo === row_GetSMSList.loanNo) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrGetSMS.forEach((trx) => {
        if (trx.loanNo === row_GetSMSList.loanNo) {
          trx.checked = false;
        }
      });
    }
  }
  toggleAll_GetSMS(event: any) {
    this._checkedAll_arrGetSMS = event.target.checked;
    const checked = event.target.checked;
    this._arrGetSMS.map((item: any) => {
      if (!item?.smsDueDt) {
        if (!item?.smsDueDtStatus) {
          item.checked = checked;
        }
      }
    });
  }
  SubmitDataSend_GetSMS() {
    this._pushArr_arrGetSMS = [];
    let action = 0;
    this._arrGetSMS.map((item: any) => {
      if (item.checked == true) {
        const data = {
          loanNo: item.loanNo,
        };
        this._pushArr_arrGetSMS.push(data);
        action = 1;
      }
    });
    this.loaderService.onLoading();
    if (action == 1) {
      this.autosev.PostSendSmsList(this._pushArr_arrGetSMS, '').subscribe(
        (data) => {
          this._pageRegistrantionList = 1;
          this._pageGetSMS = 1;
          this.fetchGetUnregistrx();
          this.fetchGetSmsNoRegis();
          this.toastService.addSingle('success', 'Submit', 'Success Record');
          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Submit',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error Record'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.toastService.addSingle('error', 'Submit', 'Change Record');
      this.loaderService.offLoading();
    }
    this._checkedAll_arrGetSMS = false;
  }
  // GetRegistrxSMS
  toggleVisibility_GetRegistrxSMS(event: any, row_GetRegistrxSMS: any, i: any) {
    // let row = row_GetRegistrxSMS;
    // if (event.target.checked == true) {
    //   row.checked = event.target.checked;
    // } else {
    //   row.checked = event.target.checked;
    // }
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrGetRegistrxSMS[i].checked = true;
          if (this._arrGetRegistrxSMS[i]?.smsADDt) {
            this._arrGetRegistrxSMS[i].checked = false;
          }
        }
      } else {
        this._arrGetRegistrxSMS.forEach((trx) => {
          if (trx.loanNo === row_GetRegistrxSMS.loanNo) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrGetRegistrxSMS.forEach((trx) => {
        if (trx.loanNo === row_GetRegistrxSMS.loanNo) {
          trx.checked = false;
        }
      });
    }
  }
  toggleAll_RegistrxSMS(event: any) {
    this._checkedAll_RegistrxSMS = event.target.checked;
    const checked = event.target.checked;
    this._arrGetRegistrxSMS.map((item: any) => {
      if (!item?.smsADDt) {
        if(!item?.smsADDtStatus)
        {
          item.checked = checked;
        }
      }
    });
  }
  SubmitDataSend_RegistrxSMS() {
    this._pushArr_RegistrxSMS = [];
    let action = 0;
    this._arrGetRegistrxSMS.map((item: any) => {
      if (item.checked == true) {
        const data = {
          loanNo: item.loanNo,
        };
        this._pushArr_RegistrxSMS.push(data);
        action = 1;
      }
    });
    this.loaderService.onLoading();
    if (action == 1) {
      this.autosev
        .PostSendSmsList(this._pushArr_RegistrxSMS, this._statusMap)
        .subscribe(
          (data) => {
            this._pageGetRegistrxSMS = 1;
            this.fetchGetRegistrxSMS();
            this.toastService.addSingle('success', 'Submit', 'Success Record');
            this.loaderService.offLoading();
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Submit',
              error.error.exceptionMessage
                ? error.error.exceptionMessage
                : 'Error Record'
            );
            this.loaderService.offLoading();
          }
        );
    } else {
      this.toastService.addSingle('error', 'Submit', 'Change Record');
      this.loaderService.offLoading();
    }
    this._checkedAll_RegistrxSMS = false;
  }

  BackPage() {
    this.routeStateService.add(
      'Result Bank',
      '/main/auto-debit/resultsAtBank',
      0,
      true
    );
  }
  NextPage() {
    this.routeStateService.add('Report', '/main/auto-debit/report', 0, true);
  }
}
