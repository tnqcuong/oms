import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitComponent } from './auto-debit.component';

describe('AutoDebitComponent', () => {
  let component: AutoDebitComponent;
  let fixture: ComponentFixture<AutoDebitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
