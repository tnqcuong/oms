import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RepaymentMatchingComponent } from './repayment-matching.component';

const routes: Routes = [
  {
    path: '',
    component: RepaymentMatchingComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RepaymentMatchingRoutingModule {}
