import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RepaymentMatchingComponent } from './repayment-matching.component';
import { RepaymentMatchingRoutingModule } from './repayment-matching.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    RepaymentMatchingRoutingModule,
    AppCommonModule,
    HeaderBreadCrumbModule,
    NgxPaginationModule
  ],
  declarations: [RepaymentMatchingComponent],
})
export class RepaymentMatchingModule {}
