import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepaymentBankComponent } from './repayment-bank.component';

describe('RepaymentBankComponent', () => {
  let component: RepaymentBankComponent;
  let fixture: ComponentFixture<RepaymentBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepaymentBankComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepaymentBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
