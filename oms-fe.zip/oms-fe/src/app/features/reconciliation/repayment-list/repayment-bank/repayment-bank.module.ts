import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RepaymentBankComponent } from './repayment-bank.component';
import { RepaymentBankRoutingModule } from './repayment-bank.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
  imports: [
    CommonModule,
    RepaymentBankRoutingModule,
    AppCommonModule,
    HeaderBreadCrumbModule,
    NgxPaginationModule
  ],
  declarations: [RepaymentBankComponent],
})
export class RepaymentBankModule {}
