import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RepaymentListComponent } from './repayment-list.component';
import { RepaymentListRoutingModule } from './repayment-list.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    HeaderBreadCrumbModule,
    RepaymentListRoutingModule],
  declarations: [RepaymentListComponent],
})
export class RepaymentListModule {}
