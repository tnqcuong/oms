import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReconciliationListComponent } from './reconciliation-list.component';

const routes: Routes = [
  {
    path: '',
    component: ReconciliationListComponent,
  },
  {
    path: 'dataChecking',
    loadChildren: () =>
      import(
        'src/app/features/reconciliation/reconciliation-data-checking/reconciliation-data-checking.module'
      ).then((m) => m.ReconciliationDataCheckingModule),
  },
  {
    path: 'disbursement',
    loadChildren: () => import('src/app/features/reconciliation/disbursement/disbursement-list/disbursement-list.module').then(m => m.DisbursementListModule)
  },
  {
    path: 'repayment',
    loadChildren: () => import('src/app/features/reconciliation/repayment-list/repayment-list.module').then((m) => m.RepaymentListModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReconciliationListRoutingModule {}
