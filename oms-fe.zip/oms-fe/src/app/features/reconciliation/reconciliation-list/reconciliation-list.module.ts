import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ReconciliationListComponent } from 'src/app/features/reconciliation/reconciliation-list/reconciliation-list.component';
import { ReconciliationListRoutingModule } from 'src/app/features/reconciliation/reconciliation-list/reconciliation-list.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ReconciliationListRoutingModule,
  ],
  declarations: [ReconciliationListComponent],
})
export class ReconciliationListModule {}
