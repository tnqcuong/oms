import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app//core/services/route-state.service';

// end
@Component({
  selector: 'app-reconciliation-list',
  templateUrl: './reconciliation-list.component.html',
  styleUrls: ['./reconciliation-list.component.sass'],
})
export class ReconciliationListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) {}

  ngOnInit(): void {}
  // Data
  log(val: any) {
    console.log(val);
  }
  goToDepartmentChecking(department: number) {
    this.routeStateService.add(
      'DataChecking',
      '/main/reconciliation/list/dataChecking',
      department,
      false
    );
  }
  goToDepartmentRepayment(department: number) {
    this.routeStateService.add(
      'Repayment',
      '/main/reconciliation/list/repayment',
      department,
      false
    );
  }
  goToDepartmentDisbursement(department: number) {
    this.routeStateService.add(
      'Disbursement',
      '/main/reconciliation/list/disbursement',
      department,
      false
    );
  }
  goToDepartmentReports(department: number) {
    this.routeStateService.add(
      'Reports',
      '/main/reconciliation/list/reports',
      department,
      false
    );
  }
  goToDepartmentTransactionConfirmation(department: number) {
    this.routeStateService.add(
      'TransactionConfirmation',
      '/main/reconciliation/list/transactionConfirmation',
      department,
      false
    );
  }
}
