import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { ReconciliationRoutingModule } from 'src/app/features/reconciliation/reconciliation.routing';
import { ReconciliationComponent } from 'src/app/features/reconciliation/reconciliation.component';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ReconciliationRoutingModule,
    HeaderBreadCrumbModule,
  ],
  declarations: [ReconciliationComponent],
})
export class ReconciliationModule {}
