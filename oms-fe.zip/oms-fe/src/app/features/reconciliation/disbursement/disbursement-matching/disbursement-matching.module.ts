import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisbursementMatchingComponent } from './disbursement-matching.component';
import { DisbursementMatchingRoutingModule } from './disbursement-matching.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    DisbursementMatchingRoutingModule,
    AppCommonModule,
    HeaderBreadCrumbModule,
    NgxPaginationModule
  ],
  declarations: [DisbursementMatchingComponent],
})
export class DisbursementMatchingModule {}
