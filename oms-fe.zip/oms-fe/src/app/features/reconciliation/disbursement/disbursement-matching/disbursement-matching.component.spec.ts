import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisbursementMatchingComponent } from './disbursement-matching.component';

describe('DisbursementMatchingComponent', () => {
  let component: DisbursementMatchingComponent;
  let fixture: ComponentFixture<DisbursementMatchingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisbursementMatchingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisbursementMatchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
