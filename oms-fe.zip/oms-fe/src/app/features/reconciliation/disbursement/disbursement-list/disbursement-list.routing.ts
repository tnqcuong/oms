import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisbursementListComponent } from 'src/app/features/reconciliation/disbursement/disbursement-list/disbursement-list.component';

const routes: Routes = [
  {
    path: '',
    component: DisbursementListComponent,
  },
  {
    path: 'all',
    loadChildren: () =>
      import('src/app/features/reconciliation/disbursement/disbursement-all/disbursement-all.module').then(
        (m) => m.DisbursementAllModule
      ),
  },
  {
    path: 'matching',
    loadChildren: () =>
      import('src/app/features/reconciliation/disbursement/disbursement-matching/disbursement-matching.module').then(
        (m) => m.DisbursementMatchingModule
      ),
  },
  {
    path: 'unMatching',
    loadChildren: () =>
      import('src/app/features/reconciliation/disbursement/disbursement-unmatching/disbursement-unmatching.module').then(
        (m) => m.DisbursementUnMatchingModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DisbursementListRoutingModule {}
