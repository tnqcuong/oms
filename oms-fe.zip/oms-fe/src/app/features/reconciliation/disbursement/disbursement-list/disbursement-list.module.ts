import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisbursementListComponent } from './disbursement-list.component';
import { DisbursementListRoutingModule } from './disbursement-list.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    HeaderBreadCrumbModule,
    DisbursementListRoutingModule],
  declarations: [DisbursementListComponent],
})
export class DisbursementListModule {}
