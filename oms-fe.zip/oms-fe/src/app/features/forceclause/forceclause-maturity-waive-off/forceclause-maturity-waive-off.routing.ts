import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseMaturityWaiveOffComponent } from './forceclause-maturity-waive-off.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseMaturityWaiveOffComponent,
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseMaturityWaiveOffRouting {}
