import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseMaturityWaiveOffComponent } from 'src/app/features/forceclause/forceclause-maturity-waive-off/forceclause-maturity-waive-off.component';
import { ForceclauseMaturityWaiveOffRouting } from 'src/app/features/forceclause/forceclause-maturity-waive-off/forceclause-maturity-waive-off.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseMaturityWaiveOffRouting,
  ],
  declarations: [ForceclauseMaturityWaiveOffComponent],
})
export class ForceclauseMaturityWaiveOffModule {}
