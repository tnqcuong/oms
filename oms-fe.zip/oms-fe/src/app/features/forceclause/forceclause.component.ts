import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app//core/services/route-state.service';
@Component({
  selector: 'app-forceclause',
  templateUrl: './forceclause.component.html',
  styleUrls: ['./forceclause.component.sass']
})
export class ForceclauseComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }

  ngOnInit(): void {
  }
  goToFCLFormAvailable(forceclause: number) {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/form-available',
      forceclause,
      false
    );
  }
  goToFCLPaymentAvailable(forceclause: number) {
    this.routeStateService.add(
      'PAYMENT AVAILABLE',
      '/main/forceclause/payment-available',
      forceclause,
      false
    );
  }
  goToFCLFormPaymentAvailable(forceclause: number) {
    this.routeStateService.add(
      'FORM AND PAYMENT AVAILABLE',
      '/main/forceclause/form-payment-available',
      forceclause,
      false
    );
  }
  goToFCLEarlyTerminationTB6(forceclause: number) {
    this.routeStateService.add(
      'EARLY TERMINATION TB6',
      '/main/forceclause/early-termination-tb6',
      forceclause,
      false
    );
  }
  goToFCLMaturityWaiveOff(forceclause: number) {
    this.routeStateService.add(
      'MATURITY WAIVE OFF',
      '/main/forceclause/maturity-waive-off',
      forceclause,
      false
    );
  }
  goToFCLMaturityBookIncome(forceclause: number) {
    this.routeStateService.add(
      'MATURITY BOOK INCOME',
      '/main/forceclause/maturity-book-income',
      forceclause,
      false
    );
  }
  goToFCLMaturityRefund(forceclause: number) {
    this.routeStateService.add(
      'MATURITY REFUND',
      '/main/forceclause/maturity-refund',
      forceclause,
      false
    );
  }
  goToFCLEarlyTerminationFollowUp(forceclause: number) {
    this.routeStateService.add(
      'EARLY TERMINATION FOLLOW UP',
      '/main/forceclause/early-termination-follow-up',
      forceclause,
      false
    );
  }
}
