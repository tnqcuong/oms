import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseComponent } from 'src/app/features/forceclause/forceclause.component';
import { ForceclauseListRouting } from 'src/app/features/forceclause/forceclause.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseListRouting,
  ],
  declarations: [ForceclauseComponent],
})
export class ForceclauseListModule {}
