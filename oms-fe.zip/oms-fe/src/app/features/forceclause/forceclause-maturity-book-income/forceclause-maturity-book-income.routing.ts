import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseMaturityBookIncomeComponent } from './forceclause-maturity-book-income.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseMaturityBookIncomeComponent,
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseMaturityBookIncomeRouting {}
