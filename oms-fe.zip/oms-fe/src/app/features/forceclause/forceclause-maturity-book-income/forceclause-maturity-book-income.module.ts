import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseMaturityBookIncomeComponent } from 'src/app/features/forceclause/forceclause-maturity-book-income/forceclause-maturity-book-income.component';
import { ForceclauseMaturityBookIncomeRouting } from 'src/app/features/forceclause/forceclause-maturity-book-income/forceclause-maturity-book-income.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseMaturityBookIncomeRouting,
  ],
  declarations: [ForceclauseMaturityBookIncomeComponent],
})
export class ForceclauseMaturityBookIncomeModule {}
