import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseMaturityRefundComponent } from './forceclause-maturity-refund.component';

describe('ForceclauseMaturityRefundComponent', () => {
  let component: ForceclauseMaturityRefundComponent;
  let fixture: ComponentFixture<ForceclauseMaturityRefundComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseMaturityRefundComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseMaturityRefundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
