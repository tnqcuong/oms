import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseMaturityRefundComponent } from 'src/app/features/forceclause/forceclause-maturity-refund/forceclause-maturity-refund.component';
import { ForceclauseMaturityRefundRouting } from 'src/app/features/forceclause/forceclause-maturity-refund/forceclause-maturity-refund.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseMaturityRefundRouting,
  ],
  declarations: [ForceclauseMaturityRefundComponent],
})
export class ForceclauseMaturityRefundModule {}
