import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseMaturityRefundComponent } from './forceclause-maturity-refund.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseMaturityRefundComponent,
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseMaturityRefundRouting {}
