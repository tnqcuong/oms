import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseEarlyTerminationTB6Component } from 'src/app/features/forceclause/forceclause-early-termination-tb6/forceclause-early-termination-tb6.component';
import { ForceclauseEarlyTerminationTB6Routing } from 'src/app/features/forceclause/forceclause-early-termination-tb6/forceclause-early-termination-tb6.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseEarlyTerminationTB6Routing,
  ],
  declarations: [ForceclauseEarlyTerminationTB6Component],
})
export class ForceclauseEarlyTerminationTB6Module {}
