import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseEarlyTerminationTB6Component } from './forceclause-early-termination-tb6.component';

describe('ForceclauseEarlyTerminationTB6Component', () => {
  let component: ForceclauseEarlyTerminationTB6Component;
  let fixture: ComponentFixture<ForceclauseEarlyTerminationTB6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseEarlyTerminationTB6Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseEarlyTerminationTB6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
