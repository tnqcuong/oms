import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-form-payment-available',
  templateUrl: './forceclause-form-payment-available.component.html',
  styleUrls: ['./forceclause-form-payment-available.component.sass']
})
export class ForceclauseFormPaymentAvailableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
