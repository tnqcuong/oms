import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseFormPaymentAvailableComponent } from 'src/app/features/forceclause/forceclause-form-payment-available/forceclause-form-payment-available.component';
import { ForceclauseFormPaymentAvailableRouting } from 'src/app/features/forceclause/forceclause-form-payment-available/forceclause-form-payment-available.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseFormPaymentAvailableRouting,
  ],
  declarations: [ForceclauseFormPaymentAvailableComponent],
})
export class ForceclauseFormPaymentAvailableModule {}
