import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseComponent } from './forceclause.component';

const routes: Routes = [
  {
    path: 'list',
    component: ForceclauseComponent,
  },
  {
    path: 'form-available',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-form-available/forceclause-form-available.module'
      ).then((m) => m.ForceclauseFormAvailableModule),
  },
  {
    path: 'payment-available',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available.module'
      ).then((m) => m.ForceclausePaymentAvailableModule),
  },
  {
    path: 'form-payment-available',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-form-payment-available/forceclause-form-payment-available.module'
      ).then((m) => m.ForceclauseFormPaymentAvailableModule),
  },
  {
    path: 'early-termination-tb6',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-early-termination-tb6/forceclause-early-termination-tb6.module'
      ).then((m) => m.ForceclauseEarlyTerminationTB6Module),
  },
  {
    path: 'maturity-waive-off',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-maturity-waive-off/forceclause-maturity-waive-off.module'
      ).then((m) => m.ForceclauseMaturityWaiveOffModule),
  },
  {
    path: 'maturity-book-income',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-maturity-book-income/forceclause-maturity-book-income.module'
      ).then((m) => m.ForceclauseMaturityBookIncomeModule),
  },
  {
    path: 'maturity-refund',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-maturity-refund/forceclause-maturity-refund.module'
      ).then((m) => m.ForceclauseMaturityRefundModule),
  },
  {
    path: 'early-termination-follow-up',
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-early-termination-follow-up/forceclause-early-termination-follow-up.module'
      ).then((m) => m.ForceclauseEarlyTerminationFollowUpModule),
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseListRouting {}
