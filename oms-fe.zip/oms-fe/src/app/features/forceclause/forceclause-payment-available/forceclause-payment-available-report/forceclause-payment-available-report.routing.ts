import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclausePaymentAvailableReportComponent } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-report/forceclause-payment-available-report.component';

const routes: Routes = [
    {
        path: '',
        component: ForceclausePaymentAvailableReportComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ForceclausePaymentAvailableReportRouting { }
