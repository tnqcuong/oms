import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-payment-available-report',
  templateUrl: './forceclause-payment-available-report.component.html',
  styleUrls: ['./forceclause-payment-available-report.component.sass']
})
export class ForceclausePaymentAvailableReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
