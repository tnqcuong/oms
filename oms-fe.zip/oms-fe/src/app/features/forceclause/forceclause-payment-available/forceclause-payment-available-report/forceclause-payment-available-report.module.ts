import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForceclausePaymentAvailableReportRouting } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-report/forceclause-payment-available-report.routing';
import { ForceclausePaymentAvailableReportComponent } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-report/forceclause-payment-available-report.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';

@NgModule({
  imports: [
    CommonModule,
    ForceclausePaymentAvailableReportRouting,
    AppCommonModule,
    HeaderBreadCrumbModule,
  ],
  declarations: [ForceclausePaymentAvailableReportComponent],
})
export class ForceclausePaymentAvailableReportModule {}
