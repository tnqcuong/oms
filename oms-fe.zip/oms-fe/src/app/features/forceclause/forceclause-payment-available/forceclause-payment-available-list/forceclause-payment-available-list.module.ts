import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForceclausePaymentAvailableListRouting } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-list/forceclause-payment-available-list.routing';
import { ForceclausePaymentAvailableListComponent } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-list/forceclause-payment-available-list.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';

@NgModule({
  imports: [
    CommonModule,
    ForceclausePaymentAvailableListRouting,
    AppCommonModule,
    HeaderBreadCrumbModule,
  ],
  declarations: [ForceclausePaymentAvailableListComponent],
})
export class ForceclausePaymentAvailableListModule {}
