import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclausePaymentAvailableListComponent } from './forceclause-payment-available-list.component';

describe('ForceclausePaymentAvailableListComponent', () => {
  let component: ForceclausePaymentAvailableListComponent;
  let fixture: ComponentFixture<ForceclausePaymentAvailableListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclausePaymentAvailableListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclausePaymentAvailableListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
