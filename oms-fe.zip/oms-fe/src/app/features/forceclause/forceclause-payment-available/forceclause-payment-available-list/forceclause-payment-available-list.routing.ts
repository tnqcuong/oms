import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclausePaymentAvailableListComponent } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-list/forceclause-payment-available-list.component';

const routes: Routes = [
    {
        path: '',
        component: ForceclausePaymentAvailableListComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ForceclausePaymentAvailableListRouting { }
