import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclausePaymentAvailableComponent } from './forceclause-payment-available.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'list',
  },
  {
    path: 'list',
    component: ForceclausePaymentAvailableComponent,
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-list/forceclause-payment-available-list.module'
      ).then((m) => m.ForceclausePaymentAvailableListModule),
  },
  {
    path: 'report',
    component: ForceclausePaymentAvailableComponent,
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available-report/forceclause-payment-available-report.module'
      ).then((m) => m.ForceclausePaymentAvailableReportModule),
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclausePaymentAvailableRouting {}
