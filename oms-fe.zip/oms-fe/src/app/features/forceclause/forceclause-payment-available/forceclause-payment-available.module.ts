import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclausePaymentAvailableComponent } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available.component';
import { ForceclausePaymentAvailableRouting } from 'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclausePaymentAvailableRouting,
  ],
  declarations: [ForceclausePaymentAvailableComponent],
})
export class ForceclausePaymentAvailableModule {}
