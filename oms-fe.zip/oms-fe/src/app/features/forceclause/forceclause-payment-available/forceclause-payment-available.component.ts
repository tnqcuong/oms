import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-payment-available',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./forceclause-payment-available.component.sass']
})
export class ForceclausePaymentAvailableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
