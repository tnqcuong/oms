import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseFormAvailableComponent } from 'src/app/features/forceclause/forceclause-form-available/forceclause-form-available.component';
import { ForceclauseFormAvailableRouting } from 'src/app/features/forceclause/forceclause-form-available/forceclause-form-available.routing';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseFormAvailableRouting,
    HeaderBreadCrumbModule,
  ],
  declarations: [ForceclauseFormAvailableComponent],
})
export class ForceclauseFormAvailableModule {}
