import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForceclauseFormAvailableReportRouting } from 'src/app/features/forceclause/forceclause-form-available/forceclause-form-available-report/forceclause-form-available-report.routing';
import { ForceclauseFormAvailableReportComponent } from 'src/app/features/forceclause/forceclause-form-available/forceclause-form-available-report/forceclause-form-available-report.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';

@NgModule({
  imports: [
    CommonModule,
    ForceclauseFormAvailableReportRouting,
    AppCommonModule,
    HeaderBreadCrumbModule,
  ],
  declarations: [ForceclauseFormAvailableReportComponent],
})
export class ForceclauseFormAvailableListModule {}
