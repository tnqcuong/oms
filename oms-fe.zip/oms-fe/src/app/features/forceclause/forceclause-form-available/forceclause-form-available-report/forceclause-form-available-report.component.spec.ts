import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseFormAvailableReportComponent } from './forceclause-form-available-report.component';

describe('ForceclauseFormAvailableReportComponent', () => {
  let component: ForceclauseFormAvailableReportComponent;
  let fixture: ComponentFixture<ForceclauseFormAvailableReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseFormAvailableReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseFormAvailableReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
