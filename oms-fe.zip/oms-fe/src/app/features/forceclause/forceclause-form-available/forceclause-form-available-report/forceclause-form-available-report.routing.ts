import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseFormAvailableReportComponent } from 'src/app/features/forceclause/forceclause-form-available/forceclause-form-available-report/forceclause-form-available-report.component';

const routes: Routes = [
    {
        path: '',
        component: ForceclauseFormAvailableReportComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ForceclauseFormAvailableReportRouting { }
