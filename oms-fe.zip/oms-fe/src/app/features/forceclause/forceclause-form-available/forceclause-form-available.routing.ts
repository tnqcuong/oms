import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseFormAvailableComponent } from './forceclause-form-available.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'list',
  },
  {
    path: 'list',
    component: ForceclauseFormAvailableComponent,
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-form-available/forceclause-form-available-list/forceclause-form-available-list.module'
      ).then((m) => m.ForceclauseFormAvailableListModule),
  },
  {
    path: 'report',
    component: ForceclauseFormAvailableComponent,
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-form-available/forceclause-form-available-report/forceclause-form-available-report.module'
      ).then((m) => m.ForceclauseFormAvailableListModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseFormAvailableRouting {}
