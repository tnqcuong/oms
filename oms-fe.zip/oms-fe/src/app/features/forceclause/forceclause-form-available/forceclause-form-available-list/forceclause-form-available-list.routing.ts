import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseFormAvailableListComponent } from 'src/app/features/forceclause/forceclause-form-available/forceclause-form-available-list/forceclause-form-available-list.component';

const routes: Routes = [
    {
        path: '',
        component: ForceclauseFormAvailableListComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ForceclauseFormAvailableListRouting { }
