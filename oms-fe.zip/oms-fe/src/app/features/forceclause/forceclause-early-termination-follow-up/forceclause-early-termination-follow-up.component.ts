import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-early-termination-follow-up',
  templateUrl: './forceclause-early-termination-follow-up.component.html',
  styleUrls: ['./forceclause-early-termination-follow-up.component.sass']
})
export class ForceclauseEarlyTerminationFollowUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
