import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseEarlyTerminationFollowUpComponent } from './forceclause-early-termination-follow-up.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseEarlyTerminationFollowUpComponent,
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseEarlyTerminationFollowUpRouting {}
