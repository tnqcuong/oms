import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { ForceclauseEarlyTerminationFollowUpComponent } from 'src/app/features/forceclause/forceclause-early-termination-follow-up/forceclause-early-termination-follow-up.component';
import { ForceclauseEarlyTerminationFollowUpRouting } from 'src/app/features/forceclause/forceclause-early-termination-follow-up/forceclause-early-termination-follow-up.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseEarlyTerminationFollowUpRouting,
  ],
  declarations: [ForceclauseEarlyTerminationFollowUpComponent],
})
export class ForceclauseEarlyTerminationFollowUpModule {}
