import { Component, OnInit, HostListener } from '@angular/core';
import { User } from 'src/app/core/models/user.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { SessionService } from 'src/app/core/services/session.service';
import { UserContextService } from 'src/app/core/services/user-context.service';
import { Router } from '@angular/router';
import { UserIdleService } from 'angular-user-idle';
import { MenuItem } from 'primeng/api';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.sass'],
})
export class HeaderComponent implements OnInit {
  user: User = {
    userId: null || 0,
    userName: null || '',
    password: null || '',
    emailId: null || '',
    birthDate: null || new Date(),
    token: null || '',
  };
  itemsMenubar: MenuItem[];
  isToggleMenu: boolean = false;
  topPosToStartShowing = 120;
  constructor(
    private router: Router,
    private routeStateService: RouteStateService,
    private sessionService: SessionService,
    private userIdle: UserIdleService,
    private userContextService: UserContextService
  ) {this.itemsMenubar = [];}

  ngOnInit(): void {
    this.user = this.sessionService.getItem('currentUser');
    //Start watching for user inactivity.
    this.userIdle.startWatching();

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe();

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() => {
      this.logout();
    });

    this.itemsMenubar=[
      {
        label: 'Reconciliation',
        // icon: 'pi pi-fw pi-file',
        items:[
          {
            label: 'Reconciliation result',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/reconciliation/list/dataChecking'
          },
          {
            label: 'Repayment',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/reconciliation/list/repayment'
          },
          {
            label: 'Disbursement',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/reconciliation/list/disbursement'
          },
          {
            label: 'Reports',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/reconciliation/list/reports'
          },
          {
            label: 'Transaction confirmation',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/reconciliation/list/transactionConfirmation'
          },
        ]
      },
      {
        label: 'Auto-Debit',
        // icon: 'pi pi-fw pi-file',
        items:[
          {
            label: 'AUTO DEBIT REGISTRATION',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/registrantion'
          },
          {
            label: 'AUTO DEBIT FORM - BN SENT HARD',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/formAndHard'
          },
          {
            label: 'AUTO DEBIT FORM - D&R RECEIVED HARD',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/formAndReceived'
          },
          {
            label: 'WAITING LIST OF AUTO-DEBIT REGISTRATION RESULTS AT BANK',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/resultsAtBank'
          },
          {
            label: 'SMS SENDING LIST',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/smsSendingList'
          },
          {
            label: 'REPORT',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/report'
          },
        ]
      },
      {
        label: 'Forceclause',
        // icon: 'pi pi-fw pi-file',
        items:[
          {
            label: 'FORM AVAILABLE',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/form-available'
          },
          {
            label: 'PAYMENT AVAILABLE',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/payment-available'
          },
          {
            label: 'FORM AND PAYMENT AVAILABLE',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/form-payment-available'
          },
          {
            label: 'EARLY TERMINATION TB6',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/early-termination-tb6'
          },
          {
            label: 'MATURITY WAIVE OFF',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/maturity-waive-off'
          },
          {
            label: 'MATURITY BOOK INCOME',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/maturity-book-income'
          },
          {
            label: 'MATURITY REFUND',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/maturity-refund'
          },
          {
            label: 'EARLY TERMINATION FOLLOW UP',
            icon: 'pi pi-fw pi-plus',
            routerLink:'/main/forceclause/early-termination-follow-up'
          },
        ]
      },
    ]
  }

  logout() {
    this.userIdle.stopWatching();
    this.routeStateService.removeAll();
    this.userContextService.logout();
    this.sessionService.removeItem('active-menu');
    this.router.navigate(['/login']);
  }
  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e: any) {
    if (window.pageYOffset > 110) {
      let element =
        document.getElementById('headerscroll-true') || new HTMLElement();
      element.classList.add('sticky');
    } else {
      let element =
        document.getElementById('headerscroll-true') || new HTMLElement();
      element.classList.remove('sticky');
    }
  }

  // @HostListener('window:scroll')
  // checkScroll() {
  //   // window의 scroll top
  //   // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

  //   const scrollPosition =
  //     window.pageYOffset ||
  //     document.documentElement.scrollTop ||
  //     document.body.scrollTop ||
  //     0;
  //   var scroll = document.getElementById('headerscroll');

  //   if (scrollPosition >= this.topPosToStartShowing) {
  //     this.isToggleMenu = true;
  //   } else {
  //     this.isToggleMenu = false;
  //   }
  // }
  removeClass(elem: any, cls: any) {
    var str = ' ' + elem.className + ' ';
    elem.className = str
      .replace(' ' + cls + ' ', ' ')
      .replace(/^\s+|\s+$/g, '');
  }
  addClass(elem: any, cls: any) {
    elem.className += ' ' + cls;
  }
}
