export const environmentAPI = {
  login: 'shinhan/common/authentication',
  profile: 'shinhan/service/userProfile',
  metadata: 'shinhan/service/metadata',
  profileUsername: 'shinhan/service/configuration/userProfile',
  role: 'shinhan/service/configuration/roles',
  addMetadata: 'shinhan/service/configuration/metadata',
  delMetadata: 'shinhan/service/configuration/metadata',
  delRole: 'shinhan/service/configuration/roles',
  addRole: 'shinhan/service/configuration/roles',
  updateRole: 'shinhan/service/configuration/roles',
  updateFeaturebyRole: 'shinhan/service/configuration/roles',
  updateRoleUserbyAdmin: 'shinhan/service/configuration/userProfile/role',
  updateMetadata: 'shinhan/service/configuration/metadata',
  updateStatusUserActive: 'shinhan/service/configuration/userProfile/active',
  updatePasswordUserActive:
    'shinhan/service/configuration/userProfile/password',
  updatePasswordUserbyUser: 'shinhan/service/userProfile',
  updateStatusUserDeActive:
    'shinhan/service/configuration/userProfile/deactive',
  metadata_feature: 'shinhan/service/configuration/features',
  getRoleDetail: 'shinhan/service/configuration/roles',
  addMetadata_feature: 'shinhan/service/configuration/features',
  addUser: 'shinhan/service/configuration/userProfile',
  updateMetadata_feature: 'shinhan/service/configuration/features',
  delMetadata_feature: 'shinhan/service/configuration/features',
};

export const environmentAPI_Recon = {
  dataChecking: 'shinhan/service/reconcile/statementFileMas',
  repaymentMatchingTrx: 'shinhan/service/reconcile/matchingtrx',
  repaymentUnMatchingTrx: 'shinhan/service/reconcile/unmatchingtrx',
  updateReconTrxNote: 'shinhan/service/reconcile/remarkaddinf',
  unMatchingLMSTrx: 'shinhan/service/reconcile/unmatchinglmstrx',
  partnerCommonInfo: 'shinhan/service/reconcile/common',
  report: 'shinhan/service/reconcile/report',
  disbursalMatchingTrx: 'shinhan/service/reconcile/matchingdisbtrx',
  disbursalUnMatchingTrx: 'shinhan/service/reconcile/unmatchingdisbtrx',
  reTry: 'shinhan/service/reconcile/retry',
  reconDailyReport: 'shinhan/service/reconcile/repmtopsreport',
  reconPendingReport: 'shinhan/service/reconcile/pendingReport',
  reconSuspenseReport: 'shinhan/service/reconcile/suspensetrx',
  exportPendingReport: 'shinhan/service/reconcile/pendingreport',
  exportDailyReport: 'shinhan/service/reconcile/dailyreport',
  exportSuspenseReport: 'shinhan/service/reconcile/suspensereport',
};

export const environmentAPI_Auto = {
  importFile: 'shinhan/service/autodebit/importregistrx',
  importFileBank: 'shinhan/service/autodebit/importbankresult',
  unregistrx: 'shinhan/service/autodebit/unregistrx',
  registrx: 'shinhan/service/autodebit/registrx',
  importhardcopy: 'shinhan/service/autodebit/importhardcopy',
  downloadTemplate: 'shinhan/service/autodebit/template',
  exportbankdata: 'shinhan/service/autodebit/exportbankdata',
  export_unregistrx: 'shinhan/service/autodebit/unregistrx/export',
  updateBankResutl: 'shinhan/service/autodebit/updatebankresult',
  export_hard: 'shinhan/service/autodebit/registrx/export',
  metadata: 'shinhan/service/metadata',
  sms: 'shinhan/service/autodebit/registrx/sms',
  sms_export: 'shinhan/service/autodebit/registrx/sms/export',
  sms_send_unregistrx: 'shinhan/service/autodebit/unregistrx/sendsms',
  sms_send_registrx: 'shinhan/service/autodebit/registrx/sendsms',
  report: 'shinhan/service/autodebit/exportreport',
};

export const environmentAPI_ReDisbursal = {
  redisbursalTrx: 'shinhan/service/redisb/redisburs',
};

export const environmentAPI_Refund = {
  refundTrx: 'shinhan/service/refund/getrefunddata',
  refundReport: 'shinhan/service/refund/exportrefundreport',
};

export enum Url_OMS {
  URL_FEATURE_AUTO_BNSENTHARDCOPY = '/main/auto-debit/formAndHard',
  URL_FEATURE_CREDIT_SHIELD = '',
  URL_FEATURE_AUTO_DRRECEIVEDHARDCOPY = '/main/auto-debit/formAndReceived',
  URL_FEATURE_EARLYTERMINATION_FOLLOWUP = '/main/forceclause/early-termination-follow-up',
  URL_FEATURE_EARLYTERMINATION_FORMAVAILABLE = '/main/forceclause/form-available',
  URL_FEATURE_EARLYTERMINATION_FORMPAYMENTAVAILABLE = '/main/forceclause/form-payment-available',
  URL_FEATURE_AUTO_LISTWAITINGBANKRESULT = '/main/auto-debit/resultsAtBank',
  URL_FEATURE_AUTO_LISTSENDINSMS = '/main/auto-debit/smsSendingList',
  URL_FEATURE_EARLYTERMINATION_MATURITY_BOOKINCOME = '/main/forceclause/maturity-book-income',
  URL_FEATURE_EARLYTERMINATION_MATURITY_REFUND = '/main/forceclause/maturity-refund',
  URL_FEATURE_EARLYTERMINATION_MATURITY_WAIVEOFF = '/main/forceclause/maturity-waive-off',
  URL_FEATURE_EARLYTERMINATION_PAYMENTAVAILABLE = '/main/forceclause/payment-available',
  URL_FEATURE_RE_DISBURSAL = '/main/re-disbursal',
  URL_FEATURE_REFUND = '/main/refund',
  URL_FEATURE_RECON_FULL = '/main/reconciliation',
  URL_FEATURE_AUTO_REGISTRATION = '/main/auto-debit/registration',
  URL_FEATURE_AUTO_REPORT = '/main/auto-debit/report',
  URL_FEATURE_REVERT = '',
  URL_FEATURE_EARLYTERMINATION_TB6 = '/main/forceclause/early-termination-tb6',
}

export enum Role {
  OMS_USER_ROLE_ADMIN = 'OMS_USER_ROLE_ADMIN',
  OMS_USER_ROLE_CO = 'OMS_USER_ROLE_CO',
  OMS_USER_ROLE_RECON = 'OMS_USER_ROLE_RECON',
  OMS_USER_ROLE_CS = 'OMS_USER_ROLE_CS',
  OMS_USER_ROLE_DR = 'OMS_USER_ROLE_DR',
}
