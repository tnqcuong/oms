// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiUrl_Authentication: 'http://10.148.84.246:19191/oms-auth-api/',
  apiUrl_FCL: 'http://10.148.84.246:39191/oms-fcl-api/',
  apiUrl_Auto: 'http://10.148.84.246:29191/oms-autodebit-api/',
  apiUrl_Redisbursal: 'http://10.148.85.97:19192/oms-redisb-api/',
  apiUrl_Refund: 'http://10.148.85.174:19192/oms-refund-api/',
  apiUrl: 'http://10.148.85.97:19191/oms-reconcile-api/',
  // apiUrl: 'http://localhost:19191/oms-reconcile-api/',
  version: '1.0.0'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
