import { Component, OnInit, HostListener } from '@angular/core';
import { User } from 'src/app/core/models/user.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { SessionService } from 'src/app/core/services/session.service';
import { UserContextService } from 'src/app/core/services/user-context.service';
import { Router } from '@angular/router';
import { UserIdleService } from 'angular-user-idle';
import { MenuItem } from 'primeng/api';
import { OMS_USER } from 'src/app/core/models/systemConfigucation.model';
import { SystemConfigurationService } from 'src/app/features/system-configuration/system-configuration.service';
import { ToastService } from 'src/app/core/services/toast.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.sass'],
})
export class HeaderComponent implements OnInit {
  user: User = {
    userName: null || '',
    token: null || '',
    fullname: null || '',
  };
  user$: User;

  OMS_USERNAME: OMS_USER = new OMS_USER();
  submitted_adduser: boolean = false;

  display_password: boolean = false;

  check_Admin: boolean = false;
  itemsMenubar: MenuItem[];
  isToggleMenu: boolean = false;
  topPosToStartShowing = 120;
  constructor(
    private router: Router,
    private routeStateService: RouteStateService,
    private sessionService: SessionService,
    private userIdle: UserIdleService,
    private userContextService: UserContextService,
    private systemConfigurationService: SystemConfigurationService,
    private toastService: ToastService,
  ) {
    this.itemsMenubar = [];
    this.user$ = this.userContextService.userValue;

  }

  ngOnInit(): void {
    this.user = this.sessionService.getItem('currentUser');
    //Start watching for user inactivity.
    this.userIdle.startWatching();

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe();

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() => {
      this.logout();
    });

    this.itemsMenubar = [
      {
        label: 'Reconciliation',
        // icon: 'pi pi-fw pi-file',
        items: [
          {
            label: 'Reconciliation result',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/reconciliation/data-checking',
          },
          {
            label: 'Repayment',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/reconciliation/repayment',
          },
          {
            label: 'Disbursement',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/reconciliation/disbursement',
          },
          {
            label: 'Reports',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/reconciliation/reports',
          },
        ],
      },
      {
        label: 'Auto-Debit',
        // icon: 'pi pi-fw pi-file',
        items: [
          {
            label: 'AUTO DEBIT REGISTRATION',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/registration',
          },
          {
            label: 'AUTO DEBIT FORM - BN SENT HARD',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/formAndHard',
          },
          {
            label: 'AUTO DEBIT FORM - D&R RECEIVED HARD',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/formAndReceived',
          },
          {
            label: 'WAITING LIST OF AUTO-DEBIT REGISTRATION RESULTS AT BANK',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/resultsAtBank',
          },
          {
            label: 'SMS SENDING LIST',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/smsSendingList',
          },
          {
            label: 'REPORT',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/auto-debit/report',
          },
        ],
      },
      {
        label: 'Early Termination',
        // icon: 'pi pi-fw pi-file',
        items: [
          {
            label: 'FORM AVAILABLE',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/form-available',
          },
          {
            label: 'PAYMENT AVAILABLE',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/payment-available',
          },
          {
            label: 'FORM AND PAYMENT AVAILABLE',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/form-payment-available',
          },
          {
            label: 'EARLY TERMINATION TB6',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/early-termination-tb6',
          },
          {
            label: 'MATURITY WAIVE OFF',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/maturity-waive-off',
          },
          {
            label: 'MATURITY BOOK INCOME',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/maturity-book-income',
          },
          {
            label: 'MATURITY REFUND',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/maturity-refund',
          },
          {
            label: 'EARLY TERMINATION FOLLOW UP',
            icon: 'pi pi-fw pi-plus',
            routerLink: '/main/forceclause/early-termination-follow-up',
          },
        ],
      },
      {
        label: 'Re-Disbursal',
        routerLink: '/main/re-disbursal',
      }
    ];
    this.user$.role?.map((role) => {
      if (role == 'OMS_USER_ROLE_ADMIN') {
        this.check_Admin = true;
      }
    });
  }

  logout() {
    this.userIdle.stopWatching();
    this.routeStateService.removeAll();
    this.userContextService.logout();
    this.sessionService.removeItem('active-menu');
    this.router.navigate(['/login']);
  }
  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e: any) {
    if (window.pageYOffset > 110) {
      let element =
        document.getElementById('headerscroll-true') || new HTMLElement();
      element.classList.add('sticky');
    } else {
      let element =
        document.getElementById('headerscroll-true') || new HTMLElement();
      element.classList.remove('sticky');
    }
  }
  editUser() {
    this.display_password = true;
  }

  SavePasswordUser() {
    this.systemConfigurationService
      .UpdatePasswordUserbyUser(this.OMS_USERNAME)
      .subscribe(
        (data) => {
          this.display_password = false;
          this.toastService.addSingleShortTime(
            'success',
            'User',
            'Success Update Password'
          );
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'User',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error Update Password'
          );
        }
      );
  }
  ClosePasswordUser() {
    this.display_password = false;
  }
  gotoRegistration() {
    this.routeStateService.add(
      'REGISTRATION',
      '/main/system/configuration',
      0,
      true
    );
  }
  removeClass(elem: any, cls: any) {
    var str = ' ' + elem.className + ' ';
    elem.className = str
      .replace(' ' + cls + ' ', ' ')
      .replace(/^\s+|\s+$/g, '');
  }
  addClass(elem: any, cls: any) {
    elem.className += ' ' + cls;
  }
}
