import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './layout/error/error.component';
import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { ReDisbursalComponent } from './features/re-disbursal/re-disbursal.component';
import { LayoutComponent } from './layout/layout.component';
import { User, Roles } from './core/models/user.model';
import { Role, Url_OMS } from 'src/environments/environmentAPI';
import { RefundComponent } from './features/refund/refund.component';


const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    loadChildren: () =>
      import('src/app/features/login/login.module').then((m) => m.LoginModule),
  },
  {
    path: 'main',
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'reconciliation',
        loadChildren: () =>
          import('src/app/features/reconciliation/reconciliation.module').then(
            (m) => m.ReconciliationModule
          ),
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_RECON_FULL] },
      },
      {
        path: 'auto-debit',
        loadChildren: () =>
          import('src/app/features/auto-debit/auto-debit.module').then(
            (m) => m.AutoDebitModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 'forceclause',
        loadChildren: () =>
          import('src/app/features/forceclause/forceclause.module').then(
            (m) => m.ForceclauseModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 're-disbursal',
        component: ReDisbursalComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_RE_DISBURSAL] },
      },
      {
        path: 'refund',
        component: RefundComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_REFUND] },
      },
      {
        path: 'system/configuration',
        loadChildren: () =>
          import(
            'src/app/features/system-configuration/system-configuration.module'
          ).then((m) => m.SystemConfigurationModule),
        canActivate: [AuthGuard],
        // data: { roles: [Role.OMS_USER_ROLE_ADMIN] },
        data: { roles: [Role.OMS_USER_ROLE_ADMIN] },
      },
    ],
  },
  {
    path: '**',
    redirectTo: 'error',
  },
  {
    path: 'error',
    component: ErrorComponent,
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      // useHash: true,
      anchorScrolling: 'enabled',
      preloadingStrategy: PreloadAllModules,
      paramsInheritanceStrategy: 'always',
      initialNavigation: 'enabled',
      relativeLinkResolution: 'corrected',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
