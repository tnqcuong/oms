import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './layout/error/error.component';
import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { ReDisbursalComponent } from './features/re-disbursal/re-disbursal.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    loadChildren: () =>
      import('src/app/features/login/login.module').then((m) => m.LoginModule),
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'reconciliation',
    loadChildren: () =>
      import('src/app/features/reconciliation/reconciliation.module').then(
        (m) => m.ReconciliationModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'auto-debit',
    loadChildren: () =>
      import('src/app/features/auto-debit/auto-debit.module').then(
        (m) => m.AutoDebitModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'forceclause',
    loadChildren: () =>
      import('src/app/features/forceclause/forceclause.module').then(
        (m) => m.ForceclauseModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 'system/configuration',
    loadChildren: () =>
      import('src/app/features/system-configuration/system-configuration.module').then(
        (m) => m.SystemConfigurationModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: 're-disbursal',
    component: ReDisbursalComponent,
    canActivate: [AuthGuard],
  },
  {
    path: '**',
    redirectTo: 'error',
  },
  {
    path: 'error',
    component: ErrorComponent,
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      anchorScrolling: 'enabled',
      preloadingStrategy: PreloadAllModules,
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
