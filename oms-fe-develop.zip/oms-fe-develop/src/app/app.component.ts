import { ChangeDetectorRef, Component } from '@angular/core';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ThemeService } from 'src/app/core/services/theme.service';
import { SessionService } from 'src/app/core/services/session.service';
import { ApplicationStateService } from './core/services/application-state.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  title = 'OMS';
  showLoader: boolean = false;
  theme: string = '';
  isMenuVisible: boolean = false;
  showHeader: boolean = false;
  constructor(
    private loaderService: LoaderService,
    private themeService: ThemeService,
    private sessionService: SessionService,
    private cdRef : ChangeDetectorRef,
    private applicationStateService: ApplicationStateService,
  ) {
  }
  ngOnInit() {

    this.loaderService.header.subscribe((val: boolean) => {
      this.showHeader = val;
      this.cdRef.detectChanges();
    });

    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
      this.cdRef.detectChanges();
    });

    this.themeService.theme.subscribe((val: string) => {
      this.theme = val;
    });

    if (this.applicationStateService.getIsMobileResolution()) {
      this.isMenuVisible = false;
    } else {
      this.isMenuVisible = true;
    }
  }

  ngOnDestroy() {
    this.themeService.theme.observers.forEach(function (element) {
      element.complete();
    });
    this.loaderService.status.observers.forEach(function (element) {
      element.complete();
    });
  }
}
