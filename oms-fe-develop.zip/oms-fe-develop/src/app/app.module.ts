import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './layout/header/header.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { LayoutComponent } from 'src/app/layout/layout.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppCommonModule } from 'src/app/app.common.module';
import { UserIdleModule } from 'angular-user-idle';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';
import { FooterComponent } from 'src/app/layout/footer/footer.component';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { ReDisbursalComponent } from './features/re-disbursal/re-disbursal.component';
import { RefundComponent } from './features/refund/refund.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
    ReDisbursalComponent,
    RefundComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    AppCommonModule,
    HeaderBreadCrumbModule,

    UserIdleModule.forRoot({ idle: 1800, timeout: 1, ping: 0 }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
  ],
  exports: [TranslateModule],
  providers: [MessageService, AuthGuard, ConfirmationService],
  bootstrap: [AppComponent],
})
export class AppModule {}
