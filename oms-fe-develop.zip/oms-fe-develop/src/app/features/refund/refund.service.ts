import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { SessionService } from 'src/app/core/services/session.service';
import { environment } from 'src/environments/environment';
import { environmentAPI_Refund } from 'src/environments/environmentAPI';

@Injectable({
  providedIn: 'root'
})
export class RefundService {

  constructor(
    private http: HttpClient,
    private sessionService: SessionService,
    private commonUtilityService: CommonUtilityService
  ) { }

  getRefundData(
    _number: string,
    _start: string,
    _searchType: string,
    _searchValue: string,
  ): Observable<any>{

    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();

    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (_searchType === '_loanNo') {
      params = params.set('_loanNo', _searchValue);
    }

    return this.http.get<any>(environment.apiUrl_Refund + environmentAPI_Refund.refundTrx,
      { headers: headerParams, params: params });
  }

  exportRefundReport(
    templateType: string,
  ): Observable<any> {
    let headers = this.commonUtilityService.getPDFHeaderParams();
    let params = new HttpParams();
    params = params.set('_bank', templateType);
    return this.http.post(
      environment.apiUrl_Refund + environmentAPI_Refund.refundReport,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  updateRefundData(
    //isUnMatch: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    // let params = new HttpParams();
    // params = params.set('_isUnmatch', isUnMatch);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl_Refund + environmentAPI_Refund.updateCustomerInfo,
      body,
      // { headers: headerParams, params: params }
      { headers: headerParams}
    );
  }
}
