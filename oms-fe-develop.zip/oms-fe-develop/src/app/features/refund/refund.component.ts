import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { Refund } from 'src/app/core/models/refund-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { RefundService } from './refund.service';
import * as file from 'file-saver';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.sass']
})
export class RefundComponent implements OnInit {

  _today = new Date();
  startDt = new Date();
  endDt = new Date();
  _number: string = '20';
  _start: string = '1';
  _totalTrx: number = 0;

  disBankList: MetaData[] = [];
  searchTypeList: SearchType[] = [];
  _searchTypeList: SearchType[] = [];
  selectedBank: string = '';
  searchingValue: string = '';
  selectedSearchType: string = '_loanNo';
  templateType: string = 'TECHCOMBANK';

  refundData: Refund[] = [];

  constructor(
    private refundService: RefundService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private confirmationService: ConfirmationService,
    private loaderService: LoaderService
  ) {
    this.disBankList = commonUtilityService.bankDisbList;
    this._searchTypeList = commonUtilityService.bankDisbSearchType;
  }

  ngOnInit(): void {
    this.getReFundData();
  }

  getReFundData() {
    this.loaderService.onLoading();
    this.refundService
      .getRefundData(
        this._number,
        this._start,
        this.selectedSearchType,
        this.searchingValue,
      )
      .subscribe(
        (data) => {
          this.refundData = data.result.data;
          this._totalTrx = data.result.count;
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle('error', '', 'Server Error');
        }
      );
  }

  searchTransaction(){

  }


  confirmAndExport() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation CSV',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.exportRefundReport();
      },
      reject: () => {
        this.toastService.addSingleShortTime(
          'info',
          'Rejected',
          'You have rejected'
        );
      },
    });
  }

  exportRefundReport() {
    this.loaderService.onLoading();
    this.refundService
      .exportRefundReport(moment(this.templateType).format('DD/MM/YYYY'))
      .subscribe(
        (response) => {
          this.downloadFile(response.body);
          this.loaderService.offLoading();
        },
        (error) => {
          console.log(error);
          this.loaderService.offLoading();
        }
      );
  }

  downloadFile(data: any) {
    const fileName = 'Daily_Report';
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + this._today);
  }
}
