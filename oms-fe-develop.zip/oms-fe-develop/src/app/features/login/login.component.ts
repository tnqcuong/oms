import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Validators, FormControl, FormGroup } from '@angular/forms';
import { UserDataService } from 'src/app/core/services/user-data.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { SessionService } from 'src/app/core/services/session.service';
import { UserContextService } from 'src/app/core/services/user-context.service';
import { environment } from 'src/environments/environment';
import { Role } from 'src/environments/environmentAPI';
import { User } from 'src/app/core/models/user.model';
import { LoaderService } from 'src/app/core/services/loader.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass'],
  providers: [MessageService],
})
export class LoginComponent implements OnInit {
  locale: string = '';

  version: string = '';

  msgs: any[] = [];
  loginForm: FormGroup;

  showPassword: boolean = false;

  constructor(
    private userService: UserDataService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private userContextService: UserContextService,
    private sessionService: SessionService,
    private loaderService: LoaderService
  ) {
    this.loginForm = new FormGroup({
      userName: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
    });
  }

  ngOnInit(): void {
    this.version = environment.version;
    this.loaderService.hideHeader();
  }
  onClickLogin() {
    let user: User = new User();
    this.userService
      .getUserByUserNameAndPassword(
        this.loginForm.value.userName,
        this.loginForm.value.password
      )
      .subscribe(
        (data) => {
          // Call Role
          const token = data.result.token;
          this.userService.GetRoleUser(token).subscribe(
            (data) => {
              user = data?.result;
              user.token = token;

              let newarr_role = [];
              let newarr_feature = [];

              for (let i = 0; i < data?.result?.roles.length; i++) {
                newarr_role.push(data?.result?.roles[i].roleCode);
                for (
                  let j = 0;
                  j < data?.result?.roles[i]?.features.length;
                  j++
                ) {
                  // console.log(data?.result?.roles[i]?.features[j]);
                  if (
                    data?.result?.roles[i]?.features[j].isRead === 'Y' ||
                    data?.result?.roles[i]?.features[j].isWrite === 'Y'
                  )
                  newarr_feature.push(data?.result?.roles[i]?.features[j].url);
                }
              }
              user.role = newarr_role;
              user.feature = newarr_feature;

              // console.log(user);

              this.userContextService.setUser(user);
              if(user.role && user.role.includes(Role.OMS_USER_ROLE_ADMIN)){
                this.routeStateService.add(
                  'System Admin',
                  'main/system/configuration',
                  null,
                  true
                );
                return;
              }
              this.routeStateService.add(
                'Dashboard',
                'main/dashboard',
                null,
                true
              );
              return;
            },
            (error) => {
              this.toastService.addSingle(
                'error',
                '',
                error.error.exceptionMessage
                  ? error.error.exceptionMessage
                  : 'Error Server'
              );
              return;
            }
          );
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            '',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error Server'
          );
          return;
        }
      );
  }
  toggleEys() {
    this.showPassword = !this.showPassword;
  }
}
