import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Validators, FormControl, FormGroup } from '@angular/forms';
import { UserDataService } from 'src/app/core/services/user-data.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { SessionService } from 'src/app/core/services/session.service';
import { UserContextService } from 'src/app/core/services/user-context.service';
import { environment } from 'src/environments/environment';
import { User } from 'src/app/core/models/user.model';
import { LoaderService } from 'src/app/core/services/loader.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass'],
  providers: [MessageService],
})
export class LoginComponent implements OnInit {
  locale: string = '';

  version: string = '';

  msgs: any[] = [];
  loginForm: FormGroup;

  showPassword: boolean = false;

  constructor(
    private userService: UserDataService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private userContextService: UserContextService,
    private sessionService: SessionService,
    private loaderService: LoaderService,
  ) {
    this.loginForm = new FormGroup({
      userName: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
    });
  }

  ngOnInit(): void {
    this.version = environment.version;
    this.loaderService.hideHeader();
  }
  onClickLogin() {
    let user: User = new User();
    this.userService
      .getUserByUserNameAndPassword(
        this.loginForm.value.userName,
        this.loginForm.value.password
      )
      .subscribe(
        (data) => {
          // Call Role
          const token = data.result.token;
          // tesst
          user.token = token;
              this.userContextService.setUser(user);
              this.routeStateService.add(
                'Dashboard',
                '/dashboard',
                null,
                true
              );
              return;
          // tesst
          this.userService.GetRoleUser(token).subscribe(
            (data) => {
              user = data?.result;
              user.token = token;
              this.userContextService.setUser(user);
              this.routeStateService.add(
                'Dashboard',
                '/dashboard',
                null,
                true
              );
              return;
            },
            (error) => {
              this.toastService.addSingle(
                'error',
                '',
                error.error.exceptionMessage
                  ? error.error.exceptionMessage
                  : 'Error Server'
              );
              return;
            }
          );
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            '',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error Server'
          );
          return;
        }
      );
  }
  toggleEys() {
    this.showPassword = !this.showPassword;
  }
}
