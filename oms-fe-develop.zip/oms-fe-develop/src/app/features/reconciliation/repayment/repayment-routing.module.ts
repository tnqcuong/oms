import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RepaymentListComponent } from './repayment-list/repayment-list.component';
import { RepaymentMatchingComponent } from './repayment-matching/repayment-matching.component';
import { RepaymentReportComponent } from './repayment-report/repayment-report.component';
import { RepaymentUnmatchingComponent } from './repayment-unmatching/repayment-unmatching.component';
import { RepaymentComponent } from './repayment.component';

const routes: Routes = [
  {
    path: '',
    component: RepaymentComponent,
    children: [
      {
        path: '',
        component: RepaymentListComponent
      },
      {
        path: 'report',
        component: RepaymentReportComponent
      },
      {
        path: 'matching',
        component: RepaymentMatchingComponent
      },
      {
        path: 'unmatching',
        component: RepaymentUnmatchingComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RepaymentRoutingModule { }
