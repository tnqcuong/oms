import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-repayment-list',
  templateUrl: './repayment-list.component.html',
  styleUrls: ['./repayment-list.component.sass']
})
export class RepaymentListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) {}

  ngOnInit(): void {}
  goToRepaymentReport(department: number) {
    this.routeStateService.add(
      'Report',
      '/reconciliation/repayment/report',
      department,
      false
    );
  }
  goToRepaymentMatching(department: number) {
    this.routeStateService.add(
      'Matching',
      '/reconciliation/repayment/matching',
      department,
      false
    );
  }
  goToRepaymentUnMatching(department: number) {
    this.routeStateService.add(
      'UnMatching',
      '/reconciliation/repayment/unmatching',
      department,
      false
    );
  }

}
