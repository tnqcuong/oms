import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-repayment',
  templateUrl: './repayment.component.html',
  styleUrls: ['./repayment.component.sass']
})
export class RepaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
