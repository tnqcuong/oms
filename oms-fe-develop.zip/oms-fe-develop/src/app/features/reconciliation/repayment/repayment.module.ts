import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RepaymentRoutingModule } from './repayment-routing.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { RepaymentUnmatchingComponent } from './repayment-unmatching/repayment-unmatching.component';
import { RepaymentMatchingComponent } from './repayment-matching/repayment-matching.component';
import { RepaymentReportComponent } from './repayment-report/repayment-report.component';
import { RepaymentListComponent } from './repayment-list/repayment-list.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [RepaymentListComponent, RepaymentMatchingComponent, RepaymentUnmatchingComponent, RepaymentReportComponent],
  imports: [
    CommonModule,
    AppCommonModule,
    NgxPaginationModule,
    RepaymentRoutingModule,
  ]
})
export class RepaymentModule { }
