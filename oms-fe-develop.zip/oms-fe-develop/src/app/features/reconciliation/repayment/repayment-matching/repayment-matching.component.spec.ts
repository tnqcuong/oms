import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepaymentMatchingComponent } from './repayment-matching.component';

describe('RepaymentMatchingComponent', () => {
  let component: RepaymentMatchingComponent;
  let fixture: ComponentFixture<RepaymentMatchingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepaymentMatchingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepaymentMatchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
