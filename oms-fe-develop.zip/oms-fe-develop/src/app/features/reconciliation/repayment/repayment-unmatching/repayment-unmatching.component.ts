import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { CommonInfo } from 'src/app/core/models/common-info.model';
import { LMSTransaction } from 'src/app/core/models/lms-transaction.model';
import { MatchingTransactionUpdate, TransactionUpdate } from 'src/app/core/models/matching-transaction-update.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';

@Component({
  selector: 'app-repayment-unmatching',
  templateUrl: './repayment-unmatching.component.html',
  styleUrls: ['./repayment-unmatching.component.sass'],
})
export class RepaymentUnmatchingComponent implements OnInit {
  _endDt = new Date();
  _startDt = new Date(this._endDt.getFullYear(), this._endDt.getMonth(), 1);

  _number: number = 100;

  _startBank: number = 1;
  _totalTrxBank: number = 0;

  _startLMS: number = 1;
  _totalTrxLMS: number = 0;

  _bankList: MetaData[] = [];
  _bankTrxStatusList: MetaData[] = [];
  _lmsTrxStatusList: MetaData[] = [];
  _bankSearchTypeList: SearchType[] = [];
  _lmsSearchTypeList: SearchType[] = [];
  selectedBank: string = '';
  bankSelectedSearchType: string = '_ref';
  bankSearchingValue: string = '';
  lmsSelectedSearchType: string = '_ref';
  lmsSearchingValue: string = '';
  isBankCheckAll: boolean = false;
  isLMSCheckAll: boolean = false;
  _showDialog = false;

  items = Array.from({ length: 100000 }).map((_, i) => `Item #${i}`);

  //partner common info
  partnerCommonInfo = new CommonInfo();

  _unMatchBankTrnxList: BankTransaction[] = [];
  _unMatchLMSTrnxList: LMSTransaction[] = [];

  lmsStatusFilterValue: string = '';
  bankStatusFilterValue: string = '';

  bankTrxUpdateList: TransactionUpdate[] = [];
  lmsTrxUpdateList: TransactionUpdate[] = [];

  startIndex: number = 0;
  endIndex: number = 0;

  constructor(
    private reconciliationService: ReconciliationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit(): void {
    this._bankList = this.commonUtilityService.bankList;
    this._bankSearchTypeList = this.commonUtilityService.bankSearchType;
    this._lmsSearchTypeList = this.commonUtilityService.lmsSearchType;
    this._bankTrxStatusList = this.commonUtilityService.bankTrxStatusList;
    this._lmsTrxStatusList = this.commonUtilityService.lmsTrxStatusList;
  }

  fetchPartnerCommonInfo() {
    this.loaderService.onLoading();
    this.reconciliationService
      .getPartnerCommonInfo(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        this.selectedBank
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this.partnerCommonInfo = new CommonInfo();
          } else {
            this.partnerCommonInfo = data.result;
          }

          if (this.partnerCommonInfo.headerData.isBank == 'Y') {
            this._bankTrxStatusList = this.commonUtilityService.bankTrxStatusList;
            this._lmsTrxStatusList = this.commonUtilityService.lmsTrxStatusList;
          } else {
            this._bankTrxStatusList = this.commonUtilityService.nonBankTrxStatusList;
            this._lmsTrxStatusList = this.commonUtilityService.nonLmsTrxStatusList;
          }

          this.fetchUnMatchingTrxForBank();
          this.fetchUnMatchingTrxForLMS();
          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            error.error?.exceptionMessage
              ? error.error?.exceptionMessage
              : 'Server error.'
          );
          this.loaderService.offLoading();
        }
      );
  }

  fetchUnMatchingTrxForBank() {
    this.loaderService.onLoading();
    this.reconciliationService
      .getUnMatchingTransactionForBank(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        this.selectedBank,
        this._number.toString(),
        this._startBank.toString(),
        this.bankSelectedSearchType,
        this.bankSearchingValue,
        this.bankStatusFilterValue
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this._unMatchBankTrnxList = [];
            this._totalTrxBank = 0;
          } else {
            this._unMatchBankTrnxList = this._unMatchBankTrnxList.concat(
              data.result.data
            );
            this._totalTrxBank = data.result.count;
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            error.error?.exceptionMessage
              ? error.error?.exceptionMessage
              : 'Server error.'
          );
          this.loaderService.offLoading();
        }
      );
  }

  fetchUnMatchingTrxForLMS() {
    this.loaderService.onLoading();
    this.reconciliationService
      .getUnMatchingTransactionForLMS(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        this.selectedBank,
        this._number.toString(),
        this._startLMS.toString(),
        this.lmsSelectedSearchType,
        this.lmsSearchingValue,
        this.lmsStatusFilterValue
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this._unMatchLMSTrnxList = [];
            this._totalTrxLMS = 0;
          } else {
            this._unMatchLMSTrnxList = this._unMatchLMSTrnxList.concat(
              data.result.data
            );
            this._totalTrxLMS = data.result.count;
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            error.error?.exceptionMessage
              ? error.error?.exceptionMessage
              : 'Server error.'
          );
          this.loaderService.offLoading();
        }
      );
  }

  searchBankTransaction() {
    if (this.selectedBank === '') {
      this.toastService.addSingleShortTime('warn', '', 'Please select partner');
    } else {
      this._startBank = 1;
      this._unMatchBankTrnxList = [];
      this.fetchPartnerCommonInfo();
    }
  }

  searchLMSTransaction() {
    if (this.selectedBank === '') {
      this.toastService.addSingleShortTime('warn', '', 'Please select partner');
    } else {
      this._startLMS = 1;
      this._unMatchLMSTrnxList = [];
      this.fetchPartnerCommonInfo();
    }
  }

  getUnMatchingTransactionByBank() {
    if (this.selectedBank === '') {
      this.toastService.addSingleShortTime('warn', '', 'Please select partner');
    } else {
      this._startBank = 1;
      this._startLMS = 1;
      //Reset transaction list
      this._unMatchBankTrnxList = [];
      this._unMatchLMSTrnxList = [];
      this.fetchPartnerCommonInfo();
    }
  }

  onBankTableDataChange(event: any) {
    this._startBank = event;
    this.fetchUnMatchingTrxForBank();
  }

  onLMSTableDataChange(event: any) {
    this._startLMS = event;
    this.fetchUnMatchingTrxForLMS();
  }

  updateUnMatchingTrxNote(body: any[]) {
    this.loaderService.onLoading();
    this.reconciliationService.updateReconTrxNote(body).subscribe(
      (data) => {
        this.toastService.addSingleShortTime(
          'info',
          '',
          'Transaction is updated.'
        );
        this._startBank = 1;
        this._unMatchBankTrnxList = [];
        this.fetchPartnerCommonInfo();
        //this.fetchUnMatchingTrxForBank();
        this.loaderService.offLoading();
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          error.error?.exceptionMessage
            ? error.error?.exceptionMessage
            : 'Server error.'
        );
        this.loaderService.offLoading();
      }
    );
  }

  updateUnMatchingLMSTrxNote(body: any[]) {
    this.loaderService.onLoading();
    this.reconciliationService.updateReconTrxNote(body).subscribe(
      (data) => {
        this.toastService.addSingleShortTime(
          'info',
          '',
          'Transaction is updated.'
        );
        this._startBank = 1;
        this._unMatchLMSTrnxList = [];
        this.fetchPartnerCommonInfo();
        //this.fetchUnMatchingTrxForLMS();
        this.loaderService.offLoading();
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          error.error?.exceptionMessage
            ? error.error?.exceptionMessage
            : 'Server error.'
        );
        this.loaderService.offLoading();
      }
    );
  }

  updateUnMatchingTrxStatus(body: any[]) {
    this.loaderService.onLoading();
    this.reconciliationService.updateUnMatchingTrxStatus(body).subscribe(
      (data) => {
        this.toastService.addSingleShortTime(
          'info',
          '',
          'Transaction is updated.'
        );
        //refresh table
        this._startBank = 1;
        this._unMatchBankTrnxList = [];
        this.fetchPartnerCommonInfo();
        //this.fetchUnMatchingTrxForBank();
        this.loaderService.offLoading();
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          error.error?.exceptionMessage
            ? error.error?.exceptionMessage
            : 'Server error.'
        );
        this.loaderService.offLoading();
      }
    );
  }

  updateUnMatchingLMSTrxStatus(body: any[]) {
    this.loaderService.onLoading();
    this.reconciliationService.updateUnMatchingLMSTrxStatus(body).subscribe(
      (data) => {
        this.toastService.addSingleShortTime(
          'info',
          '',
          'Transaction is updated.'
        );
        //refresh Data
        this._startLMS = 1;
        this._unMatchLMSTrnxList = [];
        this.fetchPartnerCommonInfo();
        //this.fetchUnMatchingTrxForLMS();
        this.loaderService.offLoading();
      },
      (error) => {
        console.log('error: ', error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.error?.exceptionMessage
            ? error.error?.exceptionMessage
            : 'Server error.'
        );
        this.loaderService.offLoading();
      }
    );
  }

  updateBankTrxStatus(item: any) {
    this._unMatchBankTrnxList.forEach((unMatchtrx) => {
      if (unMatchtrx.selected) {
        unMatchtrx.statusCode = item.statusCode;
      }
    });
  }

  updateLMSTrxStatus(item: any) {
    this._unMatchLMSTrnxList.forEach((unMatchtrx) => {
      if (unMatchtrx.selected) {
        unMatchtrx.statusCode = item.statusCode;
      }
    });
  }

  buildDataBody(trxList: any[]) {
    let bodyList: any[] = [];
    trxList.forEach((trx) => {
      if (trx.selected) {
        bodyList.push({
          id: trx.id,
          refNo: trx.refNo,
          statusCode: trx.statusCode,
          remarkNote: trx.remarkNote,
        });
      }
    });

    return bodyList;
  }

  updateBankRemarkNoteValue(item: any, event: any) {
    this._unMatchBankTrnxList.forEach((trx) => {
      if (trx.id === item.id) {
        trx.remarkNote = event.target.value;
      } else if (trx.selected) {
        trx.remarkNote = event.target.value;
      }
    });
  }

  updateLMSRemarkNoteValue(item: any, event: any) {
    this._unMatchLMSTrnxList.forEach((trx) => {
      if (trx.id === item.id) {
        trx.remarkNote = event.target.value;
      } else if (trx.selected) {
        trx.remarkNote = event.target.value;
      }
    });
  }

  confirmAndChangeBankStatus(selectedItem: any) {
    // Check status code is DELETE
    if (selectedItem.statusCode == '7') {
      this.confirmationService.confirm({
        message: 'Are you sure that you want to change status to DELETE',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.bankStatusChange(selectedItem);
        },
        reject: () => {
          this._startBank = 1;
          this._unMatchBankTrnxList = [];
          this.fetchPartnerCommonInfo();
          //this.fetchUnMatchingTrxForBank();
        },
      });
    } else {
      this.bankStatusChange(selectedItem);
    }
  }

  confirmAndChangeLMSStatus(selectedItem: any) {
    // Check status code is DELETE
    if (selectedItem.statusCode == '7') {
      this.confirmationService.confirm({
        message: 'Are you sure that you want to change status to DELETE',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.lmsStatusChange(selectedItem);
        },
        reject: () => {
          this._startLMS = 1;
          this._unMatchLMSTrnxList = [];
          this.fetchPartnerCommonInfo();
          //this.fetchUnMatchingTrxForLMS();
        },
      });
    } else {
      this.lmsStatusChange(selectedItem);
    }
  }

  bankStatusChange(selectedItem: any) {
    let body: any[] = [];
    selectedItem.selected = true;
    this.updateBankTrxStatus(selectedItem);

    body = this.buildDataBody(this._unMatchBankTrnxList);
    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        statusCode: selectedItem.statusCode,
      });
    }
    this.updateUnMatchingTrxStatus(body);
  }

  lmsStatusChange(selectedItem: any) {
    let body: any[] = [];

    selectedItem.selected = true;
    this.updateLMSTrxStatus(selectedItem);
    body = this.buildDataBody(this._unMatchLMSTrnxList);
    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        statusCode: selectedItem.statusCode,
      });
    }
    this.updateUnMatchingLMSTrxStatus(body);
  }

  bankRemarkNoteChange(selectedItem: any, event: any) {
    let body: any[] = [];
    this.updateBankRemarkNoteValue(selectedItem, event);

    this._unMatchBankTrnxList.forEach((trx) => {
      if (trx.selected) {
        body.push({
          id: trx.id,
          remarkNote: event.target.value,
          type: 'STMT',
        });
      }
    });

    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        remarkNote: event.target.value,
        type: 'STMT',
      });
    }

    console.log('body: ', body);

    this.updateUnMatchingTrxNote(body);
  }

  lmsRemarkNoteChange(selectedItem: any, event: any) {
    let body: any[] = [];
    this.updateLMSRemarkNoteValue(selectedItem, event);
    this._unMatchLMSTrnxList.forEach((trx) => {
      if (trx.selected) {
        body.push({
          id: trx.id,
          remarkNote: event.target.value,
          type: 'LMS',
        });
      }
    });

    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        remarkNote: event.target.value,
        type: 'LMS',
      });
    }
    this.updateUnMatchingLMSTrxNote(body);
  }

  selectBankTransaction(item: any, event: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._unMatchBankTrnxList[i].selected = true;
        }
      } else {
        this._unMatchBankTrnxList.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._unMatchBankTrnxList.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectLMSTransaction(item: any, event: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._unMatchLMSTrnxList[i].selected = true;
        }
      } else {
        this._unMatchLMSTrnxList.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._unMatchLMSTrnxList.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
      // if(event.shiftKey){
      //   this.endIndex = i;
      //   if(this.startIndex > this.endIndex){
      //     [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
      //   }
      //   for(let i = this.startIndex; i <= this.endIndex; i++){
      //     this._unMatchLMSTrnxList[i].selected = false;
      //   }
      // }
      // else {
      //   this._unMatchLMSTrnxList.forEach((trx) => {
      //     if (trx.id === item.id) {
      //       trx.selected = false;
      //     }
      //   });
      // }
      // this.startIndex = i;
    }
  }

  validateUpdateTrxList(
    bankTrxList: TransactionUpdate[],
    lmsTrxList: TransactionUpdate[]
  ) {
    let flag = false;

    let trxList = bankTrxList.concat(lmsTrxList);
    let initStatus = trxList[0].statusCode;

    if (initStatus == 1 || initStatus == 6 || initStatus == 8) {
      flag = true;
    }

    for (let i = 1; i < trxList.length; i++) {
      if (trxList[i].statusCode != initStatus) {
        flag = false;
        break;
      }
    }

    return flag;
  }

  updateMatchingTransaction(trxUpdateList: any[]) {
    this.loaderService.onLoading();
    this.reconciliationService
      .updateMatchingTrxStatus('false', trxUpdateList)
      .subscribe(
        (data) => {
          this.toastService.addSingleShortTime(
            'info',
            '',
            'Transactions is updated.'
          );
          this._startBank = 1;
          this._startLMS = 1;
          this._unMatchBankTrnxList = [];
          this._unMatchLMSTrnxList = [];
          this.fetchPartnerCommonInfo();
          // this.fetchUnMatchingTrxForBank();
          // this.fetchUnMatchingTrxForLMS();
          this.loaderService.offLoading();
          this.hideDialog();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            error.error?.exceptionMessage
              ? error.error?.exceptionMessage
              : 'Server error.'
          );
          this.loaderService.offLoading();
        }
      );
  }

  updateTrxList() {
    let trxUpdate = new MatchingTransactionUpdate();
    let trxUpdateList = [];

    for (let i = 0; i < this.bankTrxUpdateList.length; i++) {
      for (let j = 0; j < this.lmsTrxUpdateList.length; j++) {
        trxUpdate.bankStatemenTrxInfo.id = this.bankTrxUpdateList[i].id;
        trxUpdate.bankStatemenTrxInfo.statusCode = this.bankTrxUpdateList[
          i
        ].statusCode;
        trxUpdate.bankStatemenTrxInfo.remarkNote = this.bankTrxUpdateList[
          i
        ].remarkNote;
        trxUpdate.lmsTrxInfo.id = this.lmsTrxUpdateList[j].id;
        trxUpdate.lmsTrxInfo.statusCode = this.lmsTrxUpdateList[j].statusCode;
        trxUpdate.lmsTrxInfo.remarkNote = this.lmsTrxUpdateList[j].remarkNote;
        trxUpdateList.push(trxUpdate);
      }
    }

    if (
      !this.validateUpdateTrxList(this.bankTrxUpdateList, this.lmsTrxUpdateList)
    ) {
      this.toastService.addSingle(
        'warn',
        '',
        'Transaction status must be similar.'
      );
    } else {
      this.confirmUpdateTrx(trxUpdateList);
    }
  }

  confirmUpdateTrx(trxUpdateList: any) {
    this.confirmationService.confirm({
      message: 'Are you sure to update Matching Transaction?',
      header: 'Confirmation Update',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.updateMatchingTransaction(trxUpdateList);
      },
      reject: () => {},
    });
  }

  checkBankAll(event: any) {
    if (event.target.checked) {
      this.isBankCheckAll = true;
      this._unMatchBankTrnxList.forEach((trx) => (trx.selected = true));
    } else {
      this.isBankCheckAll = false;
      this._unMatchBankTrnxList.forEach((trx) => (trx.selected = false));
    }
  }

  checkLMSAll(event: any) {
    if (event.target.checked) {
      this.isLMSCheckAll = true;
      this._unMatchLMSTrnxList.forEach((trx) => (trx.selected = true));
    } else {
      this.isLMSCheckAll = false;
      this._unMatchLMSTrnxList.forEach((trx) => (trx.selected = false));
    }
  }

  hideDialog() {
    this._showDialog = false;
  }

  changeToMatchedStatus(trxList: TransactionUpdate[]) {
    trxList.forEach((trx) => {
      trx.statusCode = 1;
    });
  }

  showDialog() {
    this.bankTrxUpdateList = [];
    this.lmsTrxUpdateList = [];
    this.bankTrxUpdateList = this.buildDataBody(this._unMatchBankTrnxList);
    this.lmsTrxUpdateList = this.buildDataBody(this._unMatchLMSTrnxList);
    this.changeToMatchedStatus(this.bankTrxUpdateList);
    this.changeToMatchedStatus(this.lmsTrxUpdateList);

    if (this.bankTrxUpdateList.length === 0) {
      this.toastService.addSingle(
        'error',
        '',
        'Bank Transaction needs to select also.'
      );
    } else if (this.bankTrxUpdateList.length > 1) {
      this.toastService.addSingle(
        'error',
        '',
        'Cannot select multi Bank Transaction.'
      );
    } else if (this.lmsTrxUpdateList.length === 0) {
      this.toastService.addSingle(
        'error',
        '',
        'LMS Transaction needs to select also.'
      );
    } else {
      this._showDialog = true;
    }
  }

  filterBankTrx() {
    this._startBank = 1;
    this._unMatchBankTrnxList = [];
    this.fetchUnMatchingTrxForBank();
  }

  filterLMSTrx() {
    this._startLMS = 1;
    this._unMatchLMSTrnxList = [];
    this.fetchUnMatchingTrxForLMS();
  }

  onScrollBank(event: any) {
    if (
      event.target.offsetHeight + event.target.scrollTop >=
      event.target.scrollHeight
    ) {
      if (this._startBank < this._totalTrxBank / this._number) {
        this._startBank++;
        this.fetchUnMatchingTrxForBank();
      }
    }
  }

  onScrollLMS(event: any) {
    if (
      event.target.offsetHeight + event.target.scrollTop >=
      event.target.scrollHeight
    ) {
      if (this._startLMS < this._totalTrxLMS / this._number) {
        this._startLMS++;
        this.fetchUnMatchingTrxForLMS();
      }
    }
  }
}
