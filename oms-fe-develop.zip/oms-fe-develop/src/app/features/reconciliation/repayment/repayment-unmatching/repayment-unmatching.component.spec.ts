import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepaymentUnmatchingComponent } from './repayment-unmatching.component';

describe('RepaymentUnmatchingComponent', () => {
  let component: RepaymentUnmatchingComponent;
  let fixture: ComponentFixture<RepaymentUnmatchingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepaymentUnmatchingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepaymentUnmatchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
