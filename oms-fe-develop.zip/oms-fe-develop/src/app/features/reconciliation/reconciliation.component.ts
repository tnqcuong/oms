import { Component, OnInit } from '@angular/core';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { ReconciliationService } from './reconciliation.service';

@Component({
  selector: 'app-reconciliation',
  templateUrl: './reconciliation.component.html',
  styleUrls: ['./reconciliation.component.sass']
})
export class ReconciliationComponent implements OnInit {

  constructor(
    private commonUtilityService: CommonUtilityService,
    private reconciliationService: ReconciliationService
  ) { }

  ngOnInit(): void {}

}
