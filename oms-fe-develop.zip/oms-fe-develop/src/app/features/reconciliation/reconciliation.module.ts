import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReconciliationRoutingModule } from './reconciliation-routing.module';
import { ReconciliationComponent } from './reconciliation.component';
import { ReconciliationListComponent } from './reconciliation-list/reconciliation-list.component';
import { DisbursementComponent } from './disbursement/disbursement.component';
import { ReconciliationDataCheckingComponent } from './reconciliation-data-checking/reconciliation-data-checking.component';
import { RepaymentComponent } from './repayment/repayment.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ReconciliationComponent,
    ReconciliationListComponent,
    DisbursementComponent,
    ReconciliationDataCheckingComponent,
    RepaymentComponent,
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ReconciliationRoutingModule
  ]
})
export class ReconciliationModule { }
