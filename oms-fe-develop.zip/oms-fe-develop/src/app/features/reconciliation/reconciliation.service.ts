import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { SessionService } from 'src/app/core/services/session.service';
import { environment } from 'src/environments/environment';
import { environmentAPI, environmentAPI_Recon } from 'src/environments/environmentAPI';

@Injectable({
  providedIn: 'root'
})
export class ReconciliationService {

  constructor(
    private http: HttpClient,
    private commonUtilityService: CommonUtilityService
  ) {}

  getMatchingTransactionByBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchValue: string
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (searchType === '_ref') {
      params = params.set('_ref', searchValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI_Recon.repaymentMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getTransactionMatching( startDt: any, endDt: any, bankCode: any, number: any, start: any): Observable<any> {
    return this.getMatchingTransactionByBank(startDt, endDt, bankCode, number, start, '', '');
  }

  updateMatchingTrxStatus(
    isUnMatch: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_isUnmatch', isUnMatch);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl + environmentAPI_Recon.repaymentMatchingTrx,
      body,
      { headers: headerParams, params: params }
    );
  }

  updateDisbMatchingTrxStatus(
    isUnMatch: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_isUnmatch', isUnMatch);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl + environmentAPI_Recon.disbursalMatchingTrx,
      body,
      { headers: headerParams, params: params }
    );
  }

  getUnMatchingTransactionForBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI_Recon.repaymentUnMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  updateUnMatchingTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI_Recon.repaymentUnMatchingTrx,
      body,
      { headers: headerParams }
    );
  }

  updateDisbUnMatchingTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI_Recon.disbursalUnMatchingTrx,
      body,
      { headers: headerParams }
    );
  }

  updateReconTrxNote(dataUpdate: any[]): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI_Recon.updateReconTrxNote,
      body,
      { headers: headerParams }
    );
  }

  //Get transactions has status code is '2'
  getAllPendingTransaction(
    startDt: string,
    endDt: string,
    bankCode: string,
    number: string,
    start: string,
  ): Observable<any> {
    if(this.commonUtilityService.isDisbPartner(bankCode)){
      return this.getDisbUnMatchingTransactionForBank(startDt, endDt, bankCode, number, start, '', '', '2');
    }

    return this.getUnMatchingTransactionForBank(startDt, endDt, bankCode, number, start, '', '', '2');
  }

  getTransactionPendingBank(
    _startDt: any,
    _endDt: any,
    _bankCode: any,
    _number: any,
    _start: any
  ): Observable<any> {

    return this.getUnMatchingTransactionForBank(_startDt, _endDt, _bankCode, _number, _start, '', '', '');
  }

  getUnMatchingTransactionForLMS(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchValue);
    }


    return this.http.get<any>(
      environment.apiUrl + environmentAPI_Recon.unMatchingLMSTrx,
      { headers: headerParams, params: params }
    );
  }

  updateUnMatchingLMSTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI_Recon.unMatchingLMSTrx,
      body,
      { headers: headerParams }
    );
  }

  getDisbTransactionPendingLMS(
    startDt: any,
    endDt: any,
    bankCode: any,
    number: any,
    start: any
  ): Observable<any> {

    return this.getUnMatchingTransactionForLMS(startDt, endDt, bankCode, number, start, '', '', '');
  }

  getTransactionPendingLMS(
    startDt: any,
    endDt: any,
    bankCode: any,
    number: any,
    start: any
  ): Observable<any> {

    return this.getUnMatchingTransactionForLMS(startDt, endDt, bankCode, number, start, '', '', '');
  }

  getPartnerCommonInfo(
    _startDt: string,
    _endDt: string,
    _bankCode: string
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);

    return this.http.get<any>(
      environment.apiUrl + environmentAPI_Recon.partnerCommonInfo,
      { headers: headerParams, params: params }
    );
  }

  getMatchingTransaction(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchValue: string
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (searchType === '_ref') {
      params = params.set('_ref', searchValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI_Recon.disbursalMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getDisbTransactionMatching(
    startDt: any,
    endDt: any,
    bankCode: any,
    number: any,
    start: any
  ): Observable<any> {
    return this.getMatchingTransaction(startDt, endDt, bankCode, number, start, '', '')
  }

  getDisbUnMatchingTransactionForBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI_Recon.disbursalUnMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  // getDisbTransactionPendingBank(
  //   startDt: any,
  //   endDt: any,
  //   bankCode: any,
  //   number: any,
  //   start: any
  // ): Observable<any> {
  //   return this.getDisbUnMatchingTransactionForBank(startDt, endDt, bankCode, number, start, '', '', '');
  // }


  PostRetryBank(params_bankCode: any): Observable<any> {
    let headers = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI_Recon.reTry,
      {},
      {
        headers: headers,
        params: params,
      }
    );
  }

  downloadFile(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any
  ): Observable<any> {
    let headers = this.commonUtilityService.getPDFHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI_Recon.report,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  getDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
    _type: string
  ): Observable<any>{

    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_trxDt', _trxDt);
    params = params.set('_type', _type);

    return this.http.get<any>(environment.apiUrl + environmentAPI_Recon.reconDailyReport,
      { headers: headerParams, params: params });
  }

  getReconSummary(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '1');
  }

  getOPSRepaymentDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '3');
  }

  getOPSDisbursalDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '2');
  }

  getRepaymentDailyCollectionReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '5');
  }

  getDisbursalDailyCollectionReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '4');
  }

  getSuspenseReport(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    _type: string,
    _searchType: string,
    _searchValue: string,
    _confirm_yn: string
  ): Observable<any>{

    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_type', _type);
    params = params.set('_confirm_yn', _confirm_yn);

    if (_searchType === '_ref') {
      params = params.set('_ref', _searchValue);
    } else if (_searchType === '_loanNo') {
      params = params.set('_loanNo', _searchValue);
    }

    return this.http.get<any>(environment.apiUrl + environmentAPI_Recon.reconSuspenseReport,
      { headers: headerParams, params: params });
  }

  getWriteOffReport(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    _type: string,
    _searchType: string,
    _searchValue: string,
    _confirm_yn: string
  ): Observable<any>{
    return this.getSuspenseReport(_startDt, _endDt, _bankCode, _number, _start, _type, _searchType, _searchValue, _confirm_yn);
  }

  updateSuspenseTrxStatus(
    _isConfirm: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_isConfirm', _isConfirm);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl + environmentAPI_Recon.reconSuspenseReport,
      body,
      { headers: headerParams, params: params }
    );
  }

  getDataCheckingList(): Observable<any>{
    let headerParams = this.commonUtilityService.getHeaderParams();

    return this.http.get<any>(environment.apiUrl + environmentAPI_Recon.dataChecking, { headers: headerParams });
  }

  exportPendingReport(
    _startDt: any,
    _endDt: any,
    _bankCode: any
  ): Observable<any> {
    let headers = this.commonUtilityService.getPDFHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI_Recon.exportPendingReport,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  exportDailyReport(
    _trxDt: any,
  ): Observable<any> {
    let headers = this.commonUtilityService.getPDFHeaderParams();

    let params = new HttpParams();
    params = params.set('_trxDt', _trxDt);
    return this.http.post(
      environment.apiUrl + environmentAPI_Recon.exportDailyReport,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

   /**
    *
    * @param startDt
    * @param endDt
    * @param type: 1 - suspense report; 2 - writeoff report
    * @returns
    */


  exportSuspenseReport(
    startDt: string,
    endDt: string,
    bankCode: string,
    type: string
  ): Observable<any> {
    let headers = this.commonUtilityService.getPDFHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', startDt);
    params = params.set('_endDt', endDt);
    params = params.set('_bankCode', bankCode);
    params = params.set('_type', type);
    return this.http.post(
      environment.apiUrl + environmentAPI_Recon.exportSuspenseReport,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  exportWriteoffReport(
    startDt: string,
    endDt: string,
    bankCode: string,
  ){
    return this.exportSuspenseReport(startDt, endDt, bankCode, '2');
  }

}
