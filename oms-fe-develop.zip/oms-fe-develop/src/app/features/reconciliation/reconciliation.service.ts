import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SessionService } from 'src/app/core/services/session.service';
import { ThemeService } from 'src/app/core/services/theme.service';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';

@Injectable({
  providedIn: 'root'
})
export class ReconciliationService {

  user = this.sessionService.getItem('currentUser');

  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {}

  GetMetaDataBank(): Observable<any> {
    return this.http.get<any>(environment.apiUrl + environmentAPI.metadata);
  }

  getHeaderParams() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'access-token': this.user.token,
    });
  }

  getMatchingTransactionByBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.repaymentMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getTransactionMatching( startDt: any, endDt: any, bankCode: any, number: any, start: any): Observable<any> {
    return this.getMatchingTransactionByBank(startDt, endDt, bankCode, number, start, '', '');
  }

  updateMatchingTrxStatus(
    isUnMatch: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_isUnmatch', isUnMatch);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.repaymentMatchingTrx,
      body,
      { headers: headerParams, params: params }
    );
  }

  getUnMatchingTransactionForBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.repaymentUnMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  updateUnMatchingTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.repaymentUnMatchingTrx,
      body,
      { headers: headerParams }
    );
  }

  getAllPendingTransaction(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    statusFilterValue: string
  ): Observable<any> {

    return this.getUnMatchingTransactionForBank(_startDt, _endDt, _bankCode, _number, _start, '', '', statusFilterValue);
  }

  getTransactionPendingBank(
    _startDt: any,
    _endDt: any,
    _bankCode: any,
    _number: any,
    _start: any
  ): Observable<any> {

    return this.getUnMatchingTransactionForBank(_startDt, _endDt, _bankCode, _number, _start, '', '', '');
  }

  getUnMatchingTransactionForLMS(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }


    return this.http.get<any>(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      { headers: headerParams, params: params }
    );
  }

  updateUnMatchingLMSTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      body,
      { headers: headerParams }
    );
  }

  getDisbTransactionPendingLMS(
    startDt: any,
    endDt: any,
    bankCode: any,
    number: any,
    start: any
  ): Observable<any> {

    return this.getUnMatchingTransactionForLMS(startDt, endDt, bankCode, number, start, '', '', '');
  }

  getTransactionPendingLMS(
    startDt: any,
    endDt: any,
    bankCode: any,
    number: any,
    start: any
  ): Observable<any> {

    return this.getUnMatchingTransactionForLMS(startDt, endDt, bankCode, number, start, '', '', '');
  }

  getPartnerCommonInfo(
    _startDt: string,
    _endDt: string,
    _bankCode: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.partnerCommonInfo,
      { headers: headerParams, params: params }
    );
  }

  getMatchingTransaction(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.disbursalMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getDisbTransactionMatching(
    startDt: any,
    endDt: any,
    bankCode: any,
    number: any,
    start: any
  ): Observable<any> {
    return this.getMatchingTransaction(startDt, endDt, bankCode, number, start, '', '')
  }

  getDisbUnMatchingTransactionForBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.disbursalUnMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getDisbTransactionPendingBank(
    startDt: any,
    endDt: any,
    bankCode: any,
    number: any,
    start: any
  ): Observable<any> {
    return this.getDisbUnMatchingTransactionForBank(startDt, endDt, bankCode, number, start, '', '', '');
  }


  PostRetryBank(params_bankCode: any): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI.reTry,
      {},
      {
        headers: headers,
        params: params,
      }
    );
  }

  downloadFile(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI.report,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  getDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
    _type: string
  ): Observable<any>{

    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_trxDt', _trxDt);
    params = params.set('_type', _type);

    return this.http.get<any>(environment.apiUrl + environmentAPI.reconDailyReport,
      { headers: headerParams, params: params });
  }

  getReconSummary(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '1');
  }

  getOPSRepaymentDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '2');
  }

  getOPSDisbursalDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{
    return this.getDailyReport(_startDt, _endDt, _trxDt, '3');
  }

  getSuspenseReport(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    _type: string,
    _loanNo: string,
    _confirm_yn: string
  ): Observable<any>{

    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_type', _type);
    params = params.set('_loanNo', _loanNo);
    params = params.set('_confirm_yn', _confirm_yn);

    return this.http.get<any>(environment.apiUrl + environmentAPI.reconSuspenseReport,
      { headers: headerParams, params: params });
  }

  getWriteOffReport(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    _type: string,
    _loanNo: string,
    _confirm_yn: string
  ): Observable<any>{
    return this.getSuspenseReport(_startDt, _endDt, _bankCode, _number, _start, _type, _loanNo, _confirm_yn);
  }

  updateSuspenseTrxStatus(
    _isConfirm: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_isConfirm', _isConfirm);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.reconSuspenseReport,
      body,
      { headers: headerParams, params: params }
    );
  }

  getDataCheckingList(): Observable<any>{
    let headerParams = this.getHeaderParams();

    return this.http.get<any>(environment.apiUrl + environmentAPI.dataChecking, { headers: headerParams });
  }
}
