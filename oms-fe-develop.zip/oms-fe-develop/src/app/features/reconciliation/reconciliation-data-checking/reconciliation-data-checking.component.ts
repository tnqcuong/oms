import { Component, OnInit } from '@angular/core';
import { DataChecking } from 'src/app/core/models/data-checking.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../reconciliation.service';

@Component({
  selector: 'app-reconciliation-data-checking',
  templateUrl: './reconciliation-data-checking.component.html',
  styleUrls: ['./reconciliation-data-checking.component.sass']
})
export class ReconciliationDataCheckingComponent implements OnInit {

  _dataCheckingList: DataChecking[] = [];
  uploadFileStatusList: MetaData[] = [];

  constructor(
    private reconciliationService: ReconciliationService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService,
    private toastService: ToastService,

  ) {}

  ngOnInit(): void {
    this.uploadFileStatusList = this.commonUtilityService.uploadFileStatusList;
    this.fetchDataCheckingList();
  }

  removeDeletedRecord(){
    for(let i = this._dataCheckingList.length - 1; i >= 0 ; i--){
      if(this._dataCheckingList[i].fileStatus == 20){
        this._dataCheckingList.splice(i,1);
      }
    }
  }

  fetchDataCheckingList() {
    this.loaderService.onLoading();
    this.reconciliationService.getDataCheckingList().subscribe(
      (data) => {
        if(data.result.data){
          this._dataCheckingList = data.result.data;
          this.removeDeletedRecord();
        }
         this.loaderService.offLoading();
      },
      (error) => {
        this.toastService.addSingle('error', 'Error', error.exceptionMessage ? error.exceptionMessage : 'Server error.');
        this.loaderService.offLoading();
      }
    );
  }
  getStatusValue(codeId: number) {
    for (let i = 0; i < this.uploadFileStatusList.length; i++) {
      if (this.uploadFileStatusList[i].lookupCodeId === codeId.toString()) {
        return this.uploadFileStatusList[i].value;
      }
    }
    return '';
  }

}
