import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-disbursement-list',
  templateUrl: './disbursement-list.component.html',
  styleUrls: ['./disbursement-list.component.sass']
})
export class DisbursementListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) {}

  ngOnInit(): void {}
  goToDisbursalReport(department: number) {
    this.routeStateService.add(
      'Report',
      '/reconciliation/disbursement/report',
      department,
      false
    );
  }
  goToDisbursalMatching(department: number) {
    this.routeStateService.add(
      'Matching',
      '/reconciliation/disbursement/matching',
      department,
      false
    );
  }
  goToDisbursalUnMatching(department: number) {
    this.routeStateService.add(
      'UnMatching',
      '/reconciliation/disbursement/unmatching',
      department,
      false
    );
  }
}
