import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisbursementUnmatchingComponent } from './disbursement-unmatching.component';

describe('DisbursementUnmatchingComponent', () => {
  let component: DisbursementUnmatchingComponent;
  let fixture: ComponentFixture<DisbursementUnmatchingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisbursementUnmatchingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisbursementUnmatchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
