import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DisbursementRoutingModule } from './disbursement-routing.module';
import { DisbursementListComponent } from './disbursement-list/disbursement-list.component';
import { DisbursementReportComponent } from './disbursement-report/disbursement-report.component';
import { DisbursementMatchingComponent } from './disbursement-matching/disbursement-matching.component';
import { DisbursementUnmatchingComponent } from './disbursement-unmatching/disbursement-unmatching.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    DisbursementListComponent,
    DisbursementReportComponent,
    DisbursementMatchingComponent,
    DisbursementUnmatchingComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    NgxPaginationModule,
    DisbursementRoutingModule
  ]
})
export class DisbursementModule { }
