import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DisbursementListComponent } from './disbursement-list/disbursement-list.component';
import { DisbursementMatchingComponent } from './disbursement-matching/disbursement-matching.component';
import { DisbursementReportComponent } from './disbursement-report/disbursement-report.component';
import { DisbursementUnmatchingComponent } from './disbursement-unmatching/disbursement-unmatching.component';
import { DisbursementComponent } from './disbursement.component';

const routes: Routes = [
  {
    path: '',
    component: DisbursementComponent,
    children: [
      {
        path: '',
        component: DisbursementListComponent
      },
      {
        path: 'report',
        component: DisbursementReportComponent
      },
      {
        path: 'matching',
        component: DisbursementMatchingComponent
      },
      {
        path: 'unmatching',
        component: DisbursementUnmatchingComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DisbursementRoutingModule { }
