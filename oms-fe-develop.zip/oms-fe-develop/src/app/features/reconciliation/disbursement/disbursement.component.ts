import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disbursement',
  templateUrl: './disbursement.component.html',
  styleUrls: ['./disbursement.component.sass']
})
export class DisbursementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
