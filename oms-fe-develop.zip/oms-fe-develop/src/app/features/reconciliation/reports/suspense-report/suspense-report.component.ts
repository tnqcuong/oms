import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { SuspenseReport } from 'src/app/core/models/suspense-report.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';
import * as file from 'file-saver';

@Component({
  selector: 'app-suspense-report',
  templateUrl: './suspense-report.component.html',
  styleUrls: ['./suspense-report.component.sass']
})
export class SuspenseReportComponent implements OnInit {

  _today = new Date();
  _startDt = this.commonUtilityService.getStartDateOfMonth(this._today);
  _endDt = this._today;
  _num = '100';
  _start = '1';

  _bankList: MetaData[] = [];
  _searchTypeList: SearchType[] = [];
  suspenseStatusList: MetaData[] = [];
  selectedBank: string = '';

  selectedSearchType: string = '_ref';
  searchingValue: string = '';

  suspensePendingData: SuspenseReport[] = [];
  suspenseDoneData: SuspenseReport[] = [];
  bookIncomeData: SuspenseReport[] = [];

  startIndex: number = 0;
  endIndex: number = 0;

  constructor(
    private reconciliationService: ReconciliationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService,
    private confirmationService: ConfirmationService,
  ) {
    this._bankList = commonUtilityService.allPartnerList;
    this._searchTypeList = commonUtilityService.reconReportSearchType;
    this.suspenseStatusList = commonUtilityService.suspenseStatusList;
  }

  ngOnInit(): void {}

  fetchSuspenseReport(){
    this.loaderService.onLoading();
    this.reconciliationService
    .getSuspenseReport(
      moment(this._startDt).format('DD/MM/YYYY'),
      moment(this._endDt).format('DD/MM/YYYY'),
      this.selectedBank,
      this._num,
      this._start,
      '1',
      this.selectedSearchType,
      this.searchingValue,
      ''
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.suspensePendingData = []
          this.suspenseDoneData = []
          this.bookIncomeData = []
        if(this.commonUtilityService.isEmptyObj(data.result)){
          this.toastService.addSingle(
            'info',
            '',
            'No Data.'
          );

        }
        else {
          for(let i = 0; i < data.result.data.length; i++){
            if(data.result.data[i].status == 2){
              this.suspensePendingData.push(data.result.data[i]);
            }
            if(data.result.data[i].status == 1){
              this.suspenseDoneData.push(data.result.data[i]);
            }
            if(data.result.data[i].status == 4){
              this.bookIncomeData.push(data.result.data[i]);
            }
          }
        }
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          'Error',
          error.error?.exceptionMessage
            ? error.error?.exceptionMessage
            : 'Server error.'
        );
      }
    );
  }

  updateTransactions(dataUpdate: any[]){
    this.reconciliationService
    .updateSuspenseTrxStatus(
      'false',
      dataUpdate
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.fetchSuspenseReport();
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          'Error',
          error.error?.exceptionMessage
            ? error.error?.exceptionMessage
            : 'Server error.'
        );
      }
    );
  }

  confirmTransactions(dataUpdate: any[]){
    this.reconciliationService
    .updateSuspenseTrxStatus(
      'true',
      dataUpdate
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.fetchSuspenseReport();
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          'Error',
          error.error?.exceptionMessage
            ? error.error?.exceptionMessage
            : 'Server error.'
        );
      }
    );
  }

  buildStatusDataUpdate(suspenseData: SuspenseReport[], data: any){
    let dataUpdate = [];

    for (let i = 0; i < suspenseData.length; i++){
      if(suspenseData[i].selected){
        dataUpdate.push({
          "id" : suspenseData[i].id,
          "remarkNote": suspenseData[i].remarkNote,
          "status": data.status
        })
      }
    }

    return dataUpdate;
  }

  buildRemarkNoteDataUpdate(suspenseData: SuspenseReport[], event: any){
    let dataUpdate = [];

    for (let i = 0; i < suspenseData.length; i++){
      if(suspenseData[i].selected){
        dataUpdate.push({
          "id" : suspenseData[i].id,
          "remarkNote": event.target.value,
          "status": suspenseData[i].status
        })
      }
    }

    return dataUpdate;
  }

  changeSuspensePendingStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.suspensePendingData, data);
    this.updateTransactions(dataUpdate);
  }

  changeSuspenseDoneStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.suspenseDoneData, data);
    this.updateTransactions(dataUpdate);
  }

  changeBookIncomeStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.bookIncomeData, data);
    this.updateTransactions(dataUpdate);
  }

  changeSuspensePendingRemarkNote(data: any, event: any) {
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.suspensePendingData, event);
    this.updateTransactions(dataUpdate);
  }

  changeSuspenseDoneRemarkNote(data: any, event: any) {

    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.suspenseDoneData, event);
    this.updateTransactions(dataUpdate);
  }

  changeBookIncomeRemarkNote(data: any, event: any) {
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.bookIncomeData, event);
    this.updateTransactions(dataUpdate);
  }

  selectDate(){
    if (this.selectedBank !== '') {
      this.fetchSuspenseReport();
    }
  }

  selectPartner(){
    if (this.selectedBank === '') {
      this.toastService.addSingleShortTime('warn', '', 'Please select partner');
    } else {
      this.fetchSuspenseReport();
    }
  }


  searchSuspenseTransaction(){
    if (this.selectedBank === '') {
      this.toastService.addSingleShortTime('warn', '', 'Please select partner');
    } else {
      this.fetchSuspenseReport();
    }
  }

  confirmSuspenseTrx(){
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Status',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.executingConfirmSuspenseTrx();
      },
      reject: () => {
        this.toastService.addSingleShortTime(
          'info',
          'Rejected',
          'You have rejected'
        );
      },
    });
  }

  executingConfirmSuspenseTrx(){
    let confirmDataUpdate= [];
    for(let i = 0; i < this.suspensePendingData.length; i++){
      if(this.suspensePendingData[i].selected){
        confirmDataUpdate.push({
          "id" : this.suspensePendingData[i].id
        })
      }
    }

    this.confirmTransactions(confirmDataUpdate);
  }

  selectSuspensePendingTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.suspensePendingData[i].selected = true;
        }
      }
      else {
        this.suspensePendingData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.suspensePendingData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectSuspenseDoneTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.suspenseDoneData[i].selected = true;
        }
      }
      else {
        this.suspenseDoneData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.suspenseDoneData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectBookIncomeTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.bookIncomeData[i].selected = true;
        }
      }
      else {
        this.bookIncomeData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.bookIncomeData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  confirmAndExport(){
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Excel',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.exportSuspenseReport();
      },
      reject: () => {
        this.toastService.addSingleShortTime(
          'info',
          'Rejected',
          'You have rejected'
        );
      },
    });
  }

  exportSuspenseReport(){
    this.loaderService.onLoading();
    this.reconciliationService
      .exportSuspenseReport(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        '1'
        ).subscribe(
        (response) => {
          this.downloadFile(response.body);
          this.loaderService.offLoading();
        },
        (error) => {
          console.log(error);
          this.loaderService.offLoading();
        }
      );
  }

  downloadFile(data: any) {
    const fileName = 'Suspense_Report';
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + this._today);
  }

}
