import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuspenseReportComponent } from './suspense-report.component';

describe('SuspenseReportComponent', () => {
  let component: SuspenseReportComponent;
  let fixture: ComponentFixture<SuspenseReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuspenseReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuspenseReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
