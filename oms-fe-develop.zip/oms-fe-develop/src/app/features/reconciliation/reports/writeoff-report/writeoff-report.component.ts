import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { SuspenseReport } from 'src/app/core/models/suspense-report.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';
import * as file from 'file-saver';

@Component({
  selector: 'app-writeoff-report',
  templateUrl: './writeoff-report.component.html',
  styleUrls: ['./writeoff-report.component.sass']
})
export class WriteoffReportComponent implements OnInit {

  _today = new Date();
  _startDt = this.commonUtilityService.getStartDateOfMonth(this._today);
  _endDt = this._today;
  _num = '100';
  _start = '1';

  _bankList: MetaData[] = [];
  _searchTypeList: SearchType[] = [];
  writeoffStatusList: MetaData[] = [];
  selectedBank: string = '';

  searchingValue: string = '';
  selectedSearchType: string = '_ref';

  writeoffPendingData: SuspenseReport[] = [];
  writeoffDoneData: SuspenseReport[] = [];
  bookIncomeData: SuspenseReport[] = [];

  startIndex: number = 0;
  endIndex: number = 0;

  constructor(
    private reconciliationService: ReconciliationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService,
    private confirmationService: ConfirmationService,
  ) {
    this._bankList = commonUtilityService.allPartnerList;
    this._searchTypeList = commonUtilityService.reconReportSearchType;
    this.writeoffStatusList = commonUtilityService.suspenseStatusList;
  }

  ngOnInit(): void {}

  fetchWriteOffReport(){
    this.loaderService.onLoading();
    this.reconciliationService
    .getWriteOffReport(
      moment(this._startDt).format('DD/MM/YYYY'),
      moment(this._endDt).format('DD/MM/YYYY'),
      this.selectedBank,
      this._num,
      this._start,
      '2',
      this.selectedSearchType,
      this.searchingValue,
      ''
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.writeoffPendingData = []
          this.writeoffDoneData = []
          this.bookIncomeData = []
        if(this.commonUtilityService.isEmptyObj(data.result)){
          this.toastService.addSingle(
            'info',
            '',
            'No Data.'
          );

        }
        else {
          for(let i = 0; i < data.result.data.length; i++){
            if(data.result.data[i].status == 2){
              this.writeoffPendingData.push(data.result.data[i]);
            }
            if(data.result.data[i].status == 1){
              this.writeoffDoneData.push(data.result.data[i]);
            }
            if(data.result.data[i].status == 4){
              this.bookIncomeData.push(data.result.data[i]);
            }
          }
        }
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }

  updateTransactions(dataUpdate: any[]){
    this.reconciliationService
    .updateSuspenseTrxStatus(
      'false',
      dataUpdate
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.fetchWriteOffReport();
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }

  confirmTransactions(dataUpdate: any[]){
    this.reconciliationService
    .updateSuspenseTrxStatus(
      'true',
      dataUpdate
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.fetchWriteOffReport();
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }

  buildStatusDataUpdate(writeOffData: SuspenseReport[], data: any){
    let dataUpdate = [];

    for (let i = 0; i < writeOffData.length; i++){
      if(writeOffData[i].selected){
        dataUpdate.push({
          "id" : writeOffData[i].id,
          "remarkNote": writeOffData[i].remarkNote,
          "status": data.status
        })
      }
    }

    return dataUpdate;
  }

  buildRemarkNoteDataUpdate(writeOffData: SuspenseReport[], event: any){
    let dataUpdate = [];

    for (let i = 0; i < writeOffData.length; i++){
      if(writeOffData[i].selected){
        dataUpdate.push({
          "id" : writeOffData[i].id,
          "remarkNote": event.target.value,
          "status": writeOffData[i].status
        })
      }
    }

    return dataUpdate;
  }

  changeWriteOffPendingStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.writeoffPendingData, data);
    this.updateTransactions(dataUpdate);
  }

  changeWriteOffDoneStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.writeoffDoneData, data);
    this.updateTransactions(dataUpdate);
  }

  changeBookIncomeStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.bookIncomeData, data);
    this.updateTransactions(dataUpdate);
  }

  changeWriteOffPendingRemarkNote(data: any, event: any) {
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.writeoffPendingData, event);
    this.updateTransactions(dataUpdate);
  }

  changeWriteOffDoneRemarkNote(data: any, event: any) {
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.writeoffDoneData, event);
    this.updateTransactions(dataUpdate);
  }

  changeBookIncomeRemarkNote(data: any, event: any) {
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.bookIncomeData, event);
    this.updateTransactions(dataUpdate);
  }

  selectDate(){
    if (this.selectedBank !== '') {
      this.fetchWriteOffReport();
    }
  }

  selectPartner(){
    if (this.selectedBank === '') {
      this.toastService.addSingleShortTime('warn', '', 'Please select partner');
    } else {
      this.fetchWriteOffReport();
    }
  }

  searchWriteOffTransaction(){
    if (this.selectedBank === '') {
      this.toastService.addSingleShortTime('warn', '', 'Please select partner');
    } else {
      this.fetchWriteOffReport();
    }
  }

  confirmWriteOffTrx(){
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Status',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.executingConfirmWriteOffTrx();
      },
      reject: () => {
        this.toastService.addSingleShortTime(
          'info',
          'Rejected',
          'You have rejected'
        );
      },
    });
  }

  executingConfirmWriteOffTrx(){
    let confirmDataUpdate= [];
    for(let i = 0; i < this.writeoffPendingData.length; i++){
      if(this.writeoffPendingData[i].selected){
        confirmDataUpdate.push({
          "id" : this.writeoffPendingData[i].id
        })
      }
    }

    this.confirmTransactions(confirmDataUpdate);
  }

  selectWriteOffPendingTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.writeoffPendingData[i].selected = true;
        }
      }
      else {
        this.writeoffPendingData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.writeoffPendingData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectWriteOffDoneTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.writeoffDoneData[i].selected = true;
        }
      }
      else {
        this.writeoffDoneData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.writeoffDoneData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectBookIncomeTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.bookIncomeData[i].selected = true;
        }
      }
      else {
        this.bookIncomeData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.bookIncomeData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  confirmAndExport(){
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Excel',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.exportWriteoffReport();
      },
      reject: () => {
        this.toastService.addSingleShortTime(
          'info',
          'Rejected',
          'You have rejected'
        );
      },
    });
  }

  exportWriteoffReport(){
    this.loaderService.onLoading();
    this.reconciliationService
      .exportWriteoffReport(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY')
        ).subscribe(
        (response) => {
          this.downloadFile(response.body);
          this.loaderService.offLoading();
        },
        (error) => {
          console.log(error);
          this.loaderService.offLoading();
        }
      );
  }

  downloadFile(data: any) {
    const fileName = 'Suspense_Report';
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + this._today);
  }

}
