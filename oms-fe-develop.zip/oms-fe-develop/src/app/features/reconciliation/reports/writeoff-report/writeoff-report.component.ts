import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { SuspenseReport } from 'src/app/core/models/suspense-report.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';

@Component({
  selector: 'app-writeoff-report',
  templateUrl: './writeoff-report.component.html',
  styleUrls: ['./writeoff-report.component.sass']
})
export class WriteoffReportComponent implements OnInit {

  _today = new Date();

  _bankList: MetaData[] = [];
  _searchTypeList: SearchType[] = [];
  writeoffStatusList: MetaData[] = [];
  selectedBank: string = '';

  searchingValue: string = '';

  writeoffPendingData: SuspenseReport[] = [];
  writeoffDoneData: SuspenseReport[] = [];
  bookIncomeData: SuspenseReport[] = [];

  startIndex: number = 0;
  endIndex: number = 0;

  constructor(
    private reconciliationService: ReconciliationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService
  ) {
    this._bankList = commonUtilityService.bankList;
    this._searchTypeList = commonUtilityService.searchType;
    this.writeoffStatusList = commonUtilityService.suspenseStatusList;
  }

  ngOnInit(): void {}

  fetchWriteOffReport(){
    this.loaderService.onLoading();
    this.reconciliationService
    .getWriteOffReport(
      '01/01/2021',
      moment(this._today).format('DD/MM/YYYY'),
      this.selectedBank,
      '1000',
      '1',
      '2',
      this.searchingValue,
      ''
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.writeoffPendingData = []
          this.writeoffDoneData = []
          this.bookIncomeData = []
        if(this.commonUtilityService.isEmptyObj(data.result)){
          this.toastService.addSingle(
            'info',
            '',
            'No Data.'
          );

        }
        else {
          for(let i = 0; i < data.result.data.length; i++){
            if(data.result.data[i].status == 1){
              this.writeoffPendingData.push(data.result.data[i]);
            }
            if(data.result.data[i].status == 2){
              this.writeoffDoneData.push(data.result.data[i]);
            }
            if(data.result.data[i].status == 4){
              this.bookIncomeData.push(data.result.data[i]);
            }
          }
        }
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }

  updateTransactions(dataUpdate: any[]){
    this.reconciliationService
    .updateSuspenseTrxStatus(
      'false',
      dataUpdate
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.fetchWriteOffReport();
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }

  confirmTransactions(dataUpdate: any[]){
    this.reconciliationService
    .updateSuspenseTrxStatus(
      'true',
      dataUpdate
    )
    .subscribe(
      (data) => {
        this.loaderService.offLoading();
        this.fetchWriteOffReport();
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }

  buildStatusDataUpdate(writeOffData: SuspenseReport[], data: any){
    let dataUpdate = [];

    for (let i = 0; i < writeOffData.length; i++){
      if(writeOffData[i].selected){
        dataUpdate.push({
          "id" : writeOffData[i].id,
          "remarkNote": writeOffData[i].remarkNote,
          "status": data.status
        })
      }
    }

    return dataUpdate;
  }

  buildRemarkNoteDataUpdate(writeOffData: SuspenseReport[], event: any){
    let dataUpdate = [];

    for (let i = 0; i < writeOffData.length; i++){
      if(writeOffData[i].selected){
        dataUpdate.push({
          "id" : writeOffData[i].id,
          "remarkNote": event.target.value,
          "status": writeOffData[i].status
        })
      }
    }

    return dataUpdate;
  }

  changeWriteOffPendingStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.writeoffPendingData, data);
    this.updateTransactions(dataUpdate);
  }

  changeWriteOffDoneStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.writeoffDoneData, data);
    this.updateTransactions(dataUpdate);
  }

  changeBookIncomeStatus(data: SuspenseReport){
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildStatusDataUpdate(this.bookIncomeData, data);
    this.updateTransactions(dataUpdate);
  }

  changeWriteOffPendingRemarkNote(data: any, event: any) {
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.writeoffPendingData, event);
    this.updateTransactions(dataUpdate);
  }

  changeWriteOffDoneRemarkNote(data: any, event: any) {

    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.writeoffDoneData, event);
    this.updateTransactions(dataUpdate);
  }

  changeBookIncomeRemarkNote(data: any, event: any) {
    let dataUpdate = [];
    data.selected = true;
    dataUpdate = this.buildRemarkNoteDataUpdate(this.bookIncomeData, event);
    this.updateTransactions(dataUpdate);
  }


  searchWriteOffTransaction(){
    this.fetchWriteOffReport();
  }

  confirmWriteOffTrx(){
    let confirmDataUpdate= [];
    for(let i = 0; i < this.writeoffDoneData.length; i++){
      if(this.writeoffDoneData[i].selected){
        confirmDataUpdate.push({
          "id" : this.writeoffDoneData[i].id
        })
      }
    }

    this.confirmTransactions(confirmDataUpdate);
  }

  selectWriteOffPendingTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.writeoffPendingData[i].selected = true;
        }
      }
      else {
        this.writeoffPendingData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.writeoffPendingData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectWriteOffDoneTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.writeoffDoneData[i].selected = true;
        }
      }
      else {
        this.writeoffDoneData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.writeoffDoneData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectBookIncomeTrx(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this.bookIncomeData[i].selected = true;
        }
      }
      else {
        this.bookIncomeData.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this.bookIncomeData.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

}
