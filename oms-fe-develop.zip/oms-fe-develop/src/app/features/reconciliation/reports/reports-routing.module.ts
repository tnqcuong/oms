import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DailyReportComponent } from './daily-report/daily-report.component';
import { PendingReportComponent } from './pending-report/pending-report.component';
import { ReportsListComponent } from './reports-list/reports-list.component';
import { ReportsComponent } from './reports.component';
import { SuspenseReportComponent } from './suspense-report/suspense-report.component';
import { WriteoffReportComponent } from './writeoff-report/writeoff-report.component';

const routes: Routes = [
  {
    path: '',
    component: ReportsComponent,
    children: [
      {
        path: '',
        component: ReportsListComponent
      },
      {
        path: 'suspense',
        component: SuspenseReportComponent
      },
      {
        path: 'daily',
        component: DailyReportComponent
      },
      {
        path: 'writeoff',
        component: WriteoffReportComponent
      },
      {
        path: 'pending',
        component: PendingReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
