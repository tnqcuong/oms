import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';

@Component({
  selector: 'app-pending-report',
  templateUrl: './pending-report.component.html',
  styleUrls: ['./pending-report.component.sass'],
})
export class PendingReportComponent implements OnInit {
  today = new Date();

  bankList: MetaData[] = [];
  searchTypeList: SearchType[] = [];
  selectedBank: string = '';

  pendingTransactions: BankTransaction[] = [];

  constructor(
    private reconciliationService: ReconciliationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService
  ) {
    this.bankList = commonUtilityService.bankList;
    console.log(
      'commonUtilityService.bankList: ',
      commonUtilityService.bankList
    );
    this.searchTypeList = commonUtilityService.searchType;
  }

  ngOnInit(): void {}

  fetchMatchingTransaction() {
    this.loaderService.onLoading();
    this.reconciliationService
      .getAllPendingTransaction(
        '01/01/2021',
        moment(this.today).add(1, 'days').format('DD/MM/YYYY'),
        this.selectedBank,
        '1000',
        '1',
        '2'
      )
      .subscribe(
        (data) => {
          this.pendingTransactions = data.result.data;
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle('error', '', 'Server Error');
        }
      );
  }
}
