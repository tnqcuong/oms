import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';
import * as file from 'file-saver';

@Component({
  selector: 'app-pending-report',
  templateUrl: './pending-report.component.html',
  styleUrls: ['./pending-report.component.sass'],
})
export class PendingReportComponent implements OnInit {
  _today = new Date();
  // startDt = moment(this._today).startOf('month').format('DD/MM/YYYY');
  startDt = new Date(this._today.getFullYear(), this._today.getMonth(), 1);
  endDt = this._today;
  // endDt = moment(this._today).endOf('month').format('DD/MM/YYYY');
  today = moment(this._today).format('DD/MM/YYYY');
  bankList: MetaData[] = [];
  searchTypeList: SearchType[] = [];
  selectedBank: string = '';

  pendingTransactions: BankTransaction[] = [];

  constructor(
    private reconciliationService: ReconciliationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private confirmationService: ConfirmationService,
    private loaderService: LoaderService
  ) {
    this.searchTypeList = commonUtilityService.searchType;
    this.bankList = this.commonUtilityService.allPartnerList;
  }

  ngOnInit(): void {}

  fetchMatchingTransaction() {
    this.loaderService.onLoading();
    this.reconciliationService
      .getAllPendingTransaction(
        moment(this.startDt).format('DD/MM/YYYY'),
        moment(this.endDt).format('DD/MM/YYYY'),
        this.selectedBank,
        '1000',
        '1'
      )
      .subscribe(
        (data) => {
          this.pendingTransactions = data.result.data;
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'error',
            'Error',
            error.error?.exceptionMessage
              ? error.error?.exceptionMessage
              : 'Server error.'
          );
        }
      );
  }

  confirm1() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Excel',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (this.selectedBank) {
          this.exportPendingReport();
          this.toastService.addSingleShortTime(
            'success',
            'Confirmed',
            'You have accepted'
          );
        } else {
          this.toastService.addSingleShortTime(
            'info',
            'Select Partner',
            'Please select a partner.'
          );
        }
      },
      reject: () => {
        this.toastService.addSingleShortTime(
          'info',
          'Rejected',
          'You have rejected'
        );
      },
    });
  }

  exportPendingReport() {
    this.loaderService.onLoading();
    this.reconciliationService
      .exportPendingReport(
        moment(this.startDt).format('DD/MM/YYYY'),
        moment(this.endDt).format('DD/MM/YYYY'),
        this.selectedBank)
      .subscribe(
        (response) => {
          this.downloadFile(response.body);
          this.loaderService.offLoading();
        },
        (error) => {
          console.log(error);
          this.loaderService.offLoading();
        }
      );
  }

  downloadFile(data: any) {
    const fileName = this.selectedBank + '_Pending_Report' || 'Pending_Report';
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + this.today);
  }

  getBankName(bankCode: string) {
    for (let i = 0; i < this.bankList.length; i++) {
      if (this.bankList[i].lookupCodeId == bankCode) {
      }
    }
  }
}
