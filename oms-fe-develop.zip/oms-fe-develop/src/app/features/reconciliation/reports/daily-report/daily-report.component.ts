import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { forkJoin, Observable } from 'rxjs';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';
import * as file from 'file-saver';

@Component({
  selector: 'app-daily-report',
  templateUrl: './daily-report.component.html',
  styleUrls: ['./daily-report.component.sass']
})
export class DailyReportComponent implements OnInit {

  _today: Date = new Date();

  _selectedDate = this._today;

  reconSummary: any[] = [];
  repaymentDailyReport: any[] = [];
  disbursalDailyReport: any[] = [];
  repaymentDailyCollectionReport: any[] = [];
  disbursalDailyCollectionReport: any[] = [];

  isWeekendArr: boolean[] = new Array(31).fill(true);

  disbBankStatusList: MetaData[] = [];
  bankStatusList: MetaData[] = [];

  constructor(
    private reconciliationService: ReconciliationService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private confirmationService: ConfirmationService,
  ) {
    this.disbBankStatusList = commonUtilityService.disbBankTrxStatusList
    this.bankStatusList = commonUtilityService.bankTrxStatusList
  }

  ngOnInit(): void {
    this.getDailyReport();
  }

  checkWeekend(selectedDate: Date){
    let startDt = this.commonUtilityService.getStartDateOfMonth(selectedDate);
    let endDt = this.commonUtilityService.getEndDateOfMonth(selectedDate);
    this.isWeekendArr = new Array(31).fill(true);

    let loop = new Date(startDt);
    let index = 0;
    while(loop <= endDt){
      if(loop.getDay() === 6 || loop.getDay() === 0){
        this.isWeekendArr[index] = true;
      }
      else {
        this.isWeekendArr[index] = false;
      }
      loop = new Date(loop.setDate(loop.getDate() + 1));
      index++;
    }

    console.log('isWeekenArr: ', this.isWeekendArr);
  }

  getDailyReport(){
    this.loaderService.onLoading();
    this.checkWeekend(this._selectedDate);
    this.forkJoinDailyReport()
      .subscribe(
        ([data1, data2, data3, data4, data5]) => {

          this.reconSummary = data1.result.data;
          this.repaymentDailyReport = data2.result.data;
          this.disbursalDailyReport = data3.result.data;

          this.repaymentDailyCollectionReport = data4.result.data;
          this.disbursalDailyCollectionReport = data5.result.data;

          console.log('data4: ', data4);
          console.log('data5: ', data5);

          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'error',
            'Error',
            error.error?.exceptionMessage
              ? error.error?.exceptionMessage
              : 'Server error.'
          );
        }
      );
  }

  forkJoinDailyReport(): Observable<any[]>{

    let call1 = this.reconciliationService
    .getReconSummary(
      moment(this.commonUtilityService.getStartDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this.commonUtilityService.getEndDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this._selectedDate).format('DD/MM/YYYY')
    );

    let call2 = this.reconciliationService
    .getOPSRepaymentDailyReport(
      moment(this.commonUtilityService.getStartDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this.commonUtilityService.getEndDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this._selectedDate).format('DD/MM/YYYY')
    );
    let call3 = this.reconciliationService
    .getOPSDisbursalDailyReport(
      moment(this.commonUtilityService.getStartDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this.commonUtilityService.getEndDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this._selectedDate).format('DD/MM/YYYY')
    );

    let call4 = this.reconciliationService
    .getRepaymentDailyCollectionReport(
      moment(this.commonUtilityService.getStartDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this.commonUtilityService.getEndDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this._selectedDate).format('DD/MM/YYYY')
    );
    let call5 = this.reconciliationService
    .getDisbursalDailyCollectionReport(
      moment(this.commonUtilityService.getStartDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this.commonUtilityService.getEndDateOfMonth(this._selectedDate)).format('DD/MM/YYYY'),
      moment(this._selectedDate).format('DD/MM/YYYY')
    );

    return forkJoin([call1, call2, call3, call4, call5]);
  }


  confirm1() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Excel',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.exportDailyReport();
      },
      reject: () => {
        this.toastService.addSingleShortTime(
          'info',
          'Rejected',
          'You have rejected'
        );
      },
    });
  }

  exportDailyReport() {
    this.loaderService.onLoading();
    this.reconciliationService
      .exportDailyReport(moment(this._selectedDate).format('DD/MM/YYYY'))
      .subscribe(
        (response) => {
          this.downloadFile(response.body);
          this.loaderService.offLoading();
        },
        (error) => {
          console.log(error);
          this.loaderService.offLoading();
        }
      );
  }

  downloadFile(data: any) {
    const fileName = 'Daily_Report';
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + this._today);
  }
}
