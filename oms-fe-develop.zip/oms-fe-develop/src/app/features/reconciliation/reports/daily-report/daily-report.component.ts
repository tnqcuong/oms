import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { forkJoin, Observable } from 'rxjs';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';

@Component({
  selector: 'app-daily-report',
  templateUrl: './daily-report.component.html',
  styleUrls: ['./daily-report.component.sass']
})
export class DailyReportComponent implements OnInit {

  _today: Date = new Date();
  // _startOfMonth = moment(this._today).startOf('month').format('DD/MM/YYYY');
  // _endOfMonth = moment(this._today).endOf('month').format('DD/MM/YYYY');
  // _selectedDate = moment(this._today).format('DD/MM/YYYY');
  _startOfMonth = new Date(
    this._today.getFullYear(),
    this._today.getMonth(),
    1
  );
  _endOfMonth = new Date(
    this._today.getFullYear(),
    this._today.getMonth() + 1,
    0
  );

  _currentMonthYear = moment(this._today).format('MMMM YYYY');
  _selectedDate = this._today;

  reconSummary: any[] = [];
  repaymentDailyReport: any[] = [];
  disbursalDailyReport: any[] = [];

  disbBankStatusList: MetaData[] = [];
  bankStatusList: MetaData[] = [];

  constructor(
    private reconciliationService: ReconciliationService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService
  ) {
    this.disbBankStatusList = commonUtilityService.disbBankTrxStatusList
    this.bankStatusList = commonUtilityService.bankTrxStatusList
  }

  ngOnInit(): void {
    this.getOPSDailyReport();
    this.getReconSummary();
  }

  getReconSummary() {
    this.loaderService.onLoading();
    this.reconciliationService
      .getReconSummary(
        moment(this._startOfMonth).format('DD/MM/YYYY'),
        moment(this._endOfMonth).format('DD/MM/YYYY'),
        moment(this._selectedDate).format('DD/MM/YYYY')
      )
      .subscribe(
        (data) => {
          this.reconSummary = data.result.data;
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle('error', 'Error', 'Server Error.');
        }
      );
  }

  getOPSDailyReport(){
    this.loaderService.onLoading();
    this.forkJoinDailyReport()
      .subscribe(
        ([data1, data2]) => {
          console.log('disbBankStatusList ', this.disbBankStatusList);
          console.log('bankStatusList ', this.bankStatusList);

          let repaymentDailyReportList = data1.result.data;
          let disbursalDailyReportList = data2.result.data;

          this.convertStatusForRepayment(repaymentDailyReportList);

          this.convertStatusForDisbursal(disbursalDailyReportList);

          this.repaymentDailyReport = repaymentDailyReportList
          this.disbursalDailyReport = disbursalDailyReportList

          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle('error', 'Error', 'Server Error.');
        }
      );
  }

  private convertStatusForDisbursal(disbursalDailyReportList: any) {
    if (!this.commonUtilityService.isEmptyObj(disbursalDailyReportList)) {
      for (let i = 0; i < disbursalDailyReportList.length; i++) {
        let item = disbursalDailyReportList[i];
        for (let j = 0; j < this.disbBankStatusList.length; j++) {
          if (item[1] == 1) {
            item[1] = "- Disbursement";
          }
          if (item[1] == 2) {
            item[1] = "- Pending disbursement/excess money";
          }
          if (item[1] == 3) {
            item[1] = "- Reverted";
          }
          if (item[1] == 4) {
            item[1] = "- Refund";
          }
          if (item[1] == 8) {
            item[1] = "- Re-disbursement";
          }
        }
      }
    }
  }

  private convertStatusForRepayment(repaymentDailyReportList: any) {
    if (!this.commonUtilityService.isEmptyObj(repaymentDailyReportList)) {
      for (let i = 0; i < repaymentDailyReportList.length; i++) {
        let item = repaymentDailyReportList[i];
        for (let j = 0; j < this.bankStatusList.length; j++) {
          if (item[1] == 1) {
            item[1] = "- Match data  Bank statement vs LMS";
          }
          if (item[1] == 2) {
            item[1] = "- Unmatch data  Bank statement vs LMS";
          }
          if (item[1] == 3) {
            item[1] = "- Revert cheque";
          }
          if (item[1] == 4) {
            item[1] = "- Refund/Cancel cheque";
          }
        }
      }
    }
  }

  forkJoinDailyReport(): Observable<any[]>{

    let call1=this.reconciliationService
    .getOPSRepaymentDailyReport(
      moment(this._startOfMonth).format('DD/MM/YYYY'),
      moment(this._endOfMonth).format('DD/MM/YYYY'),
      moment(this._selectedDate).format('DD/MM/YYYY')
    )
    let call2=this.reconciliationService
    .getOPSDisbursalDailyReport(
      moment(this._startOfMonth).format('DD/MM/YYYY'),
      moment(this._endOfMonth).format('DD/MM/YYYY'),
      moment(this._selectedDate).format('DD/MM/YYYY')
    )

    return forkJoin([call1, call2]);
  }


  confirm1() {
    // this.confirmationService.confirm({
    //   message: 'Are you sure that you want to proceed?',
    //   header: 'Confirmation',
    //   icon: 'pi pi-exclamation-triangle',
    //   accept: () => {
    //     this.Export();
    //   },
    //   reject: () => {
    //     this.toastService.addSingle('info', 'Rejected', 'You have rejected');
    //   },
    // });
  }
}
