import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';
import { DailyReportComponent } from './daily-report/daily-report.component';
import { PendingReportComponent } from './pending-report/pending-report.component';
import { SuspenseReportComponent } from './suspense-report/suspense-report.component';
import { WriteoffReportComponent } from './writeoff-report/writeoff-report.component';
import { ReportsListComponent } from './reports-list/reports-list.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ReportsComponent,
    DailyReportComponent,
    PendingReportComponent,
    SuspenseReportComponent,
    WriteoffReportComponent,
    ReportsListComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ReportsRoutingModule
  ]
})
export class ReportsModule { }
