import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-reports-list',
  templateUrl: './reports-list.component.html',
  styleUrls: ['./reports-list.component.sass']
})
export class ReportsListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }

  ngOnInit(): void {
  }

  goToPendingReport(department: number) {
    this.routeStateService.add(
      'PendingReport',
      '/reconciliation/reports/pending',
      department,
      false
    );
  }

  goToDailyReport(department: number) {
    this.routeStateService.add(
      'DailyReport',
      '/reconciliation/reports/daily',
      department,
      false
    );
  }

  goToSuspenseReport(department: number) {
    this.routeStateService.add(
      'SuspenseReport',
      '/reconciliation/reports/suspense',
      department,
      false
    );
  }

  goToWriteoffReport(department: number) {
    this.routeStateService.add(
      'WriteoffReport',
      '/reconciliation/reports/writeoff',
      department,
      false
    );
  }

}
