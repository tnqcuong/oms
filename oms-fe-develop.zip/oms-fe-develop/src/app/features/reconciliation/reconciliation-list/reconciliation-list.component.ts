import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-reconciliation-list',
  templateUrl: './reconciliation-list.component.html',
  styleUrls: ['./reconciliation-list.component.sass']
})
export class ReconciliationListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) {}

  ngOnInit(): void {}
  // Data
  log(val: any) {
    console.log(val);
  }
  goToDepartmentChecking(department: number) {
    this.routeStateService.add(
      'DataChecking',
      '/main/reconciliation/data-checking',
      department,
      false
    );
  }
  goToDepartmentRepayment(department: number) {
    this.routeStateService.add(
      'Repayment',
      '/main/reconciliation/repayment',
      department,
      false
    );
  }
  goToDepartmentDisbursement(department: number) {
    this.routeStateService.add(
      'Disbursement',
      '/main/reconciliation/disbursement',
      department,
      false
    );
  }
  goToDepartmentReports(department: number) {
    this.routeStateService.add(
      'Reports',
      '/main/reconciliation/reports',
      department,
      false
    );
  }
}
