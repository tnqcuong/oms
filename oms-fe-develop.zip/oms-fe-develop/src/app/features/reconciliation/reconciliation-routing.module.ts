import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReconciliationDataCheckingComponent } from './reconciliation-data-checking/reconciliation-data-checking.component';
import { ReconciliationListComponent } from './reconciliation-list/reconciliation-list.component';
import { ReconciliationComponent } from './reconciliation.component';

const routes: Routes = [
  {
    path: '',
    component: ReconciliationComponent,
    children: [
      {
        path: '',
        component: ReconciliationListComponent
      },
      {
        path: 'data-checking',
        component: ReconciliationDataCheckingComponent
      },
      {
        path: 'disbursement',
        loadChildren: () => import('src/app/features/reconciliation/disbursement/disbursement.module').then(m => m.DisbursementModule)
      },
      {
        path: 'repayment',
        loadChildren: () => import('src/app/features/reconciliation/repayment/repayment.module').then(m => m.RepaymentModule)
      },
      {
        path: 'reports',
        loadChildren: () => import('src/app/features/reconciliation/reports/reports.module').then(m => m.ReportsModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReconciliationRoutingModule { }
