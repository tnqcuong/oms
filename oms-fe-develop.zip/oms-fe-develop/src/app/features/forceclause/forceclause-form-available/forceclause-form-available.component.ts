import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-form-available',
  templateUrl: './forceclause-form-available.component.html',
  styleUrls: ['./forceclause-form-available.component.sass']
})
export class ForceclauseFormAvailableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
