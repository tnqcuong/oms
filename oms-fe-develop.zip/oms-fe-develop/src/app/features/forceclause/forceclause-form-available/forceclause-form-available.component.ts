import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-form-available',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./forceclause-form-available.component.sass'],
})
export class ForceclauseFormAvailableComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
