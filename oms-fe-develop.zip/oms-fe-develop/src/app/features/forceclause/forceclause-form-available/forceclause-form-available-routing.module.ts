import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclauseFormAvailableListComponent } from './forceclause-form-available-list/forceclause-form-available-list.component';
import { ForceclauseFormAvailableReportComponent } from './forceclause-form-available-report/forceclause-form-available-report.component';
import { ForceclauseFormAvailableComponent } from './forceclause-form-available.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseFormAvailableComponent,
    children: [
      {
        path: '',
        component: ForceclauseFormAvailableListComponent
      },
      {
        path: 'report',
        component: ForceclauseFormAvailableReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForceclauseFormAvailableRoutingModule { }
