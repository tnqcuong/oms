import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseFormAvailableListComponent } from './forceclause-form-available-list.component';

describe('ForceclauseFormAvailableListComponent', () => {
  let component: ForceclauseFormAvailableListComponent;
  let fixture: ComponentFixture<ForceclauseFormAvailableListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseFormAvailableListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseFormAvailableListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
