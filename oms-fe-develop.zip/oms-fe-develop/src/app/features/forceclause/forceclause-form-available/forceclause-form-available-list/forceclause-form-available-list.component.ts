import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-forceclause-form-available-list',
  templateUrl: './forceclause-form-available-list.component.html',
  styleUrls: ['./forceclause-form-available-list.component.sass']
})
export class ForceclauseFormAvailableListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }


  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchForm: searchSelect[] = [
    {
      id: '_cif',
      value: 'CIF',
    },
  ];

  ngOnInit(): void {
  }
  getDataSearch() {
    console.log(this._lookupCodeId);
    console.log(this._valueSrech);
  }
  WaiveOff() {}
  Remove() {}
  ET() {}
  goToFCLFormAvailableReport()
  {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/forceclause/form-available/report',
      0,
      true
    );
  }
  BackPage()
  {
    this.routeStateService.add(
      'List',
      '/forceclause/form-available',
      0,
      true
    );
  }
  MorePage()
  {

  }

}
