import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Form } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';
@Component({
  selector: 'app-forceclause-form-available-list',
  templateUrl: './forceclause-form-available-list.component.html',
  styleUrls: ['./forceclause-form-available-list.component.sass'],
})
export class ForceclauseFormAvailableListComponent implements OnInit {
  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService
  ) {}

  startIndex: number = 0;
  endIndex: number = 0;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';

  loading_form: boolean = false;
  loading_more: boolean = true;
  _arrFormList: Form[] = [];
  _arrFormListAll: Form[] = [];
  _arrFormListTrue: Form[] = [];
  _arrFormListCount = 0;
  _pageFormList = 1;
  _tableSizeFormList = 5;
  _totalPage = 0;

  display_WaiveOff: boolean = false;

  _listsearchForm: searchSelect[] = [
    {
      id: '_cifNo',
      value: 'CIF',
    },
  ];

  ngOnInit(): void {
    this.fetchGetForm();
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetForm() {
    this.loaderService.onLoading();
    this.FCLservice.GetForm(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizeFormList,
      this._pageFormList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrFormList = [];
          this.loading_form = false;
          this.loaderService.offLoading();
        } else {
          this._arrFormList = [];
          this._arrFormList = data?.result?.data;
          this._arrFormListCount = data?.result?.count;
          this.loading_form = true;
          // set page
          this._totalPage = this._arrFormListCount / this._tableSizeFormList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrFormListAll = this._arrFormListAll.concat(this._arrFormList);

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Form List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data Form List'
        );
        this.loaderService.offLoading();
      }
    );
  }
  getDataSearch() {
    this._pageFormList = 1;
    this._arrFormListAll = [];
    this.fetchGetForm();
  }
  CheckETFormScanDate(et_form_scan_date: any) {
    const _et_form_scan_datet = moment(et_form_scan_date, 'DD/MM/YYYY');
    const days = this._DayNow.diff(_et_form_scan_datet, 'days');
    // const days = _et_form_scan_datet.diff(this._DayNow, 'days');
    if (days >= 5) {
      return 'D';
    } else if (days >= 3) {
      return 'V';
    }
    return 'N';
  }
  toggleVisibility(event: any, row_GetFormtrx: any, i: any){
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrFormListAll[i].checked = true;
        }
      } else {
        this._arrFormListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrFormListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked = false;
        }
      });
    }
  }
  WaiveOff() {
    this._arrFormListTrue= [];
    this.display_WaiveOff = true;
    this._arrFormListAll.map((item)=>{
      if(item.checked)
      {
        this._arrFormListTrue.push(item);
      }
    })
  }
  CloseDialog_WaiveOff()
  {
    this.display_WaiveOff = false;
  }
  onSubmitWaiveOff()
  {

  }
  Remove() {}
  ET() {}
  goToFCLFormAvailableReport() {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/form-available/report',
      0,
      true
    );
  }
  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  MorePage() {
    if (this._pageFormList < this._totalPage) {
      this._pageFormList = this._pageFormList + 1;
      this.fetchGetForm();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'Form List', 'Out of Data');
    }
  }
}
