import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-forceclause-form-available-report',
  templateUrl: './forceclause-form-available-report.component.html',
  styleUrls: ['./forceclause-form-available-report.component.sass']
})
export class ForceclauseFormAvailableReportComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }
  _lookupCodeId = '';
  _valueSrech = '';

  DayNow = new Date();
  _endDt = new Date(moment(this.DayNow).dayOfYear(365).format('MM/DD/YYYY'));
  _startDt = new Date(
    moment(this.DayNow).dayOfYear(1).format('MM/DD/YYYY')
  );

  _listsearchRegistrantion: searchSelect[] = [
    {
      id: '_cif',
      value: 'CIF',
    },
  ];
  ngOnInit(): void {
  }
  BackPage()
  {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/forceclause/form-available',
      0,
      true
    );
  }

  getDataSearch()
  {
    console.log(this._lookupCodeId);
    console.log(this._valueSrech);
  }
}
