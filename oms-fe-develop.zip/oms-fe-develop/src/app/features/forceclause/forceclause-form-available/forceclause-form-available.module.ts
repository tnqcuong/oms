import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclauseFormAvailableRoutingModule } from './forceclause-form-available-routing.module';
import { ForceclauseFormAvailableListComponent } from './forceclause-form-available-list/forceclause-form-available-list.component';
import { ForceclauseFormAvailableReportComponent } from './forceclause-form-available-report/forceclause-form-available-report.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclauseFormAvailableListComponent,
    ForceclauseFormAvailableReportComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseFormAvailableRoutingModule
  ]
})
export class ForceclauseFormAvailableModule { }
