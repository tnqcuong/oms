import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseFormAvailableComponent } from './forceclause-form-available.component';

describe('ForceclauseFormAvailableComponent', () => {
  let component: ForceclauseFormAvailableComponent;
  let fixture: ComponentFixture<ForceclauseFormAvailableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseFormAvailableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseFormAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
