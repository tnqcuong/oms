import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseEarlyTerminationFollowUpListComponent } from './forceclause-early-termination-follow-up-list.component';

describe('ForceclauseEarlyTerminationFollowUpListComponent', () => {
  let component: ForceclauseEarlyTerminationFollowUpListComponent;
  let fixture: ComponentFixture<ForceclauseEarlyTerminationFollowUpListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseEarlyTerminationFollowUpListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseEarlyTerminationFollowUpListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
