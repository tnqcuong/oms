import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { FollowUp } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { ConfirmationService } from 'primeng/api';
import { ExcelService } from 'src/app/core/services/excel.service';
@Component({
  selector: 'app-forceclause-early-termination-follow-up-list',
  templateUrl: './forceclause-early-termination-follow-up-list.component.html',
  styleUrls: ['./forceclause-early-termination-follow-up-list.component.sass'],
  providers: [ConfirmationService],
})
export class ForceclauseEarlyTerminationFollowUpListComponent
  implements OnInit
{
  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private confirmationService: ConfirmationService,
    private exclesev: ExcelService,
  ) {
    this._FOLLOWUP_EMI_NOTE = commonUtilityService.FOLLOWUP_EMI_NOTE;
  }

  _FOLLOWUP_EMI_NOTE: MetaData[] = [];

  startIndex: number = 0;
  endIndex: number = 0;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';

  LastDate: Date = new Date(
    this.DayNow.getFullYear(),
    this.DayNow.getMonth() - 1,
    this.DayNow.getDate()
  );

  _endDt = new Date(moment(this.DayNow).format('MM/DD/YYYY'));
  _startDt = new Date(moment(this.LastDate).format('MM/DD/YYYY'));

  _listsearchPayment: searchSelect[] = [
    {
      id: '_loanNo',
      value: 'Agreement No',
    },
    {
      id: '_partner',
      value: 'Partner Bank',
    },
  ];

  display_Update_Note: boolean = false;
  display_Update_Remark: boolean = false;
  _editNode: boolean = false;

  loading_FollowUp: boolean = false;
  loading_more: boolean = true;
  _arrFollowUpList: FollowUp[] = [];
  _arrFollowUpListAll: FollowUp[] = [];
  _arrFollowUpListTrue: FollowUp[] = [];
  _arrFollowUpListTrue_Remark: FollowUp[] = [];
  _arrFollowUpListCount = 0;
  _pageFollowUpList = 1;
  _tableSizeFollowUpList = 20;
  _totalPage = 0;

  ngOnInit(): void {
    this.fetchGetFollowUp();
  }
  getDataSearch() {
    this._pageFollowUpList = 1;
    this._arrFollowUpListAll = [];
    this.fetchGetFollowUp();
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetFollowUp() {
    this.loaderService.onLoading();
    this.FCLservice.GetFollowUp(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizeFollowUpList,
      this._pageFollowUpList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrFollowUpList = [];
          this.loading_FollowUp = false;
          this.loaderService.offLoading();
        } else {
          this._arrFollowUpList = [];
          this._arrFollowUpList = data?.result?.data;
          this._arrFollowUpListCount = data?.result?.count;
          this.loading_FollowUp = true;
          // set page
          this._totalPage =
            this._arrFollowUpListCount / this._tableSizeFollowUpList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrFollowUpListAll = this._arrFollowUpListAll.concat(
            this._arrFollowUpList
          );

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'FollowUp List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data FollowUp List'
        );
        this.loaderService.offLoading();
      }
    );
  }
  toggleVisibility(event: any, row_GetFormtrx: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrFollowUpListAll[i].checked = true;
        }
      } else {
        this._arrFollowUpListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrFollowUpListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked = false;
        }
      });
    }
  }
  toggleVisibilityRemark(event: any, row_GetFormtrx: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrFollowUpListAll[i].checked_remark = true;
        }
      } else {
        this._arrFollowUpListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked_remark = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrFollowUpListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked_remark = false;
        }
      });
    }
  }

  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  goToFCLFollowUpReport() {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/early-termination-follow-up/report',
      0,
      true
    );
  }
  Update_Note() {
    this._arrFollowUpListTrue = [];
    this.display_Update_Note = true;
    this._arrFollowUpListAll.map((item) => {
      if (item.checked) {
        this._arrFollowUpListTrue.push(item);
      }
    });
  }
  EditNodeRemark(row_GetFormtrx: any, i: any) {
    this._editNode = true;
    this._arrFollowUpListAll.map((item) => {
      if (item.loan_no === row_GetFormtrx.loan_no) {
        item.checked_remark = true;
      }
    });
  }
  RemoveNodeRemark(row_GetFormtrx: any, i: any) {
    this._editNode = true;
    this._arrFollowUpListAll.map((item) => {
      if (item.loan_no === row_GetFormtrx.loan_no) {
        item.checked_remark = false;
      }
    });
  }
  Update_Remark() {
    this._arrFollowUpListTrue_Remark = [];
    this._arrFollowUpListAll.map((item) => {
      if (item.checked_remark) {
        this._arrFollowUpListTrue_Remark.push(item);
      }
    });
    this.loaderService.onLoading();
    if (this._arrFollowUpListTrue_Remark.length > 0) {
      this.FCLservice.PatchUpdateNote_Remark(
        this._arrFollowUpListTrue_Remark
      ).subscribe(
        (data) => {
          // console.log(data);
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'FollowUp Update Remark',
            'Success Update Remark'
          );
          this._arrFollowUpListAll.map((item) => {
            item.checked_remark = false;
          });
          // feth page
          this._pageFollowUpList = 1;
          this._arrFollowUpListAll = [];
          this.fetchGetFollowUp();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'FollowUp Update Remark',
            error.error?.exceptionMessage
              ? error.error.exceptionMessage
              : 'No Update Remark'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.loaderService.offLoading();
      this.toastService.addSingleShortTime(
        'warn',
        'FollowUp Update Remark',
        'Nothing Has Changed'
      );
    }
  }
  MorePage() {
    if (this._pageFollowUpList < this._totalPage) {
      this._pageFollowUpList = this._pageFollowUpList + 1;
      this.fetchGetFollowUp();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'Refund List', 'Out of Data');
    }
  }
  onSubmitUpdateNote() {
    this.loaderService.onLoading();
    if(this._arrFollowUpListTrue.length>0)
    {
      this.FCLservice.PatchUpdateNote_Remark(
        this._arrFollowUpListTrue
      ).subscribe(
        (data) => {
          // console.log(data);
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'FollowUp Update Note',
            'Success Update Note'
          );
          this._arrFollowUpListAll.map((item) => {
            item.checked_remark = false;
          });
          // feth page
          this._pageFollowUpList = 1;
          this._arrFollowUpListAll = [];
          this.fetchGetFollowUp();

          this.display_Update_Note = false;
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'FollowUp Update Note',
            error.error?.exceptionMessage
              ? error.error.exceptionMessage
              : 'No Update Note'
          );
          this.loaderService.offLoading();
        }
      );
    }
    else {
      this.loaderService.offLoading();
      this.display_Update_Note = false;
      this.toastService.addSingleShortTime(
        'warn',
        'FollowUp Update Note',
        'Nothing Has Changed'
      );
    }
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.FCLservice
      .downloadFileAPI_Excel_FollowUp(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
      )
      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'Note_FollowUp',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'Export',
            'Success Export File'
          );
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }

          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }
  CloseDialog_UpdateNone() {
    this.display_Update_Note = false;
  }
}
