import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseEarlyTerminationFollowUpComponent } from './forceclause-early-termination-follow-up.component';

describe('ForceclauseEarlyTerminationFollowUpComponent', () => {
  let component: ForceclauseEarlyTerminationFollowUpComponent;
  let fixture: ComponentFixture<ForceclauseEarlyTerminationFollowUpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseEarlyTerminationFollowUpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseEarlyTerminationFollowUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
