import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclauseEarlyTerminationFollowUpListComponent } from './forceclause-early-termination-follow-up-list/forceclause-early-termination-follow-up-list.component';
import { ForceclauseEarlyTerminationFollowUpReportComponent } from './forceclause-early-termination-follow-up-report/forceclause-early-termination-follow-up-report.component';
import { ForceclauseEarlyTerminationFollowUpComponent } from './forceclause-early-termination-follow-up.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseEarlyTerminationFollowUpComponent,
    children: [
      {
        path: '',
        component: ForceclauseEarlyTerminationFollowUpListComponent
      },
      {
        path: 'report',
        component: ForceclauseEarlyTerminationFollowUpReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForceclauseEarlyTerminationFollowUpRoutingModule { }
