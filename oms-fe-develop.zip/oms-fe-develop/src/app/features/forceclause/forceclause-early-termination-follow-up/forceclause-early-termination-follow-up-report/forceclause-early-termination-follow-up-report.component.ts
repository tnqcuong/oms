import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
@Component({
  selector: 'app-forceclause-early-termination-follow-up-report',
  templateUrl: './forceclause-early-termination-follow-up-report.component.html',
  styleUrls: ['./forceclause-early-termination-follow-up-report.component.sass']
})
export class ForceclauseEarlyTerminationFollowUpReportComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }
  _lookupCodeId = '';
  _valueSrech = '';

  DayNow = new Date();
  _endDt = new Date(moment(this.DayNow).dayOfYear(365).format('MM/DD/YYYY'));
  _startDt = new Date(
    moment(this.DayNow).dayOfYear(1).format('MM/DD/YYYY')
  );

  _listsearchRegistrantion: searchSelect[] = [
    {
      id: '_cif',
      value: 'Agreement No',
    },
    {
      id: '_cif',
      value: 'Customer Phone No',
    },
  ];
  ngOnInit(): void {
  }
  BackPage()
  {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/early-termination-follow-up',
      0,
      true
    );
  }

  getDataSearch()
  {
    console.log(this._lookupCodeId);
    console.log(this._valueSrech);
  }

}
