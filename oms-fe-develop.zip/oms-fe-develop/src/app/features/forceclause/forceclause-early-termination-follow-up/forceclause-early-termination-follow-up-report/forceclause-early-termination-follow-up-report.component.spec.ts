import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseEarlyTerminationFollowUpReportComponent } from './forceclause-early-termination-follow-up-report.component';

describe('ForceclauseEarlyTerminationFollowUpReportComponent', () => {
  let component: ForceclauseEarlyTerminationFollowUpReportComponent;
  let fixture: ComponentFixture<ForceclauseEarlyTerminationFollowUpReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseEarlyTerminationFollowUpReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseEarlyTerminationFollowUpReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
