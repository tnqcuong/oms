import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclauseEarlyTerminationFollowUpRoutingModule } from './forceclause-early-termination-follow-up.routing.module';
import { ForceclauseEarlyTerminationFollowUpListComponent } from './forceclause-early-termination-follow-up-list/forceclause-early-termination-follow-up-list.component';
import { ForceclauseEarlyTerminationFollowUpReportComponent } from './forceclause-early-termination-follow-up-report/forceclause-early-termination-follow-up-report.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclauseEarlyTerminationFollowUpListComponent,
    ForceclauseEarlyTerminationFollowUpReportComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseEarlyTerminationFollowUpRoutingModule
  ]
})
export class ForceclauseEarlyTerminationFollowUpModule { }
