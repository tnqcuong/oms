import { HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { environmentAPI_FCL } from 'src/environments/environmentAPI';
import { SessionService } from 'src/app/core/services/session.service';
import { User } from 'src/app/core/models/user.model';
@Injectable({
  providedIn: 'root',
})
export class ForceclauseService {
  user: any;
  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {
    this.user = this.sessionService.getItem('currentUser');
  }

  getHeaderParams() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'access-token': this.user.token,
      Authorization: this.user.token,
    });
  }
  getHeaderParamsContentTypePDF() {
    return new HttpHeaders({
      'Content-Type': 'application/pdf',
      Accept: 'application/pdf',
      'access-token': this.user.token,
      Authorization: this.user.token,
    });
  }

  GetForm(
    params_select: any,
    params_value: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();

    if (params_select == '_cifNo') {
      params = params.set('_cifNo', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(environment.apiUrl_FCL + environmentAPI_FCL.form, {
      headers: headers,
      params: params,
    });
  }
  GetPayment(
    params_select: any,
    params_value: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();

    if (params_select == '_cifNo') {
      params = params.set('_cifNo', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(environment.apiUrl_FCL + environmentAPI_FCL.payment, {
      headers: headers,
      params: params,
    });
  }
  GetFormPayment(
    params_select: any,
    params_value: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();

    if (params_select == '_cifNo') {
      params = params.set('_cifNo', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl_FCL + environmentAPI_FCL.formpayment,
      {
        headers: headers,
        params: params,
      }
    );
  }
  GetMaturityOff(
    params_select: any,
    params_value: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();

    if (params_select == '_cifNo') {
      params = params.set('_cifNo', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(environment.apiUrl_FCL + environmentAPI_FCL.waiveoff, {
      headers: headers,
      params: params,
    });
  }
  GetMaturityBookIncome(
    params_select: any,
    params_value: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();

    if (params_select == '_cifNo') {
      params = params.set('_cifNo', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(environment.apiUrl_FCL + environmentAPI_FCL.book, {
      headers: headers,
      params: params,
    });
  }
  GetMaturityRefund(
    params_select: any,
    params_value: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();

    if (params_select == '_cifNo') {
      params = params.set('_cifNo', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(environment.apiUrl_FCL + environmentAPI_FCL.refund, {
      headers: headers,
      params: params,
    });
  }
  GetFollowUp(
    params_select: any,
    params_value: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    let headers = this.getHeaderParams();

    let params = new HttpParams();

    if (params_select == '_partner') {
      params = params.set('_partner', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(environment.apiUrl_FCL + environmentAPI_FCL.followup, {
      headers: headers,
      params: params,
    });
  }
  PatchUpdateNote_Remark(data_node: any): Observable<any> {
    let headers = this.getHeaderParams();
    return this.http.patch(
      environment.apiUrl_FCL + environmentAPI_FCL.updateNodeAndRemark,
      data_node,
      { headers }
    );
  }
  PostUpdateBookIncome_Done(data_node: any): Observable<any> {
    let headers = this.getHeaderParams();
    return this.http.post(
      environment.apiUrl_FCL + environmentAPI_FCL.book_done,
      data_node,
      { headers }
    );
  }
  PostUpdateRefund_Done(data_node: any): Observable<any> {
    let headers = this.getHeaderParams();
    return this.http.post(
      environment.apiUrl_FCL + environmentAPI_FCL.refund_done,
      data_node,
      { headers }
    );
  }
  downloadFileAPI_Excel_FollowUp(
    params_startDt: any,
    params_endDt: any
  ): Observable<any> {
    let headers = this.getHeaderParamsContentTypePDF();
    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    return this.http.post(
      environment.apiUrl_FCL + environmentAPI_FCL.excel_followUp,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  downloadFileAPI_Excel_Refund(
    params_startDt: any,
    params_endDt: any
  ): Observable<any> {
    let headers = this.getHeaderParamsContentTypePDF();
    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    return this.http.post(
      environment.apiUrl_FCL + environmentAPI_FCL.excel_refund,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
}
