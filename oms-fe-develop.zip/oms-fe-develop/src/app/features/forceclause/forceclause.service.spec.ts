import { TestBed } from '@angular/core/testing';

import { ForceclauseService } from './forceclause.service';

describe('ForceclauseService', () => {
  let service: ForceclauseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ForceclauseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
