import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseListComponent } from './forceclause-list.component';

describe('ForceclauseListComponent', () => {
  let component: ForceclauseListComponent;
  let fixture: ComponentFixture<ForceclauseListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
