import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause',
  templateUrl: './forceclause.component.html',
  styleUrls: ['./forceclause.component.sass']
})
export class ForceclauseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
