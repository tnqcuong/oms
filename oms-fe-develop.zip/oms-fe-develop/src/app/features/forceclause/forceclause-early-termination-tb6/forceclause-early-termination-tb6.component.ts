import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-early-termination-tb6',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./forceclause-early-termination-tb6.component.sass']
})
export class ForceclauseEarlyTerminationTb6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
