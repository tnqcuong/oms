import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-early-termination-tb6',
  templateUrl: './forceclause-early-termination-tb6.component.html',
  styleUrls: ['./forceclause-early-termination-tb6.component.sass']
})
export class ForceclauseEarlyTerminationTb6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
