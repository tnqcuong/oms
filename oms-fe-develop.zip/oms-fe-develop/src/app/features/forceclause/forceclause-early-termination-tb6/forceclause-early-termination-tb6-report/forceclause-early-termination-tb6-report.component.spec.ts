import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseEarlyTerminationTb6ReportComponent } from './forceclause-early-termination-tb6-report.component';

describe('ForceclauseEarlyTerminationTb6ReportComponent', () => {
  let component: ForceclauseEarlyTerminationTb6ReportComponent;
  let fixture: ComponentFixture<ForceclauseEarlyTerminationTb6ReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseEarlyTerminationTb6ReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseEarlyTerminationTb6ReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
