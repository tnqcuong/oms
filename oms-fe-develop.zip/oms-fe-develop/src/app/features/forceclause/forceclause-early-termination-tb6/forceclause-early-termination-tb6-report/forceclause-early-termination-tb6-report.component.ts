import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-early-termination-tb6-report',
  templateUrl: './forceclause-early-termination-tb6-report.component.html',
  styleUrls: ['./forceclause-early-termination-tb6-report.component.sass']
})
export class ForceclauseEarlyTerminationTb6ReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
