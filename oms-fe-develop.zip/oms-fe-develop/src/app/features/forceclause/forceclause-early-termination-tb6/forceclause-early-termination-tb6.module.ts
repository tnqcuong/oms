import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclauseEarlyTerminationTb6RoutingModule } from './forceclause-early-termination-tb6.routing.module';
import { ForceclauseEarlyTerminationTb6ListComponent } from './forceclause-early-termination-tb6-list/forceclause-early-termination-tb6-list.component';
import { ForceclauseEarlyTerminationTb6ReportComponent } from './forceclause-early-termination-tb6-report/forceclause-early-termination-tb6-report.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclauseEarlyTerminationTb6ListComponent,
    ForceclauseEarlyTerminationTb6ReportComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseEarlyTerminationTb6RoutingModule
  ]
})
export class ForceclauseEarlyTerminationTb6Module { }
