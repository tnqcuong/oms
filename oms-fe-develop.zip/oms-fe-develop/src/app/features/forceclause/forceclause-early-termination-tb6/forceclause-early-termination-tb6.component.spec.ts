import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseEarlyTerminationTb6Component } from './forceclause-early-termination-tb6.component';

describe('ForceclauseEarlyTerminationTb6Component', () => {
  let component: ForceclauseEarlyTerminationTb6Component;
  let fixture: ComponentFixture<ForceclauseEarlyTerminationTb6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseEarlyTerminationTb6Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseEarlyTerminationTb6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
