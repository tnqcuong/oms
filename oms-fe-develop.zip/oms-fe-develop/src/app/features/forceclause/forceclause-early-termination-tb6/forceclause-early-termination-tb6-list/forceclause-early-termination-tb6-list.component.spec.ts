import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseEarlyTerminationTb6ListComponent } from './forceclause-early-termination-tb6-list.component';

describe('ForceclauseEarlyTerminationTb6ListComponent', () => {
  let component: ForceclauseEarlyTerminationTb6ListComponent;
  let fixture: ComponentFixture<ForceclauseEarlyTerminationTb6ListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseEarlyTerminationTb6ListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseEarlyTerminationTb6ListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
