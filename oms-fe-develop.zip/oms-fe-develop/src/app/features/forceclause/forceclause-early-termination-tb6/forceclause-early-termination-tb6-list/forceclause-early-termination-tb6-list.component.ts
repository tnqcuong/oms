import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-forceclause-early-termination-tb6-list',
  templateUrl: './forceclause-early-termination-tb6-list.component.html',
  styleUrls: ['./forceclause-early-termination-tb6-list.component.sass']
})
export class ForceclauseEarlyTerminationTb6ListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }


  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchForm: searchSelect[] = [
    {
      id: '_cif',
      value: 'CIF',
    },
  ];

  ngOnInit(): void {
  }
  getDataSearch() {
    console.log(this._lookupCodeId);
    console.log(this._valueSrech);
  }
  WaiveOff() {}
  Remove() {}
  Dummy() {}
  onFileChangeAPI(evt: any){}
  goToFCLTB6Report()
  {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/early-termination-tb6/report',
      0,
      true
    );
  }
  BackPage()
  {
    this.routeStateService.add(
      'List',
      '/main/forceclause',
      0,
      true
    );
  }
  MorePage()
  {

  }

}
