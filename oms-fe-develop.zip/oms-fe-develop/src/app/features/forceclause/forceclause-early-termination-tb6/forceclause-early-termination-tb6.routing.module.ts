import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclauseEarlyTerminationTb6ListComponent } from './forceclause-early-termination-tb6-list/forceclause-early-termination-tb6-list.component';
import { ForceclauseEarlyTerminationTb6ReportComponent } from './forceclause-early-termination-tb6-report/forceclause-early-termination-tb6-report.component';
import { ForceclauseEarlyTerminationTb6Component } from './forceclause-early-termination-tb6.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseEarlyTerminationTb6Component,
    children: [
      {
        path: '',
        component: ForceclauseEarlyTerminationTb6ListComponent
      },
      {
        path: 'report',
        component: ForceclauseEarlyTerminationTb6ReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForceclauseEarlyTerminationTb6RoutingModule { }
