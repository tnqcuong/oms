import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-maturity-book-income',
  templateUrl: './forceclause-maturity-book-income.component.html',
  styleUrls: ['./forceclause-maturity-book-income.component.sass']
})
export class ForceclauseMaturityBookIncomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
