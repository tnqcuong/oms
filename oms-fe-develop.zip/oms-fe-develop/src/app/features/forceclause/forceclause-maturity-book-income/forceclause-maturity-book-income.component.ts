import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { BookIcome } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';
@Component({
  selector: 'app-forceclause-maturity-book-income',
  templateUrl: './forceclause-maturity-book-income.component.html',
  styleUrls: ['./forceclause-maturity-book-income.component.sass']
})
export class ForceclauseMaturityBookIncomeComponent implements OnInit {

  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService
    ) {}

    startIndex: number = 0;
    endIndex: number = 0;

    DayNow = new Date();
    _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';


  _listsearchPayment: searchSelect[] = [
    {
      id: '_cifNo',
      value: 'CIF',
    },
  ];

  loading_BookIcome: boolean = false;
  loading_more: boolean = true;
  _arrBookIcomeList: BookIcome[] = [];
  _arrBookIcomeListAll: BookIcome[] = [];
  _arrBookIcomeListTrue: BookIcome[] = [];
  _arrBookIcomeListCount = 0;
  _pageBookIcomeList = 1;
  _tableSizeBookIcomeList = 5;
  _totalPage = 0;

  ngOnInit(): void {
    this.fetchGetBookIcome();
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetBookIcome() {
    this.loaderService.onLoading();
    this.FCLservice.GetMaturityBookIncome(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizeBookIcomeList,
      this._pageBookIcomeList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrBookIcomeList = [];
          this.loading_BookIcome = false;
          this.loaderService.offLoading();
        } else {
          this._arrBookIcomeList = [];
          this._arrBookIcomeList = data?.result?.data;
          this._arrBookIcomeListCount = data?.result?.count;
          this.loading_BookIcome = true;
          // set page
          this._totalPage =
            this._arrBookIcomeListCount / this._tableSizeBookIcomeList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrBookIcomeListAll = this._arrBookIcomeListAll.concat(
            this._arrBookIcomeList
          );

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Form Payment List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data Form Payment List'
        );
        this.loaderService.offLoading();
      }
    );
  }

  BackPage() {
    this.routeStateService.add(
      'List',
      '/main/forceclause',
      0,
      true
    );
  }
  getDataSearch(){
    this._pageBookIcomeList = 1;
    this._arrBookIcomeListAll = [];
    this.fetchGetBookIcome();
  }
  ListDoneUser()
  {}
  Done(){
    this._arrBookIcomeListTrue = [];
    this._arrBookIcomeListAll.map((item)=>{
      if(item.checked)
      {
        this._arrBookIcomeListTrue.push(item);
      }
    })
    this.loaderService.onLoading();
    if (this._arrBookIcomeListTrue.length > 0) {
      this.FCLservice.PostUpdateBookIncome_Done(
        this._arrBookIcomeListTrue
      ).subscribe(
        (data) => {
          // console.log(data);
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'Book Income Update Done',
            'Success Update Done'
          );
          this._arrBookIcomeListAll.map((item) => {
            item.checked = false;
          });
          // feth page
          this._pageBookIcomeList = 1;
          this._arrBookIcomeListAll = [];
          this.fetchGetBookIcome();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Book Income Update Done',
            error.error?.exceptionMessage
              ? error.error.exceptionMessage
              : 'No Update Done'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.loaderService.offLoading();
      this.toastService.addSingleShortTime(
        'warn',
        'Book Income Update Done',
        'Nothing Has Changed'
      );
    }
  }
  MorePage() {
    if (this._pageBookIcomeList < this._totalPage) {
      this._pageBookIcomeList = this._pageBookIcomeList + 1;
      this.fetchGetBookIcome();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'BookIcome List', 'Out of Data');
    }
  }

  toggleVisibility(event: any, row_GetFormtrx: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrBookIcomeListAll[i].checked = true;
        }
      } else {
        this._arrBookIcomeListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrBookIcomeListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked = false;
        }
      });
    }
  }


}
