import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseMaturityBookIncomeComponent } from './forceclause-maturity-book-income.component';

describe('ForceclauseMaturityBookIncomeComponent', () => {
  let component: ForceclauseMaturityBookIncomeComponent;
  let fixture: ComponentFixture<ForceclauseMaturityBookIncomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseMaturityBookIncomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseMaturityBookIncomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
