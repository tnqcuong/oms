import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclauseFormPaymentAvailableRoutingModule } from './forceclause-form-payment-available-routing.module';
import { ForceclauseFormPaymentAvailableListComponent } from './forceclause-form-payment-available-list/forceclause-form-payment-available-list.component';
import { ForceclauseFormPaymentAvailableReportComponent } from './forceclause-form-payment-available-report/forceclause-form-payment-available-report.component';
import { ForceclauseFormPaymentAvailableCheckerComponent } from './forceclause-form-payment-available-checker/forceclause-form-payment-available-checker.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclauseFormPaymentAvailableListComponent,
    ForceclauseFormPaymentAvailableReportComponent,
    ForceclauseFormPaymentAvailableCheckerComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseFormPaymentAvailableRoutingModule
  ]
})
export class ForceclauseFormPaymentAvailableModule { }
