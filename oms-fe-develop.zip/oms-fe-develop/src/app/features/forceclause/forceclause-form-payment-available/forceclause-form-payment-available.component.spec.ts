import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseFormPaymentAvailableComponent } from './forceclause-form-payment-available.component';

describe('ForceclauseFormPaymentAvailableComponent', () => {
  let component: ForceclauseFormPaymentAvailableComponent;
  let fixture: ComponentFixture<ForceclauseFormPaymentAvailableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseFormPaymentAvailableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseFormPaymentAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
