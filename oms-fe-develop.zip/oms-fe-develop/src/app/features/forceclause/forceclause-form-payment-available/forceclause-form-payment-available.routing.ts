import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForceclauseFormPaymentAvailableComponent } from './forceclause-form-payment-available.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'list',
  },
  {
    path: 'list',
    component: ForceclauseFormPaymentAvailableComponent,
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-form-payment-available/forceclause-form-payment-available-list/forceclause-form-payment-available-list.module'
      ).then((m) => m.ForceclauseFormPaymentAvailableListModule),
  },
  {
    path: 'report',
    component: ForceclauseFormPaymentAvailableComponent,
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-form-payment-available/forceclause-form-payment-available-report/forceclause-form-payment-available-report.module'
      ).then((m) => m.ForceclauseFormPaymentAvailableReportModule),
  },
  {
    path: 'checker',
    component: ForceclauseFormPaymentAvailableComponent,
    loadChildren: () =>
      import(
        'src/app/features/forceclause/forceclause-form-payment-available/forceclause-form-payment-available-checker/forceclause-form-payment-available-checker.module'
      ).then((m) => m.FForceclauseFormPaymentAvailableCheckerModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseFormPaymentAvailableRouting {}
