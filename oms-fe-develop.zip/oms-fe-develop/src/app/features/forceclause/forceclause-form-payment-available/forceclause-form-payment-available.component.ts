import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-form-payment-available',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./forceclause-form-payment-available.component.sass']
})
export class ForceclauseFormPaymentAvailableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
