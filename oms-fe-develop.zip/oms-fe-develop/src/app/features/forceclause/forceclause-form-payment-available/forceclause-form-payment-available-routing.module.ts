import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclauseFormPaymentAvailableCheckerComponent } from './forceclause-form-payment-available-checker/forceclause-form-payment-available-checker.component';
import { ForceclauseFormPaymentAvailableListComponent } from './forceclause-form-payment-available-list/forceclause-form-payment-available-list.component';
import { ForceclauseFormPaymentAvailableReportComponent } from './forceclause-form-payment-available-report/forceclause-form-payment-available-report.component';
import { ForceclauseFormPaymentAvailableComponent } from './forceclause-form-payment-available.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseFormPaymentAvailableComponent,
    children: [
      {
        path: '',
        component: ForceclauseFormPaymentAvailableListComponent
      },
      {
        path: 'report',
        component: ForceclauseFormPaymentAvailableReportComponent
      },
      {
        path: 'checker',
        component: ForceclauseFormPaymentAvailableCheckerComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForceclauseFormPaymentAvailableRoutingModule { }
