import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseFormPaymentAvailableCheckerComponent } from './forceclause-form-payment-available-checker.component';

describe('ForceclauseFormPaymentAvailableCheckerComponent', () => {
  let component: ForceclauseFormPaymentAvailableCheckerComponent;
  let fixture: ComponentFixture<ForceclauseFormPaymentAvailableCheckerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseFormPaymentAvailableCheckerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseFormPaymentAvailableCheckerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
