import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { FormPayment } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';

@Component({
  selector: 'app-forceclause-form-payment-available-list',
  templateUrl: './forceclause-form-payment-available-list.component.html',
  styleUrls: ['./forceclause-form-payment-available-list.component.sass'],
})
export class ForceclauseFormPaymentAvailableListComponent implements OnInit {
  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService
  ) {}

  startIndex: number = 0;
  endIndex: number = 0;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchForm: searchSelect[] = [
    {
      id: '_cifNo',
      value: 'CIF',
    },
  ];

  loading_FormPayment: boolean = false;
  loading_more: boolean = true;
  _arrFormPaymentList: FormPayment[] = [];
  _arrFormPaymentListAll: FormPayment[] = [];
  _arrFormPaymentListTrue: FormPayment[] = [];
  _arrFormPaymentListCount = 0;
  _pageFormPaymentList = 1;
  _tableSizeFormPaymentList = 5;
  _totalPage = 0;

  ngOnInit(): void {
    this.fetchGetFormPayment();
  }
  getDataSearch() {
    this._pageFormPaymentList = 1;
    this._arrFormPaymentListAll = [];
    this.fetchGetFormPayment();
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetFormPayment() {
    this.loaderService.onLoading();
    this.FCLservice.GetFormPayment(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizeFormPaymentList,
      this._pageFormPaymentList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrFormPaymentList = [];
          this.loading_FormPayment = false;
          this.loaderService.offLoading();
        } else {
          this._arrFormPaymentList = [];
          this._arrFormPaymentList = data?.result?.data;
          this._arrFormPaymentListCount = data?.result?.count;
          this.loading_FormPayment = true;
          // set page
          this._totalPage =
            this._arrFormPaymentListCount / this._tableSizeFormPaymentList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrFormPaymentListAll = this._arrFormPaymentListAll.concat(
            this._arrFormPaymentList
          );

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Form Payment List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data Form Payment List'
        );
        this.loaderService.offLoading();
      }
    );
  }

  CheckETFormScanDate(simulated_et_date: any) {
    const _simulated_et_date = moment(simulated_et_date, 'DD/MM/YYYY');
    const days = this._DayNow.diff(_simulated_et_date, 'days');
    // const days = _et_form_scan_datet.diff(this._DayNow, 'days');
    if (days > 2) {
      return 'Y';
    }
    return 'N';
  }

  toggleVisibility(event: any, row_GetFormtrx: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrFormPaymentListAll[i].checked = true;
        }
      } else {
        this._arrFormPaymentListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrFormPaymentListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked = false;
        }
      });
    }
  }

  Dummy() {}
  Done() {}
  WaiveOff() {}
  goToFCLFormPaymentAvailableReport() {
    this.routeStateService.add(
      'REPORT',
      '/main/forceclause/form-payment-available/report',
      0,
      true
    );
  }
  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  MorePage() {
    if (this._pageFormPaymentList < this._totalPage) {
      this._pageFormPaymentList = this._pageFormPaymentList + 1;
      this.fetchGetFormPayment();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'Form Payment List', 'Out of Data');
    }
  }
  goToFCLChecker() {
    this.routeStateService.add(
      'CHECKER',
      '/main/forceclause/form-payment-available/checker',
      0,
      true
    );
  }
}
