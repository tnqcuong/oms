import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-forceclause-form-payment-available-list',
  templateUrl: './forceclause-form-payment-available-list.component.html',
  styleUrls: ['./forceclause-form-payment-available-list.component.sass']
})
export class ForceclauseFormPaymentAvailableListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) {}

  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchForm: searchSelect[] = [
    {
      id: '_cif',
      value: 'CIF',
    },
  ];

  ngOnInit(): void {}
  getDataSearch() {
    console.log(this._lookupCodeId);
    console.log(this._valueSrech);
  }
  Dummy() {}
  Done() {}
  WaiveOff() {}
  goToFCLFormPaymentAvailableReport() {
    this.routeStateService.add(
      'REPORT',
      '/main/forceclause/form-payment-available/report',
      0,
      true
    );
  }
  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  MorePage() {}
  goToFCLChecker() {
    this.routeStateService.add(
      'CHECKER',
      '/main/forceclause/form-payment-available/checker',
      0,
      true
    );
  }

}
