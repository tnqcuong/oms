import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseFormPaymentAvailableListComponent } from './forceclause-form-payment-available-list.component';

describe('ForceclauseFormPaymentAvailableListComponent', () => {
  let component: ForceclauseFormPaymentAvailableListComponent;
  let fixture: ComponentFixture<ForceclauseFormPaymentAvailableListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseFormPaymentAvailableListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseFormPaymentAvailableListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
