import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseFormPaymentAvailableReportComponent } from './forceclause-form-payment-available-report.component';

describe('ForceclauseFormPaymentAvailableReportComponent', () => {
  let component: ForceclauseFormPaymentAvailableReportComponent;
  let fixture: ComponentFixture<ForceclauseFormPaymentAvailableReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseFormPaymentAvailableReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseFormPaymentAvailableReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
