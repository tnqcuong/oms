import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-forceclause-form-payment-available-report',
  templateUrl: './forceclause-form-payment-available-report.component.html',
  styleUrls: ['./forceclause-form-payment-available-report.component.sass']
})
export class ForceclauseFormPaymentAvailableReportComponent implements OnInit {

  constructor(
    private routeStateService: RouteStateService,
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
  ) {}
  _lookupCodeId = '';
  _valueSrech = '';

  DayNow = new Date();
  _endDt = new Date(moment(this.DayNow).dayOfYear(365).format('MM/DD/YYYY'));
  _startDt = new Date(moment(this.DayNow).dayOfYear(1).format('MM/DD/YYYY'));

  _listsearchRegistrantion: searchSelect[] = [
    {
      id: '_cif',
      value: 'CIF',
    },
  ];
  ngOnInit(): void {}
  BackPage() {
    this.routeStateService.add(
      'FORM PAYMENT AVAILABLE',
      '/main/forceclause/form-payment-available',
      0,
      true
    );
  }

  getDataSearch() {
    console.log(this._lookupCodeId);
    console.log(this._valueSrech);
  }
  confirm() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        // this.Export();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }


}
