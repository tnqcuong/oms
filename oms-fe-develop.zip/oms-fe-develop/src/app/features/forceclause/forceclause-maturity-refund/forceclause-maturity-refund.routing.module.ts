import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclauseMaturityRefundListComponent } from './forceclause-maturity-refund-list/forceclause-maturity-refund-list.component';
import { ForceclauseMaturityRefundReportComponent } from './forceclause-maturity-refund-report/forceclause-maturity-refund-report.component';
import { ForceclauseMaturityRefundComponent } from './forceclause-maturity-refund.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseMaturityRefundComponent,
    children: [
      {
        path: '',
        component: ForceclauseMaturityRefundListComponent
      },
      {
        path: 'report',
        component: ForceclauseMaturityRefundReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForceclauseMaturityRefundRoutingModule { }
