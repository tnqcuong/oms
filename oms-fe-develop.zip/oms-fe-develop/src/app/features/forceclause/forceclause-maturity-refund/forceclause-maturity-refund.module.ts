import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclauseMaturityRefundRoutingModule } from './forceclause-maturity-refund.routing.module';
import { ForceclauseMaturityRefundListComponent } from './forceclause-maturity-refund-list/forceclause-maturity-refund-list.component';
import { ForceclauseMaturityRefundReportComponent } from './forceclause-maturity-refund-report/forceclause-maturity-refund-report.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclauseMaturityRefundListComponent,
    ForceclauseMaturityRefundReportComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseMaturityRefundRoutingModule
  ]
})
export class ForceclauseMaturityRefundModule { }
