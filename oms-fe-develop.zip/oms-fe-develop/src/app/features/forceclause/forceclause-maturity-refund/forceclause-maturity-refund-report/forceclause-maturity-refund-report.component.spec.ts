import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseMaturityRefundReportComponent } from './forceclause-maturity-refund-report.component';

describe('ForceclauseMaturityRefundReportComponent', () => {
  let component: ForceclauseMaturityRefundReportComponent;
  let fixture: ComponentFixture<ForceclauseMaturityRefundReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseMaturityRefundReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseMaturityRefundReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
