import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Refund } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';
import { ExcelService } from 'src/app/core/services/excel.service';
@Component({
  selector: 'app-forceclause-maturity-refund-list',
  templateUrl: './forceclause-maturity-refund-list.component.html',
  styleUrls: ['./forceclause-maturity-refund-list.component.sass'],
})
export class ForceclauseMaturityRefundListComponent implements OnInit {
  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private exclesev: ExcelService,
  ) {}

  startIndex: number = 0;
  endIndex: number = 0;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchPayment: searchSelect[] = [
    {
      id: '_cifNo',
      value: 'CIF',
    },
  ];

  LastDate: Date = new Date(
    this.DayNow.getFullYear(),
    this.DayNow.getMonth() - 1,
    this.DayNow.getDate()
  );

  _endDt = new Date(moment(this.DayNow).format('MM/DD/YYYY'));
  _startDt = new Date(moment(this.LastDate).format('MM/DD/YYYY'));

  loading_Refund: boolean = false;
  loading_more: boolean = true;
  _arrRefundList: Refund[] = [];
  _arrRefundListAll: Refund[] = [];
  _arrRefundListTrue: Refund[] = [];
  _arrRefundListCount = 0;
  _pageRefundList = 1;
  _tableSizeRefundList = 5;
  _totalPage = 0;

  ngOnInit(): void {
    this.fetchGetRefund();
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetRefund() {
    this.loaderService.onLoading();
    this.FCLservice.GetMaturityRefund(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizeRefundList,
      this._pageRefundList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrRefundList = [];
          this.loading_Refund = false;
          this.loaderService.offLoading();
        } else {
          this._arrRefundList = [];
          this._arrRefundList = data?.result?.data;
          this._arrRefundListCount = data?.result?.count;
          this.loading_Refund = true;
          // set page
          this._totalPage =
            this._arrRefundListCount / this._tableSizeRefundList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrRefundListAll = this._arrRefundListAll.concat(
            this._arrRefundList
          );

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Refund List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data Refund List'
        );
        this.loaderService.offLoading();
      }
    );
  }

  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  goToFCLRefundReport() {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/maturity-refund/report',
      0,
      true
    );
  }
  getDataSearch() {
    this._pageRefundList = 1;
    this._arrRefundListAll = [];
    this.fetchGetRefund();
  }
  Done() {
    this._arrRefundListTrue = [];
    this._arrRefundListAll.map((item)=>{
      if(item.checked)
      {
        this._arrRefundListTrue.push(item);
      }
    })
    this.loaderService.onLoading();
    if (this._arrRefundListTrue.length > 0) {
      this.FCLservice.PostUpdateRefund_Done(
        this._arrRefundListTrue
      ).subscribe(
        (data) => {
          // console.log(data);
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'Refund Update Done',
            'Success Update Done'
          );
          this._arrRefundListAll.map((item) => {
            item.checked = false;
          });
          // feth page
          this._pageRefundList = 1;
          this._arrRefundListAll = [];
          this.fetchGetRefund();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Refund Update Done',
            error.error?.exceptionMessage
              ? error.error.exceptionMessage
              : 'No Update Done'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.loaderService.offLoading();
      this.toastService.addSingleShortTime(
        'warn',
        'Refund Update Done',
        'Nothing Has Changed'
      );
    }
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.FCLservice
      .downloadFileAPI_Excel_Refund(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
      )
      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'RefundDone',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'Export',
            'Success Export File'
          );
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }

          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }
  MorePage() {
    if (this._pageRefundList < this._totalPage) {
      this._pageRefundList = this._pageRefundList + 1;
      this.fetchGetRefund();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'Refund List', 'Out of Data');
    }
  }
  toggleVisibility(event: any, row_GetFormtrx: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrRefundListAll[i].checked = true;
        }
      } else {
        this._arrRefundListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrRefundListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked = false;
        }
      });
    }
  }
}
