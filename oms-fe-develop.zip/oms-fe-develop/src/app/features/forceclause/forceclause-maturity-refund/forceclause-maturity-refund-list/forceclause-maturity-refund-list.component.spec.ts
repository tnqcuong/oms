import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseMaturityRefundListComponent } from './forceclause-maturity-refund-list.component';

describe('ForceclauseMaturityRefundListComponent', () => {
  let component: ForceclauseMaturityRefundListComponent;
  let fixture: ComponentFixture<ForceclauseMaturityRefundListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseMaturityRefundListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseMaturityRefundListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
