import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-maturity-refund',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./forceclause-maturity-refund.component.sass']
})
export class ForceclauseMaturityRefundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
