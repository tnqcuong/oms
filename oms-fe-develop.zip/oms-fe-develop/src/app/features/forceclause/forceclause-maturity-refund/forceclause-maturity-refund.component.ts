import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-maturity-refund',
  templateUrl: './forceclause-maturity-refund.component.html',
  styleUrls: ['./forceclause-maturity-refund.component.sass']
})
export class ForceclauseMaturityRefundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
