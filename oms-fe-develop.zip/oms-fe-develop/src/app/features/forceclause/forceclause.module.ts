import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclauseRoutingModule } from './forceclause-routing.module';
import { ForceclauseComponent } from './forceclause.component';
import { ForceclauseListComponent } from './forceclause-list/forceclause-list.component';
import { ForceclauseEarlyTerminationFollowUpComponent } from './forceclause-early-termination-follow-up/forceclause-early-termination-follow-up.component';
import { ForceclauseEarlyTerminationTb6Component } from './forceclause-early-termination-tb6/forceclause-early-termination-tb6.component';
import { ForceclauseFormAvailableComponent } from './forceclause-form-available/forceclause-form-available.component';
import { ForceclauseFormPaymentAvailableComponent } from './forceclause-form-payment-available/forceclause-form-payment-available.component';
import { ForceclauseMaturityBookIncomeComponent } from './forceclause-maturity-book-income/forceclause-maturity-book-income.component';
import { ForceclauseMaturityRefundComponent } from './forceclause-maturity-refund/forceclause-maturity-refund.component';
import { ForceclauseMaturityWaiveOffComponent } from './forceclause-maturity-waive-off/forceclause-maturity-waive-off.component';
import { ForceclausePaymentAvailableComponent } from './forceclause-payment-available/forceclause-payment-available.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclauseComponent,
    ForceclauseListComponent,
    ForceclauseEarlyTerminationFollowUpComponent,
    ForceclauseEarlyTerminationTb6Component,
    ForceclauseFormAvailableComponent,
    ForceclauseFormPaymentAvailableComponent,
    ForceclauseMaturityBookIncomeComponent,
    ForceclauseMaturityRefundComponent,
    ForceclauseMaturityWaiveOffComponent,
    ForceclausePaymentAvailableComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseRoutingModule
  ]
})
export class ForceclauseModule { }
