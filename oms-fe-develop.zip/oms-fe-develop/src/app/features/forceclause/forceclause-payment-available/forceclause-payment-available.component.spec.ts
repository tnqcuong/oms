import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclausePaymentAvailableComponent } from './forceclause-payment-available.component';

describe('ForceclausePaymentAvailableComponent', () => {
  let component: ForceclausePaymentAvailableComponent;
  let fixture: ComponentFixture<ForceclausePaymentAvailableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclausePaymentAvailableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclausePaymentAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
