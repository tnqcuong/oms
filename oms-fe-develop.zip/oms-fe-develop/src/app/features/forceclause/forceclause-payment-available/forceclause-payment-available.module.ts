import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclausePaymentAvailableRoutingModule } from './forceclause-payment-available-routing.module';
import { ForceclausePaymentAvailableListComponent } from './forceclause-payment-available-list/forceclause-payment-available-list.component';
import { ForceclausePaymentAvailableReportComponent } from './forceclause-payment-available-report/forceclause-payment-available-report.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclausePaymentAvailableListComponent,
    ForceclausePaymentAvailableReportComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclausePaymentAvailableRoutingModule
  ]
})
export class ForceclausePaymentAvailableModule { }
