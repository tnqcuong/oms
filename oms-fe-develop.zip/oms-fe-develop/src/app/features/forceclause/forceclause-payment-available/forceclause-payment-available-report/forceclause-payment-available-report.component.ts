import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-forceclause-payment-available-report',
  templateUrl: './forceclause-payment-available-report.component.html',
  styleUrls: ['./forceclause-payment-available-report.component.sass']
})
export class ForceclausePaymentAvailableReportComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }
  _lookupCodeId = '';
  _valueSrech = '';

  ngOnInit(): void {
  }
  DayNow = new Date();
  _endDt = new Date(moment(this.DayNow).dayOfYear(365).format('MM/DD/YYYY'));
  _startDt = new Date(
    moment(this.DayNow).dayOfYear(1).format('MM/DD/YYYY')
  );

  _listsearchRegistrantion: searchSelect[] = [
    {
      id: '_cif',
      value: 'CIF',
    },
  ];

  BackPage()
  {
    this.routeStateService.add(
      'PAYMENT AVAILABLE',
      '/main/forceclause/payment-available',
      0,
      true
    );
  }

  getDataSearch()
  {
    console.log(this._lookupCodeId);
    console.log(this._valueSrech);
  }

}
