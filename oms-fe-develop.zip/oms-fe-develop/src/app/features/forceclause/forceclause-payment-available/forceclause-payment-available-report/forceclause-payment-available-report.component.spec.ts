import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclausePaymentAvailableReportComponent } from './forceclause-payment-available-report.component';

describe('ForceclausePaymentAvailableReportComponent', () => {
  let component: ForceclausePaymentAvailableReportComponent;
  let fixture: ComponentFixture<ForceclausePaymentAvailableReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclausePaymentAvailableReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclausePaymentAvailableReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
