import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-forceclause-payment-available-list',
  templateUrl: './forceclause-payment-available-list.component.html',
  styleUrls: ['./forceclause-payment-available-list.component.sass']
})
export class ForceclausePaymentAvailableListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) {}

  _lookupCodeId = '';
  _valueSrech = '';


  _listsearchPayment: searchSelect[] = [
    {
      id: '_cif',
      value: 'CIF',
    },
  ];

  ngOnInit(): void {}

  BackPage() {
    this.routeStateService.add(
      'List',
      '/main/forceclause',
      0,
      true
    );
  }
  goToFCLPaymentAvailableReport() {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/payment-available/report',
      0,
      true
    );
  }
  getDataSearch(){}
  Remove(){}
  ET(){}
  MorePage(){}
}
