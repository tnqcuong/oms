import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Payment } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';

@Component({
  selector: 'app-forceclause-payment-available-list',
  templateUrl: './forceclause-payment-available-list.component.html',
  styleUrls: ['./forceclause-payment-available-list.component.sass'],
})
export class ForceclausePaymentAvailableListComponent implements OnInit {
  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService
  ) {}

  startIndex: number = 0;
  endIndex: number = 0;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchPayment: searchSelect[] = [
    {
      id: '_cifNo',
      value: 'CIF',
    },
  ];

  loading_payment: boolean = false;
  loading_more: boolean = true;
  _arrPaymentList: Payment[] = [];
  _arrPaymentListAll: Payment[] = [];
  _arrPaymentListTrue: Payment[] = [];
  _arrPaymentListCount = 0;
  _pagePaymentList = 1;
  _tableSizePaymentList = 5;
  _totalPage = 0;

  ngOnInit(): void {this.fetchGetPayment();}
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetPayment() {
    this.loaderService.onLoading();
    this.FCLservice.GetPayment(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizePaymentList,
      this._pagePaymentList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrPaymentList = [];
          this.loading_payment = false;
          this.loaderService.offLoading();
        } else {
          this._arrPaymentList = [];
          this._arrPaymentList = data?.result?.data;
          this._arrPaymentListCount = data?.result?.count;
          this.loading_payment = true;
          // set page
          this._totalPage = this._arrPaymentListCount / this._tableSizePaymentList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrPaymentListAll = this._arrPaymentListAll.concat(this._arrPaymentList);

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Payment List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data Payment List'
        );
        this.loaderService.offLoading();
      }
    );
  }
  CheckETFormScanDate(et_form_scan_date: any) {
    const _et_form_scan_datet = moment(et_form_scan_date, 'DD/MM/YYYY');
    const days = this._DayNow.diff(_et_form_scan_datet, 'days');
    // const days = _et_form_scan_datet.diff(this._DayNow, 'days');
    if (days >= 5) {
      return 'D';
    } else if (days >= 3) {
      return 'V';
    }
    return 'N';
  }

  toggleVisibility(event: any, row_GetFormtrx: any, i: any){
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrPaymentListAll[i].checked = true;
        }
      } else {
        this._arrPaymentListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrPaymentListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked = false;
        }
      });
    }
  }

  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  goToFCLPaymentAvailableReport() {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/payment-available/report',
      0,
      true
    );
  }
  getDataSearch() {
    this._pagePaymentList = 1;
    this._arrPaymentListAll = [];
    this.fetchGetPayment();
  }
  Remove() {}
  ET() {}
  MorePage() {
    if (this._pagePaymentList < this._totalPage) {
      this._pagePaymentList = this._pagePaymentList + 1;
      this.fetchGetPayment();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'Form List', 'Out of Data');
    }
  }
}
