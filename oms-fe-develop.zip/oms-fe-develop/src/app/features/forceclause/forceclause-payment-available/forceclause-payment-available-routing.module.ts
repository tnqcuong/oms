import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclausePaymentAvailableListComponent } from './forceclause-payment-available-list/forceclause-payment-available-list.component';
import { ForceclausePaymentAvailableReportComponent } from './forceclause-payment-available-report/forceclause-payment-available-report.component';
import { ForceclausePaymentAvailableComponent } from './forceclause-payment-available.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclausePaymentAvailableComponent,
    children: [
      {
        path: '',
        component: ForceclausePaymentAvailableListComponent
      },
      {
        path: 'report',
        component: ForceclausePaymentAvailableReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForceclausePaymentAvailableRoutingModule { }
