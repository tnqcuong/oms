import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-payment-available',
  templateUrl: './forceclause-payment-available.component.html',
  styleUrls: ['./forceclause-payment-available.component.sass']
})
export class ForceclausePaymentAvailableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
