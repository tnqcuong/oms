import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseComponent } from './forceclause.component';

describe('ForceclauseComponent', () => {
  let component: ForceclauseComponent;
  let fixture: ComponentFixture<ForceclauseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
