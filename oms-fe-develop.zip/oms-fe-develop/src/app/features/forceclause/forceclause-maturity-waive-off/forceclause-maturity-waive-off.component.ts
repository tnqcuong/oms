import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-maturity-waive-off',
  templateUrl: './forceclause-maturity-waive-off.component.html',
  styleUrls: ['./forceclause-maturity-waive-off.component.sass']
})
export class ForceclauseMaturityWaiveOffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
