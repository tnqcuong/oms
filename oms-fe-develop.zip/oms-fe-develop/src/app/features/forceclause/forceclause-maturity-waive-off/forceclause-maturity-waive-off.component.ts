import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forceclause-maturity-waive-off',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./forceclause-maturity-waive-off.component.sass']
})
export class ForceclauseMaturityWaiveOffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
