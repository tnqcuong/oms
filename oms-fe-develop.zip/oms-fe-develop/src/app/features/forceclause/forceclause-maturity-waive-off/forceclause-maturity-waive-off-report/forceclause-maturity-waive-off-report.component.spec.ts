import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseMaturityWaiveOffReportComponent } from './forceclause-maturity-waive-off-report.component';

describe('ForceclauseMaturityWaiveOffReportComponent', () => {
  let component: ForceclauseMaturityWaiveOffReportComponent;
  let fixture: ComponentFixture<ForceclauseMaturityWaiveOffReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseMaturityWaiveOffReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseMaturityWaiveOffReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
