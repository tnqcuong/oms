import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseMaturityWaiveOffComponent } from './forceclause-maturity-waive-off.component';

describe('ForceclauseMaturityWaiveOffComponent', () => {
  let component: ForceclauseMaturityWaiveOffComponent;
  let fixture: ComponentFixture<ForceclauseMaturityWaiveOffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseMaturityWaiveOffComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseMaturityWaiveOffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
