import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclauseMaturityWaiveOffListComponent } from './forceclause-maturity-waive-off-list/forceclause-maturity-waive-off-list.component';
import { ForceclauseMaturityWaiveOffReportComponent } from './forceclause-maturity-waive-off-report/forceclause-maturity-waive-off-report.component';
import { ForceclauseMaturityWaiveOffComponent } from './forceclause-maturity-waive-off.component';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseMaturityWaiveOffComponent,
    children: [
      {
        path: '',
        component: ForceclauseMaturityWaiveOffListComponent
      },
      {
        path: 'report',
        component: ForceclauseMaturityWaiveOffReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForceclauseMaturityWaiveOffRoutingModule { }
