import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForceclauseMaturityWaiveOffRoutingModule } from './forceclause-maturity-waive-off.routing.module';
import { ForceclauseMaturityWaiveOffListComponent } from './forceclause-maturity-waive-off-list/forceclause-maturity-waive-off-list.component';
import { ForceclauseMaturityWaiveOffReportComponent } from './forceclause-maturity-waive-off-report/forceclause-maturity-waive-off-report.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [
    ForceclauseMaturityWaiveOffListComponent,
    ForceclauseMaturityWaiveOffReportComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    ForceclauseMaturityWaiveOffRoutingModule
  ]
})
export class ForceclauseMaturityWaiveOffModule { }
