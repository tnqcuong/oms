import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForceclauseMaturityWaiveOffListComponent } from './forceclause-maturity-waive-off-list.component';

describe('ForceclauseMaturityWaiveOffListComponent', () => {
  let component: ForceclauseMaturityWaiveOffListComponent;
  let fixture: ComponentFixture<ForceclauseMaturityWaiveOffListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForceclauseMaturityWaiveOffListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForceclauseMaturityWaiveOffListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
