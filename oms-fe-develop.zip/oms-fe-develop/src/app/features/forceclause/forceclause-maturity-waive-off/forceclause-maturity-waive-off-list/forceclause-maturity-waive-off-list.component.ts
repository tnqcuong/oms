import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { WaiveOff } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';
@Component({
  selector: 'app-forceclause-maturity-waive-off-list',
  templateUrl: './forceclause-maturity-waive-off-list.component.html',
  styleUrls: ['./forceclause-maturity-waive-off-list.component.sass'],
})
export class ForceclauseMaturityWaiveOffListComponent implements OnInit {
  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService
  ) {}

  startIndex: number = 0;
  endIndex: number = 0;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchPayment: searchSelect[] = [
    {
      id: '_cifNo',
      value: 'CIF',
    },
  ];

  loading_WaiveOff: boolean = false;
  loading_more: boolean = true;
  _arrWaiveOffList: WaiveOff[] = [];
  _arrWaiveOffListAll: WaiveOff[] = [];
  _arrWaiveOffListTrue: WaiveOff[] = [];
  _arrWaiveOffListCount = 0;
  _pageWaiveOffList = 1;
  _tableSizeWaiveOffList = 5;
  _totalPage = 0;

  ngOnInit(): void {
    this.fetchGetWaiveOff();
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetWaiveOff() {
    this.loaderService.onLoading();
    this.FCLservice.GetMaturityOff(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizeWaiveOffList,
      this._pageWaiveOffList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrWaiveOffList = [];
          this.loading_WaiveOff = false;
          this.loaderService.offLoading();
        } else {
          this._arrWaiveOffList = [];
          this._arrWaiveOffList = data?.result?.data;
          this._arrWaiveOffListCount = data?.result?.count;
          this.loading_WaiveOff = true;
          // set page
          this._totalPage =
            this._arrWaiveOffListCount / this._tableSizeWaiveOffList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrWaiveOffListAll = this._arrWaiveOffListAll.concat(
            this._arrWaiveOffList
          );

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'WaiveOff List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data WaiveOff List'
        );
        this.loaderService.offLoading();
      }
    );
  }

  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  goToFCLWaiveOffReport() {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/maturity-waive-off/report',
      0,
      true
    );
  }
  getDataSearch() {
    this._pageWaiveOffList = 1;
    this._arrWaiveOffListAll = [];
    this.fetchGetWaiveOff();
  }
  WaiveOff() {}
  MorePage() {
    if (this._pageWaiveOffList < this._totalPage) {
      this._pageWaiveOffList = this._pageWaiveOffList + 1;
      this.fetchGetWaiveOff();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'WaiveOff List', 'Out of Data');
    }
  }
}
