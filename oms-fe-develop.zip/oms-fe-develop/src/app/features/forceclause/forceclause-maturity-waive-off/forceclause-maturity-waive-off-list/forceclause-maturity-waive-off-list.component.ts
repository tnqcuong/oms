import { Component, OnInit } from '@angular/core';
import { searchSelect } from 'src/app/core/models/Forceclause.model';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ForceclauseService } from 'src/app/features/forceclause/forceclause.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { WaiveOff } from 'src/app/core/models/FCL.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as moment from 'moment';
import { ExcelService } from 'src/app/core/services/excel.service';
@Component({
  selector: 'app-forceclause-maturity-waive-off-list',
  templateUrl: './forceclause-maturity-waive-off-list.component.html',
  styleUrls: ['./forceclause-maturity-waive-off-list.component.sass'],
})
export class ForceclauseMaturityWaiveOffListComponent implements OnInit {
  constructor(
    private routeStateService: RouteStateService,
    private FCLservice: ForceclauseService,
    private loaderService: LoaderService,
    private toastService: ToastService,
    private exclesev: ExcelService,
  ) {}

  startIndex: number = 0;
  endIndex: number = 0;

  display_WaiveOff: boolean = false;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _lookupCodeId = '';
  _valueSrech = '';

  _listsearchPayment: searchSelect[] = [
    {
      id: '_cifNo',
      value: 'CIF',
    },
  ];

  LastDate: Date = new Date(
    this.DayNow.getFullYear(),
    this.DayNow.getMonth() - 1,
    this.DayNow.getDate()
  );

  _endDt = new Date(moment(this.DayNow).format('MM/DD/YYYY'));
  _startDt = new Date(moment(this.LastDate).format('MM/DD/YYYY'));

  loading_WaiveOff: boolean = false;
  loading_more: boolean = true;
  _arrWaiveOffList: WaiveOff[] = [];
  _arrWaiveOffListAll: WaiveOff[] = [];
  _arrWaiveOffListTrue: WaiveOff[] = [];
  _arrWaiveOffListCount = 0;
  _pageWaiveOffList = 1;
  _tableSizeWaiveOffList = 5;
  _totalPage = 0;

  ngOnInit(): void {
    this.fetchGetWaiveOff();
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchGetWaiveOff() {
    this.loaderService.onLoading();
    this.FCLservice.GetMaturityOff(
      this._lookupCodeId,
      this._valueSrech,
      this._tableSizeWaiveOffList,
      this._pageWaiveOffList
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrWaiveOffList = [];
          this.loading_WaiveOff = false;
          this.loaderService.offLoading();
        } else {
          this._arrWaiveOffList = [];
          this._arrWaiveOffList = data?.result?.data;
          this._arrWaiveOffListCount = data?.result?.count;
          this.loading_WaiveOff = true;
          // set page
          this._totalPage =
            this._arrWaiveOffListCount / this._tableSizeWaiveOffList;
          if (this._totalPage > Math.floor(this._totalPage)) {
            this._totalPage = Math.floor(this._totalPage) + 1;
          }

          this._arrWaiveOffListAll = this._arrWaiveOffListAll.concat(
            this._arrWaiveOffList
          );

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'WaiveOff List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data WaiveOff List'
        );
        this.loaderService.offLoading();
      }
    );
  }
  toggleVisibility(event: any, row_GetFormtrx: any, i: any) {
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrWaiveOffListAll[i].checked = true;
        }
      } else {
        this._arrWaiveOffListAll.forEach((trx) => {
          if (trx.loan_no === row_GetFormtrx.loan_no) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrWaiveOffListAll.forEach((trx) => {
        if (trx.loan_no === row_GetFormtrx.loan_no) {
          trx.checked = false;
        }
      });
    }
  }

  BackPage() {
    this.routeStateService.add('List', '/main/forceclause', 0, true);
  }
  goToFCLWaiveOffReport() {
    this.routeStateService.add(
      'FORM AVAILABLE',
      '/main/forceclause/maturity-waive-off/report',
      0,
      true
    );
  }
  getDataSearch() {
    this._pageWaiveOffList = 1;
    this._arrWaiveOffListAll = [];
    this.fetchGetWaiveOff();
  }
  CloseDialog_WaiveOff() {
    this.display_WaiveOff = false;
  }
  onSubmitWaiveOff() {
    this.loaderService.onLoading();
    this.FCLservice.PostWaiveOff(this._arrWaiveOffListTrue).subscribe(
      (data) => {
        console.log(data);
        this.loaderService.offLoading();
      },
      (error) => {
        console.log(error);
        this.loaderService.offLoading();
      }
    );
  }
  WaiveOff() {
    this._arrWaiveOffListTrue = [];

    this._arrWaiveOffListAll.map((item) => {
      if (item.checked) {
        this._arrWaiveOffListTrue.push(item);
      }
    });
    if (this._arrWaiveOffListTrue.length > 0) {
      this.display_WaiveOff = true;
    } else {
      this.toastService.addSingleShortTime(
        'warn',
        'WaiveOff',
        'Nothing Has Changed'
      );
    }
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.FCLservice
      .downloadFileAPI_Excel_WaiveOff(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
      )
      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'WaiveOff',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'Export',
            'Success Export File'
          );
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }

          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }
  MorePage() {
    if (this._pageWaiveOffList < this._totalPage) {
      this._pageWaiveOffList = this._pageWaiveOffList + 1;
      this.fetchGetWaiveOff();
      this.loading_more = true;
    } else {
      this.loading_more = false;
      this.toastService.addSingle('warn', 'WaiveOff List', 'Out of Data');
    }
  }
  CheckETFormScanDate(day_diff: any) {
    const day = Number(day_diff);
    if (day > 5) return 'V';
    return 'A';
  }
}
