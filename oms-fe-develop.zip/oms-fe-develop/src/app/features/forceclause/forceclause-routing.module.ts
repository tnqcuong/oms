import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForceclauseEarlyTerminationFollowUpComponent } from './forceclause-early-termination-follow-up/forceclause-early-termination-follow-up.component';
import { ForceclauseEarlyTerminationTb6Component } from './forceclause-early-termination-tb6/forceclause-early-termination-tb6.component';
import { ForceclauseFormAvailableComponent } from './forceclause-form-available/forceclause-form-available.component';
import { ForceclauseFormPaymentAvailableComponent } from './forceclause-form-payment-available/forceclause-form-payment-available.component';
import { ForceclauseListComponent } from './forceclause-list/forceclause-list.component';
import { ForceclauseMaturityBookIncomeComponent } from './forceclause-maturity-book-income/forceclause-maturity-book-income.component';
import { ForceclauseMaturityRefundComponent } from './forceclause-maturity-refund/forceclause-maturity-refund.component';
import { ForceclauseMaturityWaiveOffComponent } from './forceclause-maturity-waive-off/forceclause-maturity-waive-off.component';
import { ForceclausePaymentAvailableComponent } from './forceclause-payment-available/forceclause-payment-available.component';
import { ForceclauseComponent } from './forceclause.component';
import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';
import { Url_OMS } from 'src/environments/environmentAPI';

const routes: Routes = [
  {
    path: '',
    component: ForceclauseComponent,
    children: [
      {
        path: '',
        component: ForceclauseListComponent,
      },
      {
        path: 'form-available',
        loadChildren: () =>
          import(
            'src/app/features/forceclause/forceclause-form-available/forceclause-form-available.module'
          ).then((m) => m.ForceclauseFormAvailableModule),
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_FORMAVAILABLE] },
      },
      {
        path: 'payment-available',
        loadChildren: () =>
          import(
            'src/app/features/forceclause/forceclause-payment-available/forceclause-payment-available.module'
          ).then((m) => m.ForceclausePaymentAvailableModule),
        canActivate: [AuthGuard],
        data: {
          feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_PAYMENTAVAILABLE],
        },
      },
      {
        path: 'form-payment-available',
        loadChildren: () =>
          import(
            'src/app/features/forceclause/forceclause-form-payment-available/forceclause-form-payment-available.module'
          ).then((m) => m.ForceclauseFormPaymentAvailableModule),
        canActivate: [AuthGuard],
        data: {
          feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_FORMPAYMENTAVAILABLE],
        },
      },
      {
        path: 'early-termination-tb6',
        loadChildren: () =>
          import(
            'src/app/features/forceclause/forceclause-early-termination-tb6/forceclause-early-termination-tb6.module'
          ).then((m) => m.ForceclauseEarlyTerminationTb6Module),
        canActivate: [AuthGuard],
        data: {
          feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_TB6],
        },
      },
      {
        path: 'maturity-waive-off',
        loadChildren: () =>
          import(
            'src/app/features/forceclause/forceclause-maturity-waive-off/forceclause-maturity-waive-off.module'
          ).then((m) => m.ForceclauseMaturityWaiveOffModule),
        canActivate: [AuthGuard],
        data: {
          feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_MATURITY_WAIVEOFF],
        },
      },
      {
        path: 'maturity-book-income',
        component: ForceclauseMaturityBookIncomeComponent,
        canActivate: [AuthGuard],
        data: {
          feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_MATURITY_BOOKINCOME],
        },
      },
      {
        path: 'maturity-refund',
        loadChildren: () =>
          import(
            'src/app/features/forceclause/forceclause-maturity-refund/forceclause-maturity-refund.module'
          ).then((m) => m.ForceclauseMaturityRefundModule),
        canActivate: [AuthGuard],
        data: {
          feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_MATURITY_REFUND],
        },
      },
      {
        path: 'early-termination-follow-up',
        loadChildren: () =>
          import(
            'src/app/features/forceclause/forceclause-early-termination-follow-up/forceclause-early-termination-follow-up.module'
          ).then((m) => m.ForceclauseEarlyTerminationFollowUpModule),
        canActivate: [AuthGuard],
        data: {
          feature: [Url_OMS.URL_FEATURE_EARLYTERMINATION_FOLLOWUP],
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ForceclauseRoutingModule {}
