import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/core/models/user.model';
import { LoaderService } from 'src/app/core/services/loader.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { UserContextService } from 'src/app/core/services/user-context.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.sass'],
})
export class DashboardComponent implements OnInit {
  user: null ;
  constructor(
    private routeStateService: RouteStateService,
    private loaderService: LoaderService,
    private userContextService: UserContextService
  ) {
  }
  ngOnInit(): void {
    this.loaderService.showHeader();
  }
  goToReconciliation(department: number) {
    this.routeStateService.add(
      'Reconciliation',
      '/main/reconciliation',
      department,
      false
    );
  }
  goToAutoDebit(department: number) {
    this.routeStateService.add('Auto-Debit', '/main/auto-debit', department, false);
  }
  goToForceclause(department: number) {
    this.routeStateService.add(
      'Forceclause',
      '/main/forceclause',
      department,
      false
    );
  }
  goToRedisbursal(department: number) {
    this.routeStateService.add(
      'Re-Disbursal',
      '/main/re-disbursal',
      department,
      false
    );
  }
  goToRefund(department: number) {
    this.routeStateService.add(
      'Refund',
      '/main/refund',
      department,
      false
    );
  }
}
