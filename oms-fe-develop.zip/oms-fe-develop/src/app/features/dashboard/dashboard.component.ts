import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/core/services/loader.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.sass'],
})
export class DashboardComponent implements OnInit {
  constructor(private routeStateService: RouteStateService, private loaderService: LoaderService) {}
  ngOnInit(): void {
    this.loaderService.showHeader();
  }
  goToReconciliation(department: number) {
    this.routeStateService.add(
      'Reconciliation',
      '/reconciliation',
      department,
      false
    );
  }
  goToAutoDebit(department: number) {
    this.routeStateService.add(
      'Auto-Debit',
      '/auto-debit',
      department,
      false
    );
  }
  goToForceclause(department: number) {
    this.routeStateService.add(
      'Forceclause',
      '/forceclause',
      department,
      false
    );
  }
  goToRedisbursal(department: number) {
    this.routeStateService.add(
      'Re-Disbursal',
      '/re-disbursal',
      department,
      false
    );
  }
}
