import { TestBed } from '@angular/core/testing';

import { ReDisbursalService } from './re-disbursal.service';

describe('ReDisbursalService', () => {
  let service: ReDisbursalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReDisbursalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
