import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReDisbursalComponent } from './re-disbursal.component';

describe('ReDisbursalComponent', () => {
  let component: ReDisbursalComponent;
  let fixture: ComponentFixture<ReDisbursalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReDisbursalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReDisbursalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
