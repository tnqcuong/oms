import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { SessionService } from 'src/app/core/services/session.service';
import { environment } from 'src/environments/environment';
import { environmentAPI_ReDisbursal } from 'src/environments/environmentAPI';

@Injectable({
  providedIn: 'root'
})
export class ReDisbursalService {

  constructor(
    private http: HttpClient,
    private commonUtilityService: CommonUtilityService
  ) { }

  getReDisbursalData(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    _searchType: string,
    _searchValue: string,
  ): Observable<any>{

    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (_searchType === '_ref') {
      params = params.set('_ref', _searchValue);
    } else if (_searchType === '_loanNo') {
      params = params.set('_loanNo', _searchValue);
    }

    return this.http.get<any>(environment.apiUrl_Redisbursal + environmentAPI_ReDisbursal.redisbursalTrx,
      { headers: headerParams, params: params });
  }

  exportReDisbursalReport(
    startDt: string,
    endDt: string,
    bankCode: string,
    type: string
  ): Observable<any> {
    let headers = this.commonUtilityService.getPDFHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', startDt);
    params = params.set('_endDt', endDt);
    params = params.set('_bankCode', bankCode);
    params = params.set('_type', type);
    return this.http.post(
      environment.apiUrl_Redisbursal + environmentAPI_ReDisbursal.redisbursalReport,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  updateRedisbursalData(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    _searchType: string,
    _searchValue: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.commonUtilityService.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (_searchType === '_ref') {
      params = params.set('_ref', _searchValue);
    } else if (_searchType === '_loanNo') {
      params = params.set('_loanNo', _searchValue);
    }

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl_Redisbursal + environmentAPI_ReDisbursal.redisbursalTrx,
      body,
      { headers: headerParams, params: params }
    );
  }
}
