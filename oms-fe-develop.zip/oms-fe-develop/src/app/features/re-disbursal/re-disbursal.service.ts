import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SessionService } from 'src/app/core/services/session.service';
import { environment } from 'src/environments/environment';
import { environmentAPI_ReDisbursal } from 'src/environments/environmentAPI';

@Injectable({
  providedIn: 'root'
})
export class ReDisbursalService {

  constructor(
    private http: HttpClient,
    private sessionService: SessionService,
  ) { }

  user = this.sessionService.getItem('currentUser');

  getHeaderParams() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'access-token': this.user.token,
    });
  }

  getReDisbursalData(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    _searchType: string,
    _searchValue: string,
  ): Observable<any>{

    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (_searchType === '_ref') {
      params = params.set('_ref', _searchValue);
    } else if (_searchType === '_loanNo') {
      params = params.set('_loanNo', _searchValue);
    }

    return this.http.get<any>(environment.apiUrl + environmentAPI_ReDisbursal.redisbursalTrx,
      { headers: headerParams, params: params });
  }
}
