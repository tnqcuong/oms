import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { Redisbursal } from 'src/app/core/models/redisbursal-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReDisbursalService } from './re-disbursal.service';
import * as file from 'file-saver';

@Component({
  selector: 'app-re-disbursal',
  templateUrl: './re-disbursal.component.html',
  styleUrls: ['./re-disbursal.component.sass']
})
export class ReDisbursalComponent implements OnInit {

  _today = new Date();
  startDt = this._today;
  endDt = this._today;
  _number: string = '100';
  _start: string = '1';
  _totalTrx: number = 0;

  disBankList: MetaData[] = [];
  searchTypeList: SearchType[] = [];
  _searchTypeList: SearchType[] = [];
  selectedBank: string = '';
  searchingValue: string = '';
  selectedSearchType: string = '_ref';

  redisbursalData: Redisbursal[] = [];

  constructor(
    private reDisbursalService: ReDisbursalService,
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService
  ) {
    this.disBankList = commonUtilityService.bankDisbList;
    this._searchTypeList = commonUtilityService.bankDisbSearchType;
  }

  ngOnInit(): void {
    this.getReDisbursalData();
  }

  getReDisbursalData() {
    this.loaderService.onLoading();
    this.reDisbursalService
      .getReDisbursalData(
        moment(this.startDt).format('DD/MM/YYYY'),
        moment(this.endDt).add(1, 'days').format('DD/MM/YYYY'),
        this.selectedBank,
        this._number,
        this._start,
        '',
        '',
      )
      .subscribe(
        (data) => {
          this.redisbursalData = data.result.data;
          console.log(this.redisbursalData)
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle('error', 'Error', error.error?.exceptionMessage ? error.error?.exceptionMessage : 'Server error.');
        }
      );
  }

  searchTransaction(){

  }

  confirmAndExport(){
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Excel',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.exportRedisbursalReport();
      },
      reject: () => {
      },
    });
  }

  exportRedisbursalReport(){
    this.loaderService.onLoading();
    this.reDisbursalService.exportReDisbursalReport(
        moment(this.startDt).format('DD/MM/YYYY'),
        moment(this.endDt).format('DD/MM/YYYY'),
        '100',
        '1'
        ).subscribe(
        (response) => {
          this.downloadFile(response.body);
          this.loaderService.offLoading();
        },
        (error) => {
          let jsonErr = this.commonUtilityService.convertByteArrayToJSON(error);

          this.toastService.addSingle(
            'error',
            'Export',
            jsonErr?.exceptionMessage
              ? jsonErr.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }

  downloadFile(data: any) {
    const fileName = 'Redisbursal_Report';
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + moment(this._today).format('DD/MM/YYYY'));
  }

  selectBankTransaction(item: any, event: any, i: any) {

  }
}
