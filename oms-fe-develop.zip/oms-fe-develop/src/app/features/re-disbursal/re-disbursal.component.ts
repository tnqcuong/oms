import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReDisbursalService } from './re-disbursal.service';

@Component({
  selector: 'app-re-disbursal',
  templateUrl: './re-disbursal.component.html',
  styleUrls: ['./re-disbursal.component.sass']
})
export class ReDisbursalComponent implements OnInit {

  _today = new Date();
  startDt = new Date();
  endDt = new Date();
  _number: number = 20;
  _start: number = 1;
  _totalTrx: number = 0;

  disBankList: MetaData[] = [];
  searchTypeList: SearchType[] = [];
  _searchTypeList: SearchType[] = [];
  selectedBank: string = '';
  searchingValue: string = '';
  selectedSearchType: string = '_ref';

  pendingTransactions: BankTransaction[] = [];

  constructor(
    private reDisbursalService: ReDisbursalService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService
  ) {
    this.disBankList = commonUtilityService.bankDisbList;
    this._searchTypeList = commonUtilityService.bankDisbSearchType;
  }

  ngOnInit(): void {}

  getReDisbursalData() {
    this.loaderService.onLoading();
    this.reDisbursalService
      .getReDisbursalData(
        moment(this.startDt).format('DD/MM/YYYY'),
        moment(this.endDt).add(1, 'days').format('DD/MM/YYYY'),
        this.selectedBank,
        '1000',
        '1',
        '',
        '',
      )
      .subscribe(
        (data) => {
          this.pendingTransactions = data.result.data;
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle('error', '', 'Server Error');
        }
      );
  }

  searchTransaction(){

  }

}
