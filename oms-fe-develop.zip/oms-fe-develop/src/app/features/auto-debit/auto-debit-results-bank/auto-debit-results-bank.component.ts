import { ElementRef, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import {
  GetRegistrxRegistrantionBank,
  ResultImportFileBank,
  searchRegistrantion,
} from 'src/app/core/models/Auto-debit.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { ExcelService } from 'src/app/core/services/excel.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AutoDeBitService } from 'src/app/features/auto-debit/auto-debit.service';

@Component({
  selector: 'app-auto-debit-results-bank',
  templateUrl: './auto-debit-results-bank.component.html',
  styleUrls: ['./auto-debit-results-bank.component.sass'],
  providers: [ConfirmationService],
})
export class AutoDebitResultsBankComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: any;
  @ViewChild('fileUploader3') fileUploader3: any;

  @ViewChild('fileInput', { static: false })
  myFileInput: ElementRef | undefined;

  _templateName = 'REGIS_AUTO_DEBIT_BANK_RESULT_TEMPLATE';

  _lookupCodeId = '';

  _valueSrech = '';

  _arrBank: MetaData[] = [];

  dateValue: Date = new Date();

  _startOf = moment(this.dateValue).startOf('month').format('DD/MM/YYYY');

  _endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');

  _arrRegistrantionBankList: GetRegistrxRegistrantionBank[] = [];
  _countRegistrantionBankList = 0;
  loading: boolean = false;
  _pageRegistrantionBankList = 1;
  _tableSizeRegistrantionBankList = 100;
  _statusMap = 3;

  _arrResultImportFileBank: ResultImportFileBank[] = [];
  _countResultImportFileBank = 0;
  loadingResultImportFileBank: boolean = false;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _listsearchRegistrantion: searchRegistrantion[] = [
    {
      id: '_bank',
      value: 'BANK',
    },
  ];

  _noficationImport: boolean = false;

  LastDateYear: Date = new Date(
    this.DayNow.getFullYear() - 1,
    this.DayNow.getMonth(),
    this.DayNow.getDate()
  );
  _endDt = new Date(moment(this.DayNow).format('MM/DD/YYYY'));
  _startDt = new Date(moment(this.LastDateYear).format('MM/DD/YYYY'));

  LastDate: Date = new Date(
    this.DayNow.getFullYear(),
    this.DayNow.getMonth() - 1,
    this.DayNow.getDate()
  );
  _endSendBankDt = new Date(moment(this.DayNow).format('MM/DD/YYYY'));
  _startSendBankDt = new Date(moment(this.LastDate).format('MM/DD/YYYY'));

  error_number = 0;

  constructor(
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private autosev: AutoDeBitService,
    private exclesev: ExcelService,
    private loaderService: LoaderService,
    private routeStateService: RouteStateService
  ) {}

  ngOnInit(): void {
    this.fetchGetRegistrxRegistrantionBank();
  }
  fetchGetRegistrxRegistrantionBank() {
    this.loaderService.onLoading();
    this.autosev
      .GetRegistrxRegistrantionBank(
        this._lookupCodeId,
        this._valueSrech,

        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),

        this._statusMap,

        moment(this._startSendBankDt).format('DD/MM/YYYY'),
        moment(this._endSendBankDt).format('DD/MM/YYYY'),

        this._tableSizeRegistrantionBankList,
        this._pageRegistrantionBankList
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this._arrRegistrantionBankList = [];
            this.loading = false;
            this.loaderService.offLoading();
          } else {
            this._arrRegistrantionBankList = data?.result?.data;
            this._countRegistrantionBankList = data?.result?.count;
            this.loading = true;
            this.loaderService.offLoading();
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Registrantion Bank',
            error.error?.exceptionMessage
              ? error.error.exceptionMessage
              : 'NO DATA REGISTRATION RESULTS AT BANK'
          );
          this.loaderService.offLoading();
        }
      );
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  getDataSearch() {
    this._pageRegistrantionBankList = 1;
    this.fetchGetRegistrxRegistrantionBank();
  }
  confirm1() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.Export();
      },
      reject: () => {
        // this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.autosev
      .downloadFileAPI_Result_Bank(
        this._lookupCodeId,
        this._valueSrech,
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        moment(this._startSendBankDt).format('DD/MM/YYYY'),
        moment(this._endSendBankDt).format('DD/MM/YYYY'),
        this._statusMap
      )
      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'export_Result_Bank',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.toastService.addSingleShortTime(
            'success',
            'Export',
            'Success Export File'
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }

          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }
  onFileChangeAPI(evt: any) {
    const target: DataTransfer = <DataTransfer>evt.target;

    let file: File = target.files[0];

    let formData: FormData = new FormData();

    if (target.files.length !== 1) {
      this.toastService.addSingle('error', 'Change 1 file', 'One File');
    } else {
      formData.append('fileUpload', file, file.name);
      this.fileUploader3.nativeElement.value = '';
    }
    evt.srcElement.value = null;
    this.loaderService.onLoading();
    this.autosev.PostFileBank(formData).subscribe(
      (data) => {
        this._noficationImport = true;
        this._arrResultImportFileBank = [];
        this._countResultImportFileBank = 0;
        this.loadingResultImportFileBank = true;
        // result
        this._arrResultImportFileBank = data.result.data;
        this._countResultImportFileBank = data.result.count;
        // load page
        this._pageRegistrantionBankList = 1;
        this.fetchGetRegistrxRegistrantionBank();
        this.fileUploader3.nativeElement.value = '';

        if (this.isEmptyObject(data.result)) {
        } else {
          for (let k = 0; k < data.result.data.length; k++) {
            if (data.result.data[k]?.errorMessage) {
              this._noficationImport = false;
              this.error_number = k + 1;
              // break;
            }
          }
        }

        if (this._noficationImport) {
          this.toastService.addSingleShortTime(
            'success',
            'Import File',
            'Success File'
          );
        } else {
          this.toastService.addSingle(
            'error',
            'Import File',
            `Error Message Row ${this.error_number}`
          );
          this.routeStateService.navigate_Fragment(
            'main/auto-debit/resultsAtBank',
            'table_import'
          );
        }
        this.loaderService.offLoading();
      },
      (error) => {
        this._arrResultImportFileBank = [];
        this._countResultImportFileBank = 0;
        this.loadingResultImportFileBank = false;
        this.toastService.addSingle(
          'error',
          'Import Error',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'Incorrect format'
        );
        this.loaderService.offLoading();

        if (
          error.error?.exceptionMessage &&
          error.error?.exceptionMessage.includes('access this resource')
        ) {
        } else {
          this.routeStateService.navigate_Fragment(
            'main/auto-debit/resultsAtBank',
            'table_import'
          );
        }
      }
    );
  }
  onPageChangeTable(event: any) {
    this._pageRegistrantionBankList = event;
    this.fetchGetRegistrxRegistrantionBank();
  }
  CheckReceiveDt(receiveDt: any) {
    const _receiveDt = moment(receiveDt, 'DD/MM/YYYY');
    const days = this._DayNow.diff(_receiveDt, 'days');
    if (days > 20) {
      return true;
    }
    return false;
  }
  DowloadFileRegis() {
    this.download();
  }
  download() {
    this.loaderService.onLoading();
    this.autosev.downloadFileAPI(this._templateName).subscribe(
      (response) => {
        this.exclesev.exportToFileExcleFromAPI(
          'Template_Regis_Result',
          response.body,
          moment(this._DayNow).format('DD/MM/YYY')
        );
        this.loaderService.offLoading();
      },
      (error) => {
        var byteArray = new Uint8Array(error?.error);
        let base64String = btoa(
          String.fromCharCode(...new Uint8Array(byteArray))
        );
        if (base64String) {
          var actual = JSON.parse(atob(base64String));
        }
        this.toastService.addSingle(
          'error',
          'Export',
          actual?.exceptionMessage
            ? actual.exceptionMessage
            : 'No Downlaod File'
        );
        this.loaderService.offLoading();
      }
    );
  }
  BackPage() {
    this.routeStateService.add(
      'Form Received',
      '/main/auto-debit/formAndReceived',
      0,
      true
    );
  }
  NextPage() {
    this.routeStateService.add(
      'SMS Send',
      '/main/auto-debit/smsSendingList',
      0,
      true
    );
  }
}
