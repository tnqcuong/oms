import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { GetPushRegistrx, GetRegistrxReceivedHard, searchRegistrantion } from 'src/app/core/models/Auto-debit.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { ExcelService } from 'src/app/core/services/excel.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AutoDeBitService } from 'src/app/features/auto-debit/auto-debit.service';

@Component({
  selector: 'app-auto-debit-form-and-received',
  templateUrl: './auto-debit-form-and-received.component.html',
  styleUrls: ['./auto-debit-form-and-received.component.sass'],
  providers: [ConfirmationService],
})
export class AutoDebitFormAndReceivedComponent implements OnInit {

  _lookupCodeId = '';

  _valueSrech = '';

  _TypeBank = '';

  _arrBank: MetaData[] = [];

  dateValue: Date = new Date();

  _startOf = moment(this.dateValue).startOf('month').format('DD/MM/YYYY');

  _endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');

  _arrGetRegistrxReceivedHard: GetRegistrxReceivedHard[] = [];
  _countGetRegistrxReceivedHard = 0;
  loading: boolean = false;
  _pageGetRegistrxReceivedHard = 1;
  _tableSizeGetRegistrxReceivedHard = 100;
  _statusMap = 2;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _AD_TYPE = '';

  _listAD_TYPE = [
    {
      id: '1',
      value: 'AUTODUE',
    },
    {
      id: '2',
      value: 'AUTOSAL',
    },
  ];

  _arrPushBank: GetPushRegistrx[] = [];

  dateDialog: boolean = false;

  submitted: boolean = false;

  _listsearchRegistrantion: searchRegistrantion[] = [
    {
      id: '_receiveUser',
      value: 'RECEIVED USER',
    },
    {
      id: '_bank',
      value: 'BANK',
    },
  ];
  @ViewChild('epltable', { static: false }) epltable: any;
  @ViewChild('fileUploader') fileUploader: any;

  LastDate: Date = new Date(
    this.DayNow.getFullYear()-1,
    this.DayNow.getMonth(),
    this.DayNow.getDate()
  );

  _endDt = new Date(moment(this.DayNow).format('MM/DD/YYYY'));
  _startDt = new Date(moment(this.LastDate).format('MM/DD/YYYY'));

  _endReceiveDt = new Date();
  _startReceiveDt = new Date(
    moment(this.DayNow).subtract(7, 'days').format('MM/DD/YYYY')
  );

  constructor(
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private AutoDeBitService: AutoDeBitService,
    private exclesev: ExcelService,
    private loaderService: LoaderService,
    private routeStateService: RouteStateService,
    private commonUtilityService: CommonUtilityService,

  ) {
    this._arrBank = commonUtilityService.BANKS_LIST_AUTO;
  }

  ngOnInit(): void {

    this.fetchGetRegistrxReceivedHard();
  }
  fetchGetRegistrxReceivedHard() {
    this.loaderService.onLoading();
    this.AutoDeBitService.GetRegistrxReceivedHard(
      this._lookupCodeId,
      this._valueSrech,

      moment(this._startDt).format('DD/MM/YYYY'),
      moment(this._endDt).format('DD/MM/YYYY'),

      this._statusMap,

      moment(this._startReceiveDt).format('DD/MM/YYYY'),
      moment(this._endReceiveDt).format('DD/MM/YYYY'),

      this._tableSizeGetRegistrxReceivedHard,
      this._pageGetRegistrxReceivedHard
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrGetRegistrxReceivedHard = [];
          this.loading = false;
          this.loaderService.offLoading();
        } else {
          this._arrGetRegistrxReceivedHard = [];
          this._arrGetRegistrxReceivedHard = data?.result?.data;
          this._countGetRegistrxReceivedHard = data?.result?.count;
          this.loading = true;
          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Registrantion List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data D&R RECEIVED HARD List'
        );
        this.loaderService.offLoading();
      }
    );
  }
  getDataSearch() {
    this._pageGetRegistrxReceivedHard = 1;
    this.fetchGetRegistrxReceivedHard();
  }
  confirm1() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.Export();
      },
      reject: () => {
        // this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.AutoDeBitService.downloadFileAPI_Received_Hard(
      this._lookupCodeId,
      this._valueSrech,
      moment(this._startDt).format('DD/MM/YYYY'),
      moment(this._endDt).format('DD/MM/YYYY'),
      moment(this._startReceiveDt).format('DD/MM/YYYY'),
      moment(this._endReceiveDt).format('DD/MM/YYYY'),
      this._statusMap
    ).subscribe(
      (data) => {
        // export api file
        this.exclesev.exportToFileExcleFromAPI(
          'export_ReceivedHard',
          data?.body,
          moment(this._DayNow).format('DD/MM/YYYY')
        );
        this.toastService.addSingleShortTime('success', 'Export', 'Success Export File');
        this.loaderService.offLoading();
      },
      (error) => {
        var byteArray = new Uint8Array(error.error);
        let base64String = btoa(
          String.fromCharCode(...new Uint8Array(byteArray))
        );
        if (base64String) {
          var actual = JSON.parse(atob(base64String));
        }
        this.toastService.addSingle(
          'error',
          'Export',
          actual?.exceptionMessage
            ? actual.exceptionMessage
            : 'Error Export File'
        );
        this.loaderService.offLoading();
      }
    );
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  onPageChangeTable(event: any) {
    this._pageGetRegistrxReceivedHard = event;
    this.fetchGetRegistrxReceivedHard();
  }
  CheckReceiveDt(receiveDt: any) {
    const _receiveDt = moment(receiveDt, 'DD/MM/YYYY');
    const days = this._DayNow.diff(_receiveDt, 'days');
    if (days > 3) {
      return true;
    }
    return false;
  }
  ExportBank() {
    if (this._TypeBank) {
      this.loaderService.onLoading();
      this.AutoDeBitService.PostExportBankData(this._TypeBank).subscribe(
        (data) => {
          this.exclesev.exportToFileExcleFromAPI(
            'export_Bank',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this._pageGetRegistrxReceivedHard = 1;
          this.fetchGetRegistrxReceivedHard();
          this.toastService.addSingleShortTime(
            'success',
            'Export',
            'Success Export File'
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }
          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.toastService.addSingle('info', 'Export', 'Change Bank');
    }
  }
  BackPage()
  {
    this.routeStateService.add(
      'Form Hard',
      '/main/auto-debit/formAndHard',
      0,
      true
    );
  }
  NextPage()
  {
    this.routeStateService.add(
      'Result Bank',
      '/main/auto-debit/resultsAtBank',
      0,
      true
    );
  }

}
