import { TestBed } from '@angular/core/testing';

import { AutoDeBitService } from './auto-debit.service';

describe('AutoDeBitService', () => {
  let service: AutoDeBitService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AutoDeBitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
