import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { GetPushRegistrx, GetRegistrx, searchRegistrantion } from 'src/app/core/models/Auto-debit.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { ExcelService } from 'src/app/core/services/excel.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AutoDeBitService } from 'src/app/features/auto-debit/auto-debit.service';

@Component({
  selector: 'app-auto-debit-form-and-hard',
  templateUrl: './auto-debit-form-and-hard.component.html',
  styleUrls: ['./auto-debit-form-and-hard.component.sass'],
  providers: [ConfirmationService],
})
export class AutoDebitFormAndHardComponent implements OnInit {

  @ViewChild('epltable', { static: false }) epltable: any;

  _lookupCodeId = '';

  _valueSrech = '';
  _arrBank: MetaData[] = [];

  dateValue: Date = new Date();

  _startOf = moment(this.dateValue).startOf('month').format('DD/MM/YYYY');

  _endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');

  _AD_TYPE = '';

  _listAD_TYPE = [
    {
      id: '1',
      value: 'AUTODUE',
    },
    {
      id: '2',
      value: 'AUTOSAL',
    },
  ];
  _listsearchRegistrantion: searchRegistrantion[] = [
    {
      id: '_branch',
      value: 'BRANCH',
    },
    {
      id: '_signedLocation',
      value: 'SIGNED LOCATION',
    },
    {
      id: '_sendUser',
      value: 'SENT USER',
    },
  ];

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  _arrGetRegistrx: GetRegistrx[] = [];
  _countGetRegistrx = 0;
  loading: boolean = false;
  _pageGetRegistrx = 1;
  _tableSizeGetRegistrx = 500;
  _statusMap = 1;

  _arrPushGetRegistrx: GetPushRegistrx[] = [];

  _checkedAll = false;

  startIndex: number = 0;
  endIndex: number = 0;

  _endDt = new Date(moment(this.DayNow).dayOfYear(365).format('MM/DD/YYYY'));
  _startDt = new Date(
    moment(this.DayNow).dayOfYear(1).format('MM/DD/YYYY')
  );

  _startSendDt = new Date(
    moment(this.DayNow).isoWeekday(1).format('MM/DD/YYYY')
  );
  _endSendDt = new Date(moment(this.DayNow).isoWeekday(7).format('MM/DD/YYYY'));

  constructor(
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private AutoDeBitService: AutoDeBitService,
    private exclesev: ExcelService,
    private loaderService: LoaderService,
    private routeStateService: RouteStateService
  ) {}

  ngOnInit(): void {
    this.fetchGetRegistrx();
  }
  fetchGetRegistrx() {
    this.loaderService.onLoading();
    this.AutoDeBitService.GetRegistrx(
      this._lookupCodeId,
      this._valueSrech,

      moment(this._startDt).format('DD/MM/YYYY'),
      moment(this._endDt).format('DD/MM/YYYY'),

      this._statusMap,

      moment(this._startSendDt).format('DD/MM/YYYY'),
      moment(this._endSendDt).format('DD/MM/YYYY'),

      this._tableSizeGetRegistrx,
      this._pageGetRegistrx
    ).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this._arrGetRegistrx = [];
          this.loading = false;
          this.loaderService.offLoading();
        } else {
          this._arrGetRegistrx = [];
          this._arrGetRegistrx = data?.result?.data;
          this._countGetRegistrx = data?.result?.count;
          this.loading = true;
          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Registrantion List',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'No Data BN SENT HARD List'
        );
        this.loaderService.offLoading();
      }
    );
  }
  getDataSearch() {
    this._pageGetRegistrx = 1;
    this.fetchGetRegistrx();
  }
  confirm1() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.Export();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  onPageChangeTable(event: any) {
    this._pageGetRegistrx = event;
    this.fetchGetRegistrx();
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.AutoDeBitService.downloadFileAPI_Hard(
      this._lookupCodeId,
      this._valueSrech,
      moment(this._startDt).format('DD/MM/YYYY'),
      moment(this._endDt).format('DD/MM/YYYY'),
      moment(this._startSendDt).format('DD/MM/YYYY'),
      moment(this._endSendDt).format('DD/MM/YYYY'),
      this._statusMap
    ).subscribe(
      (data) => {
        // export api file
        this.exclesev.exportToFileExcleFromAPI(
          'export_Hard',
          data?.body,
          moment(this._DayNow).format('DD/MM/YYYY')
        );
        this.toastService.addSingle('success', 'Export', 'Success Export File');
        this.loaderService.offLoading();
      },
      (error) => {
        var byteArray = new Uint8Array(error.error);
        let base64String = btoa(
          String.fromCharCode(...new Uint8Array(byteArray))
        );
        if (base64String) {
          var actual = JSON.parse(atob(base64String));
        }

        this.toastService.addSingle(
          'error',
          'Export',
          actual?.exceptionMessage
            ? actual.exceptionMessage
            : 'Error Export File'
        );
        this.loaderService.offLoading();
      }
    );
  }
  toggleVisibility(event: any, row_GetRegistrx: any, i: any) {
    // let row = row_GetRegistrx;
    // if (event.target.checked == true) {
    //   row.checked = event.target.checked;
    // } else {
    //   row.checked = event.target.checked;
    // }
    if (event.target.checked) {
      if (event.shiftKey) {
        this.endIndex = i;
        if (this.startIndex > this.endIndex) {
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex];
        }
        for (let i = this.startIndex; i <= this.endIndex; i++) {
          this._arrGetRegistrx[i].checked = true;
        }
      } else {
        this._arrGetRegistrx.forEach((trx) => {
          if (trx.loanNo === row_GetRegistrx.loanNo) {
            trx.checked = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._arrGetRegistrx.forEach((trx) => {
        if (trx.loanNo === row_GetRegistrx.loanNo) {
          trx.checked = false;
        }
      });
    }
  }
  toggleAll(event: any) {
    this._checkedAll = event.target.checked;
    const checked = event.target.checked;
    this._arrGetRegistrx.map((item: any) => {
      item.checked = checked;
    });
  }
  SubmitDataSend() {
    this._arrPushGetRegistrx = [];
    let action = 0;
    this._arrGetRegistrx.map((item: any) => {
      if (item.checked == true) {
        const data = {
          loanNo: item.loanNo,
        };
        this._arrPushGetRegistrx.push(data);
        action = 1;
      }
    });
    this.loaderService.onLoading();
    if (action == 1) {
      this.AutoDeBitService.PostImportHardCopy(
        this._arrPushGetRegistrx
      ).subscribe(
        (data) => {
          this._pageGetRegistrx = 1;
          this.fetchGetRegistrx();
          this.toastService.addSingle('success', 'Submit', 'Success Record');
          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Submit',
            error.error?.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error Record'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.loaderService.offLoading();
      this.toastService.addSingle('error', 'Submit', 'Change Record');
    }
    this._checkedAll = false;
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  CheckSentDate(sentDate: any) {
    const _sentDate = moment(sentDate, 'DD/MM/YYYY');

    const days = this._DayNow.diff(_sentDate, 'days');
    if (days > 3) {
      return true;
    }
    return false;
  }
  BackPage()
  {
    this.routeStateService.add(
      'Registrantion',
      '/auto-debit/registration',
      0,
      true
    );
  }
  NextPage()
  {
    this.routeStateService.add(
      'Form Received',
      '/auto-debit/formAndReceived',
      0,
      true
    );
  }

}
