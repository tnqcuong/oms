import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitFormAndHardComponent } from './auto-debit-form-and-hard.component';

describe('AutoDebitFormAndHardComponent', () => {
  let component: AutoDebitFormAndHardComponent;
  let fixture: ComponentFixture<AutoDebitFormAndHardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitFormAndHardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitFormAndHardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
