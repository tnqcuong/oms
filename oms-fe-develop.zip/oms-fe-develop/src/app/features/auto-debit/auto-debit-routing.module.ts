import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AutoDebitFormAndHardComponent } from './auto-debit-form-and-hard/auto-debit-form-and-hard.component';
import { AutoDebitFormAndReceivedComponent } from './auto-debit-form-and-received/auto-debit-form-and-received.component';
import { AutoDebitListComponent } from './auto-debit-list/auto-debit-list.component';
import { AutoDebitRegistrationComponent } from './auto-debit-registration/auto-debit-registration.component';
import { AutoDebitReportComponent } from './auto-debit-report/auto-debit-report.component';
import { AutoDebitResultsBankComponent } from './auto-debit-results-bank/auto-debit-results-bank.component';
import { AutoDebitSmsSendingListComponent } from './auto-debit-sms-sending-list/auto-debit-sms-sending-list.component';
import { AutoDebitComponent } from './auto-debit.component';

const routes: Routes = [
  {
    path: '',
    component: AutoDebitComponent,
    children: [
      {
        path: '',
        component: AutoDebitListComponent
      },
      {
        path: 'registration',
        component: AutoDebitRegistrationComponent
      },
      {
        path: 'formAndHard',
        component: AutoDebitFormAndHardComponent
      },
      {
        path: 'formAndReceived',
        component: AutoDebitFormAndReceivedComponent
      },
      {
        path: 'resultsAtBank',
        component: AutoDebitResultsBankComponent
      },
      {
        path: 'smsSendingList',
        component: AutoDebitSmsSendingListComponent
      },
      {
        path: 'report',
        component: AutoDebitReportComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AutoDebitRoutingModule { }
