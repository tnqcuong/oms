import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AutoDebitFormAndHardComponent } from './auto-debit-form-and-hard/auto-debit-form-and-hard.component';
import { AutoDebitFormAndReceivedComponent } from './auto-debit-form-and-received/auto-debit-form-and-received.component';
import { AutoDebitListComponent } from './auto-debit-list/auto-debit-list.component';
import { AutoDebitRegistrationComponent } from './auto-debit-registration/auto-debit-registration.component';
import { AutoDebitReportComponent } from './auto-debit-report/auto-debit-report.component';
import { AutoDebitResultsBankComponent } from './auto-debit-results-bank/auto-debit-results-bank.component';
import { AutoDebitSmsSendingListComponent } from './auto-debit-sms-sending-list/auto-debit-sms-sending-list.component';
import { AutoDebitComponent } from './auto-debit.component';
import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';
import { User, Roles, Feature } from 'src/app/core/models/user.model';
import { Url_OMS } from 'src/environments/environmentAPI';
const routes: Routes = [
  {
    path: '',
    component: AutoDebitComponent,
    children: [
      {
        path: '',
        component: AutoDebitListComponent
      },
      {
        path: 'registration',
        component: AutoDebitRegistrationComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_AUTO_REGISTRATION] },

      },
      {
        path: 'formAndHard',
        component: AutoDebitFormAndHardComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_AUTO_BNSENTHARDCOPY] },
      },
      {
        path: 'formAndReceived',
        component: AutoDebitFormAndReceivedComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_AUTO_DRRECEIVEDHARDCOPY] },
      },
      {
        path: 'resultsAtBank',
        component: AutoDebitResultsBankComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_AUTO_LISTWAITINGBANKRESULT] },
      },
      {
        path: 'smsSendingList',
        component: AutoDebitSmsSendingListComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_AUTO_LISTSENDINSMS] },
      },
      {
        path: 'report',
        component: AutoDebitReportComponent,
        canActivate: [AuthGuard],
        data: { feature: [Url_OMS.URL_FEATURE_AUTO_REPORT] },
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AutoDebitRoutingModule { }
