import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SessionService } from 'src/app/core/services/session.service';
import { environment } from 'src/environments/environment';
import { environmentAPI_Auto } from 'src/environments/environmentAPI';

@Injectable({
  providedIn: 'root'
})
export class AutoDeBitService {

  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {}

  PostFile(formData: FormData): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);
    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.importFile,
      formData,
      { headers: headers, reportProgress: true }
    );
  }
  PostFile_Success(formData: FormData): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);
    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.updateBankResutl,
      formData,
      { headers: headers, reportProgress: true }
    );
  }
  PostFileBank(formData: FormData): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);
    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.importFileBank,
      formData,
      { headers: headers }
    );
  }
  GetUnregistrx(
    params_select: any,
    params_value: any,

    params_adType: any,
    params_doc36: any,

    params_startDt: any,
    params_endDt: any,

    params_number: any,
    params_start: any,

    params_firstDueDt: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_cusName') {
      params = params.set('_cusName', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_roUser') {
      params = params.set('_roUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_adType', params_adType);
    params = params.set('_doc36', params_doc36);

    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    params = params.set('_firstDueDt', params_firstDueDt);

    return this.http.get(
      environment.apiUrl_Auto + environmentAPI_Auto.unregistrx,
      {
        headers: headers,
        params: params,
      }
    );
  }
  GetRegistrx(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_statusMap: any,

    params_startSendDt: any,
    params_endSendDt: any,

    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_signedLocation') {
      params = params.set('_signedLocation', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_sendUser') {
      params = params.set('_sendUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    params = params.set('_startSendDt', params_startSendDt);
    params = params.set('_endSendDt', params_endSendDt);

    params = params.set('_statusMap', params_statusMap);

    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl_Auto + environmentAPI_Auto.registrx,
      {
        headers: headers,
        params: params,
      }
    );
  }
  GetRegistrxReceivedHard(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_statusMap: any,

    params_startSendDt: any,
    params_endReceiveDt: any,

    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_receiveUser') {
      params = params.set('_receiveUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    params = params.set('_startReceiveDt', params_startSendDt);
    params = params.set('_endReceiveDt', params_endReceiveDt);

    params = params.set('_statusMap', params_statusMap);

    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl_Auto + environmentAPI_Auto.registrx,
      {
        headers: headers,
        params: params,
      }
    );
  }
  GetRegistrxReceivedBank(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_statusMap: any,

    params_startBankResultDt: any,
    params_endBankResultDt: any,

    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_receiveUser') {
      params = params.set('_receiveUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    params = params.set('_startBankResultDt', params_startBankResultDt);
    params = params.set('_endBankResultDt', params_endBankResultDt);

    params = params.set('_statusMap', params_statusMap);

    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl_Auto + environmentAPI_Auto.registrx,
      {
        headers: headers,
        params: params,
      }
    );
  }
  GetRegistrxRegistrantionBank(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_statusMap: any,

    params_startSendBankDt: any,
    params_endSendBankDt: any,

    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    params = params.set('_startSendBankDt', params_startSendBankDt);
    params = params.set('_endSendBankDt', params_endSendBankDt);

    params = params.set('_statusMap', params_statusMap);

    params = params.set('_number', params_number);
    params = params.set('_start', params_start);
    return this.http.get(
      environment.apiUrl_Auto + environmentAPI_Auto.registrx,
      {
        headers: headers,
        params: params,
      }
    );
  }
  fetchGetSmsNoRegis(
    params_select: any,
    params_value: any,

    params_firstDueDt: any,

    params_isSend: any,

    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_roUser') {
      params = params.set('_roUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_isSend', params_isSend);

    params = params.set('_firstDueDt', params_firstDueDt);

    params = params.set('_number', params_number);
    params = params.set('_start', params_start);
    return this.http.get(environment.apiUrl_Auto + environmentAPI_Auto.sms, {
      headers: headers,
      params: params,
    });
  }
  downloadFileAPI_SmsNoRegis(
    params_select: any,
    params_value: any,

    params_firstDueDt: any,

    params_isSend: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_roUser') {
      params = params.set('_roUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_isSend', params_isSend);

    params = params.set('_firstDueDt', params_firstDueDt);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.sms_export,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }

  PostImportHardCopy(_arrPushGetRegistrx: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.importhardcopy,
      _arrPushGetRegistrx,
      {
        headers: headers,
      }
    );
  }
  downloadFileAPI(params_templateName: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    params = params.set('_templateName', params_templateName);
    return this.http.get(
      environment.apiUrl_Auto + environmentAPI_Auto.downloadTemplate,
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  downloadFileAPI_Registration(
    params_select: any,
    params_value: any,

    params_adType: any,
    params_doc36: any,

    params_startDt: any,
    params_endDt: any,

    params_firstDueDt: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_cusName') {
      params = params.set('_cusName', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_roUser') {
      params = params.set('_roUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_adType', params_adType);
    params = params.set('_doc36', params_doc36);

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    params = params.set('_firstDueDt', params_firstDueDt);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.export_unregistrx,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  PostUpdateBankResult(params_loanNo: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.updateBankResutl,
      params_loanNo,
      {
        headers: headers,
      }
    );
  }
  downloadFileAPI_Hard(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_startReceiveDt: any,
    params_endSendDt: any,
    params_statusMap: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_signedLocation') {
      params = params.set('_signedLocation', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_sendUser') {
      params = params.set('_sendUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startSendDt', params_startReceiveDt);
    params = params.set('_endSendDt', params_endSendDt);
    params = params.set('_statusMap', params_statusMap);
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.export_hard,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  downloadFileAPI_Received_Hard(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_startReceiveDt: any,
    params_endSendDt: any,

    params_statusMap: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_receiveUser') {
      params = params.set('_receiveUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startReceiveDt', params_startReceiveDt);
    params = params.set('_endReceiveDt', params_endSendDt);
    params = params.set('_statusMap', params_statusMap);
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.export_hard,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  downloadFileAPI_Result_Bank(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_startSendBankDt: any,
    params_endSendBankDt: any,

    params_statusMap: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_receiveUser') {
      params = params.set('_receiveUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startSendBankDt', params_startSendBankDt);
    params = params.set('_endSendBankDt', params_endSendBankDt);
    params = params.set('_statusMap', params_statusMap);
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.export_hard,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  downloadFileAPI_Result_Bank_SMS(
    params_select: any,
    params_value: any,

    params_startDt: any,
    params_endDt: any,

    params_statusMap: any,

    params_startBankResultDt: any,
    params_endBankResultDt: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    if (params_select == '_bank') {
      params = params.set('_bank', params_value);
    } else if (params_select == '_branch') {
      params = params.set('_branch', params_value);
    } else if (params_select == '_receiveUser') {
      params = params.set('_receiveUser', params_value);
    } else {
      params = params.set('_loanNo', params_value);
    }

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    params = params.set('_startBankResultDt', params_startBankResultDt);
    params = params.set('_endBankResultDt', params_endBankResultDt);

    params = params.set('_statusMap', params_statusMap);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.export_hard,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  GetMetaData(): Observable<any> {
    return this.http.get<any>(
      environment.apiUrl_Auto + environmentAPI_Auto.metadata
    );
  }
  PostExportBankData(params_bank: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);
    let params = new HttpParams();
    params = params.set('_bank', params_bank);
    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.exportbankdata,
      {},
      {
        headers: headers,
        params: params,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
  PostSmsRegistration_List(_pushArr_RegistrantionList: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.sms_send_unregistrx,
      _pushArr_RegistrantionList,
      {
        headers: headers,
      }
    );
  }
  PostSendSmsList(
    _pushArr_arrGetSMS: any,
    params_statusMap: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);
    let params = new HttpParams();
    params = params.set('_statusMap', params_statusMap);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.sms_send_registrx,
      _pushArr_arrGetSMS,
      {
        headers: headers,
        params: params,
      }
    );
  }
  downloadFileAPI_Report(
    params_select: any,

    params_startDt: any,
    params_endDt: any,
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();


    params = params.set('_templateName', params_select);

    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);

    return this.http.post(
      environment.apiUrl_Auto + environmentAPI_Auto.report,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
}
