import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitListComponent } from './auto-debit-list.component';

describe('AutoDebitListComponent', () => {
  let component: AutoDebitListComponent;
  let fixture: ComponentFixture<AutoDebitListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
