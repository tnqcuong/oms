import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';


@Component({
  selector: 'app-auto-debit-list',
  templateUrl: './auto-debit-list.component.html',
  styleUrls: ['./auto-debit-list.component.sass'],
})
export class AutoDebitListComponent implements OnInit {
  constructor(
    private routeStateService: RouteStateService,
  ) {}

  ngOnInit(): void {}

  goToAutoDebitRegistration(autodebit: number) {
    this.routeStateService.add(
      'Registrantion',
      '/main/auto-debit/registration',
      autodebit,
      false
    );
  }
  goToAutoDebitFormAndHard(autodebit: number) {
    this.routeStateService.add(
      'FormAndHard',
      '/main/auto-debit/formAndHard',
      autodebit,
      false
    );
  }
  goToAutoDebitFormAndReceived(autodebit: number) {
    this.routeStateService.add(
      'FormAndReceived',
      '/main/auto-debit/formAndReceived',
      autodebit,
      false
    );
  }
  goToAutoDebitResultsAtBank(autodebit: number) {
    this.routeStateService.add(
      'ResultsAtBank',
      '/main/auto-debit/resultsAtBank',
      autodebit,
      false
    );
  }
  goToAutoDebitSmsSendingList(autodebit: number) {
    this.routeStateService.add(
      'SmsSendingList',
      '/main/auto-debit/smsSendingList',
      autodebit,
      false
    );
  }
  goToAutoDebitReport(autodebit: number) {
    this.routeStateService.add(
      'Report',
      '/main/auto-debit/report',
      autodebit,
      false
    );
  }
}
