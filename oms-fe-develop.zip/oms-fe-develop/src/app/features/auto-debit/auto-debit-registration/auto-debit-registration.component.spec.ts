import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitRegistrationComponent } from './auto-debit-registration.component';

describe('AutoDebitRegistrationComponent', () => {
  let component: AutoDebitRegistrationComponent;
  let fixture: ComponentFixture<AutoDebitRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitRegistrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
