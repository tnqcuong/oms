import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import {
  GetPushRegistrx,
  Registrantion,
  RegistrantionList,
  ResultImportFile,
  searchRegistrantion,
} from 'src/app/core/models/Auto-debit.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { ExcelService } from 'src/app/core/services/excel.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AutoDeBitService } from 'src/app/features/auto-debit/auto-debit.service';

@Component({
  selector: 'app-auto-debit-registration',
  templateUrl: './auto-debit-registration.component.html',
  styleUrls: ['./auto-debit-registration.component.sass'],
  providers: [ConfirmationService],
})
export class AutoDebitRegistrationComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: any;
  error_number = 0;

  _templateName_1 = 'REGIS_AUTO_DEBIT_TEMPLATE';

  _templateName_2 = 'REGIS_AUTO_DEBIT_BANK_RESULT_TEMPLATE';

  _lookupCodeId = '';

  _valueSrech = '';

  _arrBank: MetaData[] = [];

  _arrRegistrantion: Registrantion[] = [];

  _arrRegistrantionList: RegistrantionList[] = [];
  _countRegistrantionList = 0;
  loading: boolean = false;
  _pageRegistrantionList = 1;
  _tableSizeRegistrantionList = 100;

  _arrResultImportFile: ResultImportFile[] = [];
  _countResultImportFile = 0;
  loadingResultImportFile: boolean = false;

  DayNow = new Date();
  _DayNow = moment(this.DayNow);

  dateValue: Date = new Date(
    this.DayNow.getFullYear(),
    this.DayNow.getMonth(),
    1
  );
  LastDate: Date = new Date(
    this.DayNow.getFullYear(),
    this.DayNow.getMonth() - 1,
    this.DayNow.getDate()
  );

  _listsearchRegistrantion: searchRegistrantion[] = [
    {
      id: '_branch',
      value: 'BRANCH',
    },
    {
      id: '_bank',
      value: 'BANKS',
    },
  ];

  _doc36 = '';

  _listDoc36 = [
    {
      id: 'YES',
      value: 'YES',
    },
    {
      id: 'NO',
      value: 'NO',
    },
  ];

  _AD_TYPE = '';

  _listAD_TYPE = [
    {
      id: 'AUTOSAL',
      value: 'AUTOSAL',
    },
    {
      id: 'NOAUTOSAL',
      value: 'NOAUTOSAL',
    },
  ];

  dateValue_start: Date = new Date();

  // day select
  _endDt = new Date(moment(this.DayNow).format('MM/DD/YYYY'));
  _startDt = new Date(moment(this.LastDate).format('MM/DD/YYYY'));
  // _startDt = new Date(
  //   moment(this.DayNow).subtract(this.dayLastMonth, 'days').format('MM/DD/YYYY')
  // );

  _noficationImport: boolean = false;

  @ViewChild('fileUploader') fileUploader: any;

  _arrPushLoanNo: GetPushRegistrx[] = [];

  constructor(
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private exclesev: ExcelService,
    private autosev: AutoDeBitService,
    private loaderService: LoaderService,
    private routeStateService: RouteStateService
  ) {}

  _abc: any;
  ngOnInit(): void {
    this.fetchGetUnregistrx();
  }
  fetchGetUnregistrx() {
    this.loaderService.onLoading();
    this.autosev
      .GetUnregistrx(
        this._lookupCodeId,
        this._valueSrech,

        this._AD_TYPE,
        this._doc36,

        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),

        this._tableSizeRegistrantionList,
        this._pageRegistrantionList,
        ''
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this._arrRegistrantionList = [];
            this.loading = false;
            this.loaderService.offLoading();
          } else {
            this._arrRegistrantionList = [];
            this._arrRegistrantionList = data?.result?.data;
            this._countRegistrantionList = data?.result?.count;
            this.loading = true;
            this.loaderService.offLoading();
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Registrantion List',
            error.error?.exceptionMessage
              ? error.error.exceptionMessage
              : 'No Data Registrantion List'
          );
          this.loaderService.offLoading();
        }
      );
  }
  getDataSearch() {
    this._pageRegistrantionList = 1;
    this.fetchGetUnregistrx();
  }
  onChangeDoc36() {
    this._pageRegistrantionList = 1;
    this.fetchGetUnregistrx();
  }
  confirm2() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.Export();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  Export() {
    // call api
    this.loaderService.onLoading();
    this.autosev
      .downloadFileAPI_Registration(
        this._lookupCodeId,
        this._valueSrech,

        this._AD_TYPE,
        this._doc36,
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        ''
      )

      .subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            'export_registration',
            data?.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.loaderService.offLoading();
          this.toastService.addSingleShortTime(
            'success',
            'Export',
            'Success Export File'
          );
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }

          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
  }
  editStatus(loanNo: any) {
    this._arrPushLoanNo = [];
    const data = {
      loanNo: loanNo,
    };
    this._arrPushLoanNo.push(data);
    this.autosev.PostUpdateBankResult(this._arrPushLoanNo).subscribe(
      (data) => {
        this.toastService.addSingleShortTime(
          'success',
          'Update Status',
          'Update successful'
        );
        this._pageRegistrantionList = 1;
        this.fetchGetUnregistrx();
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Update Status',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'Could not update'
        );
      }
    );
  }
  DiaLog(loanNo: any) {
    this.confirmationService.confirm({
      message: `Are you sure you want to update ${loanNo} status?`,
      header: 'Update Status ',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.editStatus(loanNo);
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  onFileChangeAPI(evt: any) {
    const target: DataTransfer = <DataTransfer>evt.target;
    let file: File = target.files[0];
    let formData: FormData = new FormData();

    if (target.files.length !== 1) {
      this.toastService.addSingle('error', 'Change 1 file', 'One File');
      // this.fileUploader.nativeElement.value = '';
    } else {
      formData.append('fileUpload', file, file.name);
      this.fileUploader.nativeElement.value = '';
    }
    evt.srcElement.value = null;
    this.loaderService.onLoading();
    this._abc = this.autosev.PostFile(formData).subscribe(
      (data) => {
        this._noficationImport = false;
        this._arrResultImportFile = [];
        this._countResultImportFile = 0;
        this.loadingResultImportFile = true;
        // result
        this._arrResultImportFile = data.result.data;
        this._countResultImportFile = data.result.count;
        // load page
        this._pageRegistrantionList = 1;
        this.fetchGetUnregistrx();
        this._noficationImport = true;

        if (this.isEmptyObject(data.result)) {
        } else {
          for (let k = 0; k < data.result.data.length; k++) {
            if (data.result.data[k].errorMessage != '') {
              this._noficationImport = false;
              this.error_number = k + 1;
              break;
            }
          }
        }

        if (this._noficationImport) {
          this.toastService.addSingleShortTime(
            'success',
            'Import File',
            'Success File'
          );
        } else {
          this.toastService.addSingle(
            'error',
            'Import File',
            `Error Message Row ${this.error_number}`
          );
          this.routeStateService.navigate_Fragment(
            'main/auto-debit/registration',
            'table_import'
          );
        }
        this.loaderService.offLoading();
      },
      (error) => {
        this.fileUploader.nativeElement.value = '';
        evt.srcElement.value = null;
        this._arrResultImportFile = [];
        this._countResultImportFile = 0;
        this.loadingResultImportFile = false;
        this.toastService.addSingle(
          'error',
          'Import Error',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'Incorrect format should choose another file'
        );
        this.loaderService.offLoading();
        this.routeStateService.navigate_Fragment(
          'main/auto-debit/registration',
          'table_import'
        );
      }
    );
    this.routeStateService.add(
      'List',
      '/main/auto-debit/registration',
      0,
      true
    );
  }
  onFileChangeAPI_Success(evt: any) {
    const target: DataTransfer = <DataTransfer>evt.target;
    let file: File = target.files[0];
    let formData: FormData = new FormData();

    if (target.files.length !== 1) {
      this.toastService.addSingle('error', 'Change 1 file', 'One File');
      // this.fileUploader.nativeElement.value = '';
    } else {
      formData.append('fileUpload', file, file.name);
      this.fileUploader.nativeElement.value = '';
    }
    evt.srcElement.value = null;
    this.loaderService.onLoading();
    this._abc = this.autosev.PostFile_Success(formData).subscribe(
      (data) => {
        this._noficationImport = false;
        this._arrResultImportFile = [];
        this._countResultImportFile = 0;
        this.loadingResultImportFile = true;
        // result
        this._arrResultImportFile = data.result.data;
        this._countResultImportFile = data.result.count;
        // load page
        this._pageRegistrantionList = 1;
        this.fetchGetUnregistrx();
        this._noficationImport = true;

        if (this.isEmptyObject(data.result)) {
        } else {
          for (let k = 0; k < data.result.data.length; k++) {
            if (data.result.data[k].errorMessage != '') {
              this._noficationImport = false;
              this.error_number = k + 1;
              break;
            }
          }
        }

        if (this._noficationImport) {
          this.toastService.addSingleShortTime(
            'success',
            'Import File',
            'Success File'
          );
        } else {
          this.toastService.addSingle(
            'error',
            'Import File',
            `Error Message Row ${this.error_number}`
          );
          this.routeStateService.navigate_Fragment(
            'main/auto-debit/registration',
            'table_import'
          );
        }
        this.loaderService.offLoading();
      },
      (error) => {
        this.fileUploader.nativeElement.value = '';
        evt.srcElement.value = null;
        this._arrResultImportFile = [];
        this._countResultImportFile = 0;
        this.loadingResultImportFile = false;
        this.toastService.addSingle(
          'error',
          'Import Error',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'Incorrect format should choose another file'
        );
        this.loaderService.offLoading();
        this.routeStateService.navigate_Fragment(
          'main/auto-debit/registration',
          'table_import'
        );
      }
    );
    this.routeStateService.add(
      'List',
      '/main/auto-debit/registration',
      0,
      true
    );
  }
  onPageChangeTable(event: any) {
    this._pageRegistrantionList = event;
    this.fetchGetUnregistrx();
  }
  CheckAuthorized(authorizeDt: any) {
    const _authorizeDt = moment(authorizeDt, 'DD/MM/YYYY');
    const days = this._DayNow.diff(_authorizeDt, 'days');
    if (days > 2) {
      return true;
    }
    return false;
  }
  CheckDoc36(doc36: any) {
    if (doc36 == 'NO' || doc36 == 'No' || doc36 == 'no' || doc36 == 'No') {
      return true;
    }
    return false;
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  DowloadFile(numbrer: any) {
    this.download(numbrer);
  }
  download(numbrer: any) {
    this.loaderService.onLoading();
    if (numbrer === 1) {
      this.autosev.downloadFileAPI(this._templateName_1).subscribe(
        (response) => {
          this.exclesev.exportToFileExcleFromAPI(
            'Template_Regis',
            response.body,
            moment(this._DayNow).format('DD/MM/YYYY')
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error?.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }
          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'No Downlaod File'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.autosev.downloadFileAPI(this._templateName_2).subscribe(
        (response) => {
          this.exclesev.exportToFileExcleFromAPI(
            'Template_Regis_Result',
            response.body,
            moment(this._DayNow).format('DD/MM/YYY')
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error?.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          if (base64String) {
            var actual = JSON.parse(atob(base64String));
          }
          this.toastService.addSingle(
            'error',
            'Export',
            actual?.exceptionMessage
              ? actual.exceptionMessage
              : 'No Downlaod File'
          );
          this.loaderService.offLoading();
        }
      );
    }
  }
  ngOnDestroy() {
    // this._abc.unsubscribe();
  }
  log(val: any) {
    console.log(val);
  }
  BackPage() {
    this.routeStateService.add('List', '/main/auto-debit', 0, true);
  }
  NextPage() {
    this.routeStateService.add(
      'Form Hard',
      '/main/auto-debit/formAndHard',
      0,
      true
    );
  }
}
