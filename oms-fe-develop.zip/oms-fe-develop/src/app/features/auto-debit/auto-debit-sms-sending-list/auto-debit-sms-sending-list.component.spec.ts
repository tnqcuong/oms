import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitSmsSendingListComponent } from './auto-debit-sms-sending-list.component';

describe('AutoDebitSmsSendingListComponent', () => {
  let component: AutoDebitSmsSendingListComponent;
  let fixture: ComponentFixture<AutoDebitSmsSendingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitSmsSendingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitSmsSendingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
