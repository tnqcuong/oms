import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auto-debit',
  templateUrl: './auto-debit.component.html',
  styleUrls: ['./auto-debit.component.sass']
})
export class AutoDebitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
