import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AutoDebitRoutingModule } from './auto-debit-routing.module';
import { AutoDebitComponent } from './auto-debit.component';
import { AutoDebitListComponent } from './auto-debit-list/auto-debit-list.component';
import { AutoDebitFormAndHardComponent } from './auto-debit-form-and-hard/auto-debit-form-and-hard.component';
import { AutoDebitFormAndReceivedComponent } from './auto-debit-form-and-received/auto-debit-form-and-received.component';

import { AutoDebitReportComponent } from './auto-debit-report/auto-debit-report.component';
import { AutoDebitRegistrationComponent } from './auto-debit-registration/auto-debit-registration.component';
import { AutoDebitResultsBankComponent } from './auto-debit-results-bank/auto-debit-results-bank.component';
import { AutoDebitSmsSendingListComponent } from './auto-debit-sms-sending-list/auto-debit-sms-sending-list.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    AutoDebitComponent,
    AutoDebitListComponent,
    AutoDebitFormAndHardComponent,
    AutoDebitFormAndReceivedComponent,
    AutoDebitReportComponent,
    AutoDebitRegistrationComponent,
    AutoDebitResultsBankComponent,
    AutoDebitSmsSendingListComponent
  ],
  imports: [
    CommonModule,
    AppCommonModule,
    NgxPaginationModule,
    AutoDebitRoutingModule
  ]
})
export class AutoDebitModule { }
