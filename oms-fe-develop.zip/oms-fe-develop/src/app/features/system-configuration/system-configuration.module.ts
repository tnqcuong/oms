import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SystemConfigurationComponent } from 'src/app/features/system-configuration/system-configuration.component';
import { SystemConfigurationRoutingModule } from 'src/app/features/system-configuration/system-configuration.routing';
import { SystemConfigurationMetadataComponent } from 'src/app/features/system-configuration/system-configuration-metadata/system-configuration-metadata.component';
import { SystemConfigurationFeatureComponent } from 'src/app/features/system-configuration/system-configuration-feature/system-configuration-feature.component';
import { SystemConfigurationRoleComponent } from 'src/app/features/system-configuration/system-configuration-role/system-configuration-role.component';
import { AppCommonModule } from '../../app.common.module';

@NgModule({
  declarations: [
    SystemConfigurationComponent,
    SystemConfigurationMetadataComponent,
    SystemConfigurationFeatureComponent,
    SystemConfigurationRoleComponent
  ],
  imports: [CommonModule, SystemConfigurationRoutingModule, AppCommonModule],
})
export class SystemConfigurationModule {}
