import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemConfigurationRoleComponent } from './system-configuration-role.component';

describe('SystemConfigurationRoleComponent', () => {
  let component: SystemConfigurationRoleComponent;
  let fixture: ComponentFixture<SystemConfigurationRoleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SystemConfigurationRoleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemConfigurationRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
