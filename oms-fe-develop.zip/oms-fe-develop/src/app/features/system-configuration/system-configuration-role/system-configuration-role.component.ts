import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { SystemConfigurationService } from '../system-configuration.service';
import {
  OMS_USER_ROLE,
  OMS_USER_FEATURE,
  OMS_METADATA,
  OMS_FEATURE_ROLE,
} from 'src/app/core/models/systemConfigucation.model';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-system-configuration-role',
  templateUrl: './system-configuration-role.component.html',
  styleUrls: ['./system-configuration-role.component.sass'],
})
export class SystemConfigurationRoleComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    private systemConfigurationService: SystemConfigurationService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private loaderService: LoaderService,
    private confirmationService: ConfirmationService
  ) {}
  checked_feature: boolean = false;

  _valueSrech = '';
  _valueDetailSrech = '';
  display_role: boolean = false;
  display_feature_detail_role: boolean = false;
  action_save: boolean = false;
  submitted_Role = false;
  submitted_Feature_Detail_Role = false;
  OMS_ROLES_ARR: OMS_METADATA[] = [];
  OMS_ROLES_COUNT = 0;
  loading_ROLES: boolean = false;
  isChekbox: boolean = false;
  isEditFeatureDetail: boolean = false;

  OMS_METADATA_FEATURE_ARR: OMS_METADATA[] = [];
  OMS_METADATA_FEATURE_COUNT = 0;

  OMS_ROLE_DETAIL_ARR: OMS_FEATURE_ROLE[] = [];
  OMS_ROLE_DETAIL_ARR_Update: OMS_FEATURE_ROLE[] = [];
  OMS_ROLE_DETAIL: OMS_FEATURE_ROLE = new OMS_FEATURE_ROLE();

  OMS_ROLE_DETAIL_ARR_TEMP: OMS_FEATURE_ROLE[] = [];

  OMS_ROLE_TEMP: OMS_FEATURE_ROLE = new OMS_FEATURE_ROLE();

  display_role_detail: boolean = false;

  product: OMS_METADATA = new OMS_METADATA();

  ngOnInit(): void {
    this.fetchRole();
    this.fetchFeature();
  }
  BackPage() {
    this.routeStateService.add(
      'USER MANAGEMENT',
      '/main/system/configuration',
      0,
      true
    );
  }
  fetchRole() {
    this.systemConfigurationService.GetRolesParam('').subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this.OMS_ROLES_ARR = [];
          this.loading_ROLES = false;
          this.loaderService.offLoading();
        } else {
          this.OMS_ROLES_ARR = [];
          this.OMS_ROLES_ARR = data?.result?.data;
          this.OMS_ROLES_COUNT = data?.result?.count;
          this.loading_ROLES = true;
          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'MetaData',
          error.error.exceptionMessage
            ? error.error.exceptionMessage
            : 'Error List MetaData'
        );
        this.loaderService.offLoading();
      }
    );
  }
  fetchFeature() {
    this.systemConfigurationService.GetMetaDataFeatureParam('').subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this.OMS_METADATA_FEATURE_ARR = [];
          this.loaderService.offLoading();
        } else {
          this.OMS_METADATA_FEATURE_ARR = [];
          this.OMS_METADATA_FEATURE_ARR = data?.result?.data;
          this.OMS_METADATA_FEATURE_COUNT = data?.result?.count;
          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'MetaData',
          error.error.exceptionMessage
            ? error.error.exceptionMessage
            : 'Error List MetaData'
        );
        this.loaderService.offLoading();
      }
    );
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  showDialog_MetaData() {
    this.display_role = true;
    this.product = {};
    this.action_save = false;
    this.submitted_Role = false;
  }
  deleteProduct(product: any) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + product.value + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.systemConfigurationService.DeleteRole(product.id).subscribe(
          (data) => {
            this.fetchRole();
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Delete Role',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Delete Role'
            );
          }
        );
      },
    });
  }
  CloseDialog_Role() {
    this.display_role = false;
  }
  onSubmitRole() {
    this.submitted_Role = true;
    if (this.product.lookupCodeId?.trim() && this.product.value?.trim()) {
      if (this.action_save) {
        this.systemConfigurationService.UpdateRole(this.product).subscribe(
          (data) => {
            this.display_role = false;
            this.fetchRole();
            this.toastService.addSingleShortTime(
              'success',
              'Update Role',
              'Success Update Role'
            );
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Update Role',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Update Role'
            );
          }
        );
      } else {
        this.systemConfigurationService.AddRole(this.product).subscribe(
          (data) => {
            this.display_role = false;
            this.fetchRole();
            this.toastService.addSingleShortTime(
              'success',
              'Add Role',
              'Success Add Role'
            );
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Add Role',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Add Role'
            );
          }
        );
      }
    } else {
    }
  }
  editProduct(product: any) {
    this.product = { ...product };
    this.action_save = true;
    this.display_role = true;
  }
  editProductDetail(product_detail: any) {
    this.product = { ...product_detail };
    this.display_role_detail = true;
    this.systemConfigurationService.GetRoleDetail(product_detail).subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this.OMS_ROLE_DETAIL_ARR = [];
          this.loaderService.offLoading();
        } else {
          this.OMS_ROLE_DETAIL_ARR = [];
          this.OMS_ROLE_DETAIL_ARR = data?.result?.features;
          // this.OMS_ROLE_DETAIL_ARR_Update = data?.result?.features;

          const n = this.OMS_ROLE_DETAIL_ARR.length;
          const m = this.OMS_METADATA_FEATURE_ARR.length;

          // set this.OMS_METADATA_FEATURE_ARR checked =false;
          for (let i = 0; i < m; i++) {
            this.OMS_METADATA_FEATURE_ARR[i].checked = false;
          }
          // set this.OMS_METADATA_FEATURE_ARR checked with role;
          for (let i = 0; i < this.OMS_ROLE_DETAIL_ARR.length; i++) {
            for (let j = 0; j < this.OMS_METADATA_FEATURE_ARR.length; j++) {
              if (
                this.OMS_ROLE_DETAIL_ARR[i].featureCode ===
                this.OMS_METADATA_FEATURE_ARR[j].lookupCodeId
              ) {
                this.OMS_METADATA_FEATURE_ARR[j].checked = true;
              }
            }
          }
          // setthis.OMS_ROLE_DETAIL_ARR =true
          for (let i = 0; i < n; i++) {
            this.OMS_ROLE_DETAIL_ARR[i].checked = true;
          }

          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'MetaData',
          error.error.exceptionMessage
            ? error.error.exceptionMessage
            : 'Error List MetaData'
        );
        this.loaderService.offLoading();
      }
    );
  }
  CloseDialog_Role_Detail() {
    this.display_role_detail = false;
  }

  toggleVisibility(event: any, product_feature: any) {
    // have checkox
    this.isChekbox = true;

    let row = product_feature;

    if (event.target.checked == true) {
      row.checked = event.target.checked;
    } else {
      row.checked = event.target.checked;
    }
    // update checkbox = true;
    this.OMS_ROLE_DETAIL_ARR_Update = [];
    for (let i = 0; i < this.OMS_METADATA_FEATURE_ARR?.length; i++) {
      if (this.OMS_METADATA_FEATURE_ARR[i].id === row.id) {
        this.OMS_METADATA_FEATURE_ARR[i].checked = row.checked;
      }
    }

    // add features
    const data_last = this.OMS_ROLE_DETAIL_ARR;
    // console.log(data_last);
    for (let i = 0; i < this.OMS_METADATA_FEATURE_ARR?.length; i++) {
      this.OMS_ROLE_TEMP = {};
      const item = this.OMS_METADATA_FEATURE_ARR[i];
      let _check = true;
      if (item.checked) {
        for (let j = 0; j < data_last.length; j++) {
          if (item.lookupCodeId === data_last[j].featureCode) {
            _check = false;
            this.OMS_ROLE_TEMP = {
              isRead: data_last[j]?.isRead,
              isWrite: data_last[j]?.isWrite,
              featureCode: data_last[j]?.featureCode,
              featureName: data_last[j]?.featureName,
              endpoint: data_last[j]?.endpoint,
              url: data_last[j]?.url,
              remarks: data_last[j]?.remarks,
              checked: event.target.checked,
              isShow: data_last[j]?.isShow,
            };
          }
        }
        if (_check) {
          _check = true;
          this.OMS_ROLE_TEMP = {
            isRead: 'Y',
            isWrite: 'N',
            featureCode: item.lookupCodeId,
            featureName: item.value,
            endpoint: '',
            url: '',
            remarks: '',
            checked: event.target.checked,
            isShow: 'Y',
          };
        }
        this.OMS_ROLE_DETAIL_ARR_Update.push(this.OMS_ROLE_TEMP);
      }
    }

    // Check update edit
    for (let i = 0; i < this.OMS_ROLE_DETAIL_ARR_Update?.length; i++) {
      for (let j = 0; j < this.OMS_ROLE_DETAIL_ARR_TEMP?.length; j++) {
        if (
          this.OMS_ROLE_DETAIL_ARR_Update[i].featureCode ===
          this.OMS_ROLE_DETAIL_ARR_TEMP[j].featureCode
        ) {
          this.OMS_ROLE_DETAIL_ARR_Update[i] = this.OMS_ROLE_DETAIL_ARR_TEMP[j];
        }
      }
    }
    // update OMS_ROLE_DETAIL_ARR
    // console.log(this.OMS_ROLE_DETAIL_ARR_Update);
  }
  editProductDetailRole(product_feature: any) {
    this.display_feature_detail_role = true;
    this.OMS_ROLE_DETAIL = {};
    // Edit feature detail not add feature
    if (this.isChekbox == false) {
      this.OMS_ROLE_DETAIL_ARR_Update = this.OMS_ROLE_DETAIL_ARR;
    } else {
    }
    this.OMS_ROLE_DETAIL_ARR_Update.map((item) => {
      if (item.featureCode == product_feature?.lookupCodeId) {
        this.OMS_ROLE_DETAIL = { ...item };
      }
    });
  }
  onSubmitFeatureDetailRole() {
    this.submitted_Feature_Detail_Role = true;

    if (this.OMS_ROLE_DETAIL_ARR_TEMP.length > 0) {
      let check_ = true;
      for (let i = 0; i < this.OMS_ROLE_DETAIL_ARR_TEMP.length; i++) {
        if (
          this.OMS_ROLE_DETAIL.featureCode ==
          this.OMS_ROLE_DETAIL_ARR_TEMP[i].featureCode
        ) {
          this.OMS_ROLE_DETAIL_ARR_TEMP[i] = this.OMS_ROLE_DETAIL;
          check_ = false;
        }
      }
      if (check_) {
        this.OMS_ROLE_DETAIL_ARR_TEMP.push(this.OMS_ROLE_DETAIL);
      }
    } else {
      this.OMS_ROLE_DETAIL_ARR_TEMP.push(this.OMS_ROLE_DETAIL);
    }

    for (let i = 0; i < this.OMS_ROLE_DETAIL_ARR_Update?.length; i++) {
      for (let j = 0; j < this.OMS_ROLE_DETAIL_ARR_TEMP?.length; j++) {
        if (
          this.OMS_ROLE_DETAIL_ARR_Update[i].featureCode ===
          this.OMS_ROLE_DETAIL_ARR_TEMP[j].featureCode
        ) {
          this.OMS_ROLE_DETAIL_ARR_Update[i] = this.OMS_ROLE_DETAIL_ARR_TEMP[j];
        }
      }
    }
    this.display_feature_detail_role = false;

    // console.log('edit: ', this.OMS_ROLE_DETAIL_ARR_TEMP);
  }
  CloseDialog_FeatureDetailRole() {
    this.display_feature_detail_role = false;
  }
  onSubmitRole_Detail() {
    console.log(this.OMS_ROLE_DETAIL_ARR_Update);
    if (this.OMS_ROLE_DETAIL_ARR_Update.length == 0) {
      this.toastService.addSingle(
        'error',
        'Update Role',
        'No Data Feature Role'
      );
    } else {
      this.systemConfigurationService
        .UpdateFeaturebyRole(this.OMS_ROLE_DETAIL_ARR_Update, this.product)
        .subscribe(
          (data) => {
            this.display_role = false;
            this.OMS_ROLE_DETAIL_ARR_TEMP = [];
            this.fetchRole();
            this.toastService.addSingleShortTime(
              'success',
              'Update Role',
              'Success Update Role'
            );
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Update Role',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Update Role'
            );
          }
        );
    }
    this.display_role_detail = false;
  }
}
