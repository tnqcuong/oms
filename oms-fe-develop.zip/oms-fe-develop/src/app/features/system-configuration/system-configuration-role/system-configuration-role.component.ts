import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { SystemConfigurationService } from '../system-configuration.service';
import {
  OMS_USER_ROLE,
  OMS_USER_FEATURE,
  OMS_METADATA,
} from 'src/app/core/models/systemConfigucation.model';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-system-configuration-role',
  templateUrl: './system-configuration-role.component.html',
  styleUrls: ['./system-configuration-role.component.sass'],
})
export class SystemConfigurationRoleComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    private systemConfigurationService: SystemConfigurationService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private loaderService: LoaderService,
    private confirmationService: ConfirmationService
  ) {}

  _valueSrech = '';
  display_role: boolean = false;
  action_save: boolean = false;
  submitted_Role = false;
  OMS_ROLES_ARR: OMS_METADATA[] = [];
  OMS_ROLES_COUNT = 0;
  loading_ROLES: boolean = false;

  product: OMS_METADATA = new OMS_METADATA();

  ngOnInit(): void {
    this.fetchMetaData();
  }
  fetchMetaData() {
    this.systemConfigurationService.GetRolesParam('').subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this.OMS_ROLES_ARR = [];
          this.loading_ROLES = false;
          this.loaderService.offLoading();
        } else {
          this.OMS_ROLES_ARR = [];
          this.OMS_ROLES_ARR = data?.result?.data;
          this.OMS_ROLES_COUNT = data?.result?.count;
          this.loading_ROLES = true;
          this.loaderService.offLoading();
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'MetaData',
          error.error.exceptionMessage
            ? error.error.exceptionMessage
            : 'Error List MetaData'
        );
        this.loaderService.offLoading();
      }
    );
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  showDialog_MetaData() {
    this.display_role = true;
    this.product = {};
    this.action_save = false;
    this.submitted_Role = false;
  }
}
