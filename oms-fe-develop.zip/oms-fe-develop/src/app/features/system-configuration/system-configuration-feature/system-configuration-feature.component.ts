import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { SystemConfigurationService } from '../system-configuration.service';
import {
  OMS_USER_ROLE,
  OMS_USER_FEATURE,
  OMS_METADATA,
} from 'src/app/core/models/systemConfigucation.model';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-system-configuration-feature',
  templateUrl: './system-configuration-feature.component.html',
  styleUrls: ['./system-configuration-feature.component.sass'],
  providers: [ConfirmationService],
})
export class SystemConfigurationFeatureComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    private systemConfigurationService: SystemConfigurationService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private loaderService: LoaderService,
    private confirmationService: ConfirmationService
  ) {
    this.searchForm = new FormGroup({
      _lookupCodeSearch: new FormControl(''),
    });
    this.MetaDataFeatureForm = this.formBuilder.group({
      lookupCodeId: ['', Validators.required],
      // lookupCode: ['', Validators.required],
      value: ['', Validators.required],
      // language: ['VN', Validators.required],
      orderBy: ['1', Validators.required],
      // isShow: ['', Validators.required],
    });
  }

  _valueSrech = '';
  searchForm: FormGroup;
  MetaDataFeatureForm: FormGroup;
  submitted_MetaData_Feature = false;
  product: OMS_METADATA = new OMS_METADATA();
  action_save: boolean = false;

  OMS_METADATA_FEATURE_ARR: OMS_METADATA[] = [];
  OMS_METADATA_FEATURE_COUNT = 0;
  loading_metadata_feature: boolean = false;
  display_metadata__feature: boolean = false;

  ngOnInit(): void {
    this.fetchMetaData_Feature();
  }
  get f_M() {
    return this.MetaDataFeatureForm.controls;
  }
  onSubmitMetaData() {
    this.submitted_MetaData_Feature = true;
    if (
      this.product.lookupCodeId?.trim() &&
      this.product.orderBy?.trim() &&
      this.product.value?.trim()
    ) {
      if (this.action_save) {
        this.systemConfigurationService
          .UpdateMetaDataFeature(this.product)
          .subscribe(
            (data) => {
              this.display_metadata__feature = false;
              this.fetchMetaData_Feature();
              this.toastService.addSingleShortTime(
                'success',
                'Update MetaData',
                'Success Update Metadata'
              );
            },
            (error) => {
              this.toastService.addSingle(
                'error',
                'Update MetaData',
                error.error?.exceptionMessage
                  ? error.error.exceptionMessage
                  : 'Can not Update Metadata'
              );
            }
          );
      } else {
        this.systemConfigurationService
          .AddMetaDataFeature(this.product)
          .subscribe(
            (data) => {
              this.display_metadata__feature = false;
              this.fetchMetaData_Feature();
              this.toastService.addSingle(
                'success',
                'Add MetaData',
                'Success Add Metadata'
              );
            },
            (error) => {
              this.toastService.addSingle(
                'error',
                'Add MetaData',
                error.error?.exceptionMessage
                  ? error.error.exceptionMessage
                  : 'Can not Add Metadata'
              );
            }
          );
      }
    } else {
    }
  }

  showDialog_MetaData_Feature() {
    this.product = {};
    this.display_metadata__feature = true;
    this.action_save = false;
    this.submitted_MetaData_Feature = false;
  }
  CloseDialog_MetaData_Feature() {
    this.display_metadata__feature = false;
    this.submitted_MetaData_Feature = false;
    this.action_save = false;
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchMetaData_Feature() {
    this.loaderService.onLoading();
    this.systemConfigurationService
      .GetMetaDataFeatureParam(this.searchForm.value._lookupCodeSearch)
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this.OMS_METADATA_FEATURE_ARR = [];
            this.loading_metadata_feature = false;
            this.loaderService.offLoading();
          } else {
            this.OMS_METADATA_FEATURE_ARR = [];
            this.OMS_METADATA_FEATURE_ARR = data?.result?.data;
            this.OMS_METADATA_FEATURE_COUNT = data?.result?.count;
            this.loading_metadata_feature = true;
            this.loaderService.offLoading();
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'MetaData',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error List MetaData'
          );
          this.loaderService.offLoading();
        }
      );
  }
  editProduct(product: any) {
    this.product = { ...product };
    this.action_save = true;
    this.display_metadata__feature = true;
  }
  deleteProduct(product: any) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + product.value + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.systemConfigurationService
          .DeleteMetaDataFeature(product.id)
          .subscribe(
            (data) => {
              this.fetchMetaData_Feature();
            },
            (error) => {
              this.toastService.addSingle(
                'error',
                'Delete MetaData',
                error.error?.exceptionMessage
                  ? error.error.exceptionMessage
                  : 'Can not Delete Metadata'
              );
            }
          );
      },
    });
  }
  BackPage() {
    this.routeStateService.add(
      'USER MANAGEMENT',
      '/main/system/configuration',
      0,
      true
    );
  }
}
