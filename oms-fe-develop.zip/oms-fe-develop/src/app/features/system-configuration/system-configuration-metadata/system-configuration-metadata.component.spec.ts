import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemConfigurationMetadataComponent } from './system-configuration-metadata.component';

describe('SystemConfigurationMetadataComponent', () => {
  let component: SystemConfigurationMetadataComponent;
  let fixture: ComponentFixture<SystemConfigurationMetadataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SystemConfigurationMetadataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemConfigurationMetadataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
