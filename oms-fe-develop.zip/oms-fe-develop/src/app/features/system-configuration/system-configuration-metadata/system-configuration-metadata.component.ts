import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { SystemConfigurationService } from '../system-configuration.service';
import {
  OMS_USER_ROLE,
  OMS_USER_FEATURE,
  OMS_METADATA,
} from 'src/app/core/models/systemConfigucation.model';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-system-configuration-metadata',
  templateUrl: './system-configuration-metadata.component.html',
  styleUrls: ['./system-configuration-metadata.component.sass'],
  providers: [ConfirmationService],
})
export class SystemConfigurationMetadataComponent implements OnInit {
  searchForm: FormGroup;
  MetaDataForm: FormGroup;

  _valueSrech = '';
  action_save: boolean = false;
  product: OMS_METADATA = new OMS_METADATA();

  OMS_METADATA_ARR: OMS_METADATA[] = [];
  OMS_METADATA_COUNT = 0;
  loading_metadata: boolean = false;
  display_metadata: boolean = false;
  submitted_MetaData = false;

  display_delete_metadata: boolean = false;
  submitted_delete_MetaData = false;

  @ViewChild('closebutton') closebutton:
    | { nativeElement: { click: () => void } }
    | undefined;

  constructor(
    private formBuilder: FormBuilder,
    private systemConfigurationService: SystemConfigurationService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private loaderService: LoaderService,
    private confirmationService: ConfirmationService
  ) {
    this.searchForm = new FormGroup({
      _lookupCodeSearch: new FormControl(''),
    });
    this.MetaDataForm = this.formBuilder.group({
      lookupCodeId: ['', Validators.required],
      lookupCode: ['', Validators.required],
      value: ['', Validators.required],
      language: ['VN', Validators.required],
      orderBy: ['1', Validators.required],
    });
  }

  ngOnInit(): void {
    this.fetchMetaData();
  }
  onClickSearchMetaData() {
    this.fetchMetaData();
  }
  fetchMetaData() {
    this.systemConfigurationService
      .GetMetaDataParam(this.searchForm.value._lookupCodeSearch)
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this.OMS_METADATA_ARR = [];
            this.loading_metadata = false;
            this.loaderService.offLoading();
          } else {
            this.OMS_METADATA_ARR = [];
            this.OMS_METADATA_ARR = data?.result?.data;
            this.OMS_METADATA_COUNT = data?.result?.count;
            this.loading_metadata = true;
            this.loaderService.offLoading();
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'MetaData',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error List MetaData'
          );
          this.loaderService.offLoading();
        }
      );
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  showDialog_MetaData() {
    this.display_metadata = true;
    this.product = {};
    this.action_save = false;
    this.submitted_MetaData = false;
  }
  CloseDialog_MetaData() {
    this.display_metadata = false;
  }
  get f_M() {
    return this.MetaDataForm.controls;
  }
  onSubmitMetaData() {
    this.submitted_MetaData = true;
    if (
      this.product.lookupCodeId?.trim() &&
      this.product.lookupCode?.trim() &&
      this.product.language?.trim() &&
      this.product.serviceName?.trim() &&
      this.product.value?.trim()
    ) {
      if (this.action_save) {
        this.systemConfigurationService.UpdateMetaData(this.product).subscribe(
          (data) => {
            this.display_metadata = false;
            this.fetchMetaData();
            this.toastService.addSingleShortTime(
              'success',
              'Update MetaData',
              'Success Update Metadata'
            );
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Update MetaData',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Update Metadata'
            );
          }
        );
      } else {
        this.systemConfigurationService.AddMetaData(this.product).subscribe(
          (data) => {
            this.display_metadata = false;
            this.fetchMetaData();
            this.toastService.addSingleShortTime(
              'success',
              'Add MetaData',
              'Success Add Metadata'
            );
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Add MetaData',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Add Metadata'
            );
          }
        );
      }
    } else {
    }
  }
  showDialog_Delete_MetaData() {
    this.display_delete_metadata = true;
  }
  CloseDialog_Delete_MetaData() {
    this.display_delete_metadata = false;
  }
  editProduct(product: any) {
    this.product = { ...product };
    this.action_save = true;
    this.display_metadata = true;
  }
  deleteProduct(product: any) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + product.value + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.systemConfigurationService.DeleteMetaData(product.id).subscribe(
          (data) => {
            this.fetchMetaData();
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Delete MetaData',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Delete Metadata'
            );
          }
        );
      },
    });
  }
  BackPage() {
    this.routeStateService.add(
      'USER MANAGEMENT',
      '/main/system/configuration',
      0,
      true
    );
  }
}
