import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { SessionService } from 'src/app/core/services/session.service';
@Injectable({
  providedIn: 'root',
})
export class SystemConfigurationService {
  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {}
  GetMetaData(): Observable<any> {
    return this.http.get<any>(
      environment.apiUrl_Authentication + environmentAPI.metadata
    );
  }
  GetMetaDataParam(param_lookupCode: any): Observable<any> {
    let params = new HttpParams();
    params = params.set('_lookupCode', param_lookupCode);
    return this.http.get<any>(
      environment.apiUrl_Authentication + environmentAPI.metadata,
      { params: params }
    );
  }
  GetRolesParam(param_lookupCode: any): Observable<any> {
    let params = new HttpParams();
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);
    params = params.set('_lookupCode', param_lookupCode);
    return this.http.get<any>(
      environment.apiUrl_Authentication + environmentAPI.role,
      { params, headers }
    );
  }
  GetMetaDataFeatureParam(param_lookupCode: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    params = params.set('_lookupCode', param_lookupCode);
    return this.http.get<any>(
      environment.apiUrl_Authentication + environmentAPI.metadata_feature,
      { params, headers }
    );
  }
  AddMetaData(Data: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);

    return this.http.post<any>(
      environment.apiUrl_Authentication + environmentAPI.addMetadata,
      Data,
      { headers }
    );
  }
  UpdateMetaData(Data: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);

    return this.http.patch<any>(
      environment.apiUrl_Authentication +
        environmentAPI.updateMetadata +
        '/' +
        Data.id,
      Data,
      { headers }
    );
  }
  AddMetaDataFeature(Data: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);

    return this.http.post<any>(
      environment.apiUrl_Authentication + environmentAPI.addMetadata_feature,
      Data,
      { headers }
    );
  }
  UpdateMetaDataFeature(Data: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);

    return this.http.patch<any>(
      environment.apiUrl_Authentication +
        environmentAPI.updateMetadata_feature +
        '/' +
        Data.id,
      Data,
      { headers }
    );
  }
  DeleteMetaData(params_id: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let options = {
      headers: headers,
      body: {},
    };

    return this.http.delete<any>(
      environment.apiUrl_Authentication +
        environmentAPI.delMetadata +
        '/' +
        params_id,
      options
    );
  }
  DeleteMetaDataFeature(params_id: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let options = {
      headers: headers,
      body: {},
    };

    return this.http.delete<any>(
      environment.apiUrl_Authentication +
        environmentAPI.delMetadata_feature +
        '/' +
        params_id,
      options
    );
  }
}
