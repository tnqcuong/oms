import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { SystemConfigurationService } from './system-configuration.service';
import {
  OMS_USER_ROLE,
  OMS_USER_FEATURE,
} from 'src/app/core/models/systemConfigucation.model';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { OMS_USER, Roles } from 'src/app/core/models/systemConfigucation.model';
import { LoaderService } from 'src/app/core/services/loader.service';
@Component({
  selector: 'app-system-configuration',
  templateUrl: './system-configuration.component.html',
  styleUrls: ['./system-configuration.component.sass'],
})
export class SystemConfigurationComponent implements OnInit {
  searchForm: FormGroup;

  display: boolean = false;
  display_status: boolean = false;
  display_password: boolean = false;

  action_status: boolean = false;

  submitted_adduser: boolean = false;

  OMS_USER: OMS_USER = new OMS_USER();

  OMS_USER_ROLE: OMS_USER_ROLE[] = [];
  OMS_USER_ROLE_LENGTH = 0;

  OMS_USERNAME: OMS_USER = new OMS_USER();

  USER_TEMP = new OMS_USER();

  action_save: boolean = false;
  _valueSrech = '';

  loading_user: boolean = false;

  display_role: boolean = false;

  _valueDetailSrech = '';

  constructor(
    private systemConfigurationService: SystemConfigurationService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private loaderService: LoaderService
  ) {
    this.searchForm = new FormGroup({
      usernameSearch: new FormControl('', Validators.required),
    });
  }

  ngOnInit(): void {
    this.fetchGetRole();
    this.fetchUser();
  }
  fetchGetRole() {
    this.systemConfigurationService.GetRolesParam('').subscribe(
      (data) => {
        if (this.isEmptyObject(data?.result)) {
          this.OMS_USER_ROLE = [];
        } else {
          this.OMS_USER_ROLE = [];

          this.OMS_USER_ROLE = data?.result?.data;
          this.OMS_USER_ROLE_LENGTH = data?.result?.count;
        }
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Roles',
          error.error.exceptionMessage
            ? error.error.exceptionMessage
            : 'Error List Roles'
        );
      }
    );
  }
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }
  fetchUser() {
    this.systemConfigurationService
      .GetUserByUserName(this.searchForm.value.usernameSearch)
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data?.result)) {
            this.loading_user = false;
          } else {
            this.OMS_USERNAME = data?.result;
            this.loading_user = true;
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'User',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error List User'
          );
        }
      );
  }

  onClickSearchUser() {
    this.fetchUser();
  }

  showDialog() {
    this.OMS_USER = {};
    this.display = true;
    this.action_save = false;
    this.submitted_adduser = false;
  }
  CloseAddUser() {
    this.display = false;
    this.action_save = false;
    this.submitted_adduser = false;
  }
  SaveAddUser() {
    this.submitted_adduser = true;
    if (
      this.OMS_USER.userName?.trim() &&
      this.OMS_USER.password?.trim() &&
      this.OMS_USER.roles?.length &&
      this.OMS_USER.fullname?.trim()
    ) {
      if (this.action_save) {
        // console.log(this.OMS_USER);
      } else {
        let roles: { roleCode: string | undefined }[] = [];
        this.OMS_USER.roles.map((item) => {
          roles.push({ roleCode: item.lookupCodeId });
        });
        this.OMS_USER.roles = roles;

        this.systemConfigurationService.AddUser(this.OMS_USER).subscribe(
          (data) => {
            this.display = false;
            this.fetchGetRole();
            this.toastService.addSingleShortTime(
              'success',
              'Add User',
              'Success Add User'
            );
          },
          (error) => {
            this.fetchGetRole();
            this.toastService.addSingle(
              'error',
              'Add User',
              error.error?.exceptionMessage
                ? error.error.exceptionMessage
                : 'Can not Add User'
            );
          }
        );
      }
    }
    // this.display = false;
  }
  OpenUser() {
    this.display_status = true;
    this.action_status = true;
  }
  LockUser() {
    this.display_status = true;
    this.action_status = false;
  }
  CloseUser() {
    this.display_status = false;
  }
  SaveUser() {
    if (this.action_status) {
      this.systemConfigurationService
        .UpdateStatusUserActive(this.OMS_USERNAME)
        .subscribe(
          (data) => {
            this.fetchUser();
            this.display_status = false;
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'User',
              error.error.exceptionMessage
                ? error.error.exceptionMessage
                : 'Error Update User'
            );
          }
        );
    } else {
      this.systemConfigurationService
        .UpdateStatusUserDeActive(this.OMS_USERNAME)
        .subscribe(
          (data) => {
            this.display_status = false;
            this.fetchUser();
          },
          (error) => {
            this.toastService.addSingle(
              'error',
              'User',
              error.error.exceptionMessage
                ? error.error.exceptionMessage
                : 'Error Update User'
            );
          }
        );
    }
  }
  editUser() {
    this.display_password = true;
  }

  SavePasswordUser() {
    this.systemConfigurationService
      .UpdatePasswordUserActive(this.OMS_USERNAME)
      .subscribe(
        (data) => {
          this.display_password = false;
          this.toastService.addSingleShortTime(
            'success',
            'User',
            'Success Update Password User'
          );
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'User',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error Update Password User'
          );
        }
      );
  }
  ClosePasswordUser() {
    this.display_password = false;
  }
  log(log: any) {
    console.log(log);
  }
  editUserRole(USERNAME: any) {
    this.display_role = true;
    for (let i = 0; i < this.OMS_USER_ROLE.length; i++) {
      this.OMS_USER_ROLE[i].checked = false;
    }
    for (let i = 0; i < USERNAME?.roles?.length; i++) {
      for (let j = 0; j < this.OMS_USER_ROLE.length; j++) {
        if (USERNAME?.roles[i].roleCode == this.OMS_USER_ROLE[j].lookupCodeId) {
          this.OMS_USER_ROLE[j].checked = true;
        }
      }
    }
  }

  onSubmitRole() {
    this.display_role = true;
    this.systemConfigurationService
      .UpdateRoleUserbyAdmin(this.USER_TEMP)
      .subscribe(
        (data) => {
          this.display_role = false;
          this.fetchUser();
          this.toastService.addSingleShortTime(
            'success',
            'Update Role',
            'Success Update Role'
          );
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Update Role',
            error.error.exceptionMessage
              ? error.error.exceptionMessage
              : 'Error Update Role'
          );
        }
      );
  }
  CloseRole() {
    this.display_role = false;
  }
  toggleVisibility(event: any, OMS_User: any) {
    let row = OMS_User;
    if (event.target.checked == true) {
      row.checked = event.target.checked;
    } else {
      row.checked = event.target.checked;
    }
    let roles_update: { roleCode: string | undefined }[] = [];

    for (let i = 0; i < this.OMS_USER_ROLE.length; i++) {
      if (this.OMS_USER_ROLE[i].checked === true) {
        roles_update.push({ roleCode: this.OMS_USER_ROLE[i].lookupCodeId });
      }
    }
    this.USER_TEMP.roles = roles_update;
    this.USER_TEMP.userName = this.OMS_USERNAME.userName;
  }
  goToMetaData() {
    this.routeStateService.add(
      'METADATA',
      '/main/system/configuration/metadata',
      0,
      true
    );
  }
  goToFeatures() {
    this.routeStateService.add(
      'FEATURES',
      '/main/system/configuration/feature',
      0,
      true
    );
  }
  goToRole() {
    this.routeStateService.add(
      'ROLE',
      '/main/system/configuration/role',
      0,
      true
    );
  }
}
