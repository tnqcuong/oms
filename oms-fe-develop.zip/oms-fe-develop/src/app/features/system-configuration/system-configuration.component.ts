import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { SystemConfigurationService } from './system-configuration.service';
import {
  OMS_USER_ROLE,
  OMS_USER_FEATURE,
} from 'src/app/core/models/systemConfigucation.model';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-system-configuration',
  templateUrl: './system-configuration.component.html',
  styleUrls: ['./system-configuration.component.sass'],
})
export class SystemConfigurationComponent implements OnInit {
  searchForm: FormGroup;

  registerForm: FormGroup;
  submitted = false;

  MetaDataForm: FormGroup;
  submitted_MetaData = false;

  display: boolean = false;
  display_metadata: boolean = false;

  OMS_USER_ROLE: OMS_USER_ROLE[] = [];
  OMS_USER_ROLE_LENGTH = 0;

  OMS_USER_FEATURE: OMS_USER_FEATURE[] = [];
  OMS_USER_FEATURE_LENGTH = 0;

  constructor(
    private formBuilder: FormBuilder,
    private systemConfigurationService: SystemConfigurationService,
    private toastService: ToastService,
    private routeStateService: RouteStateService
  ) {
    this.searchForm = new FormGroup({
      usernameSearch: new FormControl('', Validators.required),
    });
    this.registerForm = this.formBuilder.group({
      fullname: ['', Validators.required],
      username: ['', Validators.required],
      selectedRole: ['', Validators.required],
    });
    this.MetaDataForm = this.formBuilder.group({
      lookupCodeId: ['', Validators.required],
      lookupCode: ['', Validators.required],
      value: ['', Validators.required],
      language: ['VN', Validators.required],
      orderBy: ['1', Validators.required],
    });
  }

  ngOnInit(): void {
    this.systemConfigurationService.GetMetaData().subscribe(
      (data) => {
        for (let i = 0; i < data.result.data.length; i++) {
          if (
            data.result.data[i].lookupCode === 'OMS_USER_ROLE' &&
            data.result.data[i].lookupCodeId !== 'OMS_USER_ROLE_ADMIN'
          ) {
            this.OMS_USER_ROLE.push(data.result.data[i]);
          }
          if(data.result.data[i].lookupCode === 'OMS_USER_FEATURE')
          {
            this.OMS_USER_FEATURE.push(data.result.data[i]);
          }
        }
        this.OMS_USER_ROLE_LENGTH = this.OMS_USER_ROLE.length;
        this.OMS_USER_FEATURE_LENGTH = this.OMS_USER_FEATURE.length;
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'MetaData',
          error.error.exceptionMessage
            ? error.error.exceptionMessage
            : 'Error List OMS_USER'
        );
      }
    );
  }

  onClickSearchUser() {
    console.log(this.searchForm.value.usernameSearch);
  }

  showDialog() {
    this.display = true;
  }
  CloseDialog() {
    this.display = false;
  }

  showDialog_MetaData() {
    this.display_metadata = true;
  }
  CloseDialog_MetaData() {
    this.display_metadata = false;
  }
  get f() {
    return this.registerForm.controls;
  }
  get f_M() {
    return this.MetaDataForm.controls;
  }
  onSubmitRegisterForm() {
    // this.display = false;
    this.submitted = true;
    console.log(this.registerForm.value);
    if (this.registerForm.invalid) {
      return;
    }
  }
  onSubmitMetaData() {
    // this.display_metadata = false;
    this.submitted_MetaData = true;
    if (this.MetaDataForm.invalid) {
      return;
    }
    this.systemConfigurationService.AddMetaData(this.MetaDataForm).subscribe(
      (data) =>{
        console.log(data);
      },
      (error) =>{
        this.toastService.addSingle(
          'error',
          'Add MetaData',
          error.error?.exceptionMessage
            ? error.error.exceptionMessage
            : 'Can not Add Metadata'
        );
      }
    )
  }
  log(log: any) {
    console.log(log);
  }
  goToMetaData()
  {
    this.routeStateService.add(
      'METADATA',
      '/system/configuration/metadata',
      0,
      true
    );
  }
  goToFeatures()
  {
    this.routeStateService.add(
      'FEATURES',
      '/system/configuration/feature',
      0,
      true
    );
  }
  goToRole()
  {
    this.routeStateService.add(
      'ROLE',
      '/system/configuration/role',
      0,
      true
    );
  }
}
