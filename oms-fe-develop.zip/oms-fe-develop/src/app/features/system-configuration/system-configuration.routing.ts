import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SystemConfigurationComponent } from 'src/app/features/system-configuration/system-configuration.component';
import { SystemConfigurationMetadataComponent } from 'src/app/features/system-configuration/system-configuration-metadata/system-configuration-metadata.component';
import { SystemConfigurationFeatureComponent } from 'src/app/features/system-configuration/system-configuration-feature/system-configuration-feature.component';
import { SystemConfigurationRoleComponent } from 'src/app/features/system-configuration/system-configuration-role/system-configuration-role.component';
const routes: Routes = [
  {
    path: '',
    component: SystemConfigurationComponent,
  },
  {
    path: 'metadata',
    component: SystemConfigurationMetadataComponent,
  },
  {
    path: 'feature',
    component: SystemConfigurationFeatureComponent,
  },
  {
    path: 'role',
    component: SystemConfigurationRoleComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SystemConfigurationRoutingModule {}
