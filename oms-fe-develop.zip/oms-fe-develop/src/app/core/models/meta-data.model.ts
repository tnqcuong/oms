export class MetaData {
  id:number = 0;
  serviceName: string = '';
  lookupCode: string = '';
  lookupCodeId: string = '';
  value: string = '';
  orderBy: string = '';
}
