export class Form {
  loan_no?: string;
  cif?: string;
  customer_name?: string;
  rpa_amount?: string;
  et_amount?: string;
  last_payment_amount?: string;
  last_payment_date?: string;
  et_form_scan_date?: string;
  simulated_et_date?: string;
  remarks?: string;
  last_change_amount?: string;
  interest_amount?: string;
  overdue_fee?: string;
  checked?: boolean;
}
export class FormPayment {
  loan_no?: string;
  cif?: string;
  customer_name?: string;
  rpa_amount?: string;
  et_amount?: string;
  last_payment_amount?: string;
  last_payment_bank_ref?: string;
  last_payment_date?: string;
  et_form_scan_date?: string;
  simulated_et_date?: string;
  checked?: boolean;
}
export class Payment {
  loan_no?: string;
  cif?: string;
  customer_name?: string;
  rpa_amount?: string;
  last_payment_amount?: string;
  last_payment_bank_ref?: string;
  last_payment_date?: string;
  remarks?: string;
  checked?: boolean;
}
export class WaiveOff {
  loan_no?: string;
  cif?: string;
  customer_name?: string;
  delq_status?: string;
  last_due_date?: string;
  principal_bal?: string;
  interest_amount?: string;
  last_change_amount?: string;
  overdue_fee?: string;
  rpa_amount?: string;
  day_diff?: string;
  statusCode?: string;

  checked?: boolean;
}
export class BookIcome {
  loan_no?: string;
  cif?: string;
  customer_name?: string;
  delq_status?: string;
  last_due_date?: string;
  principal_bal?: string;
  interest_amount?: string;
  last_change_amount?: string;
  overdue_fee?: string;
  rpa_amount?: string;
  last_payment_date?: string;
  day_diff_due_date?: string;
  day_diff_pmt_date?: string;
  checked?: boolean;
}
export class Refund {
  loan_no?: string;
  cif?: string;
  customer_name?: string;
  delq_status?: string;
  last_due_date?: string;
  principal_bal?: string;
  interest_amount?: string;
  last_change_amount?: string;
  overdue_fee?: string;
  rpa_amount?: string;
  last_payment_date?: string;
  day_diff?: string;
  checked?: boolean;
}
export class FollowUp {
  customer_phone_no?: string;
  loan_no?: string;
  customer_name?: string;
  collection_account?: string;
  last_payment_bank_ref?: string;
  bank_narration?: string;
  bank_credit_amount?: string;
  emi_amount?: string;
  transaction_date?: string;
  outstanding_principle?: string;
  excess_amount?: string;
  penalty_fees?: string;
  partner_bank?: string;
  followup_note?: string;
  last_due_date?: string;
  remarks?: string;
  checked?: boolean;
  checked_remark: boolean = false;

}
