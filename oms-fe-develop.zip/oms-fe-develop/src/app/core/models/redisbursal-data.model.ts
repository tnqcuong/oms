export class Redisbursal {
  id: number = 0;
  loanNo: string = '';
  trxDate: string = '';
  refNo: string = '';
  drAmt: number = 0;
  crAmt: number = 0;
  diffAmt: number = 0;
  remark: string = '';
  orgRefNo: string = '';
  orgTrxDate: string = '';
  cusName: string = '';
  partyName: string = '';
  attFileName: string = '';
  bankCode: string = '';
  redisbType: string = '';
  benAcc: string = '';
  bencBankCode: string = '';
  bencBankName: string = '';
  selected?:boolean = false;
}
