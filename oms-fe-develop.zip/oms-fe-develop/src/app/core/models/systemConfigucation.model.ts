export class OMS_USER_ROLE{
  id?:string;
  lookupCodeId?:string;
  value?:string;
  isShow?:string;
}
export class OMS_USER_FEATURE{
  id?:string;
  lookupCodeId?:string;
  value?:string;
  isShow?:string;
}
export class OMS_METADATA{
  id?:string;
  lookupCode?:string;
  lookupCodeId?:string;
  language?:string;
  value?:string;
  orderBy?:string;
  isShow?:string;
}
