export class OMS_USER_ROLE {
  serviceName?: string;
  value?: string;
  isShow?: string;
  orderBy?: string;
  lookupCodeId?: string;
  lookupCode?: string;
  language?: string;
  checked?: boolean;
}
export class OMS_USER_FEATURE {
  id?: string;
  lookupCodeId?: string;
  value?: string;
  isShow?: string;
  checked?: boolean;
}
export class OMS_METADATA {
  id?: string;
  lookupCode?: string;
  lookupCodeId?: string;
  language?: string;
  value?: string;
  orderBy?: string;
  isShow?: string;
  serviceName?: string;
  checked?: boolean;

}

export class OMS_FEATURE_ROLE {
  endpoint?: string;
  url?: string;
  featureCode?: string;
  featureName?: string;
  isRead?: string;
  isShow?: string;
  isWrite?: string;
  remarks?: string;
  checked?: boolean;
}

export class OMS_USER {
  userName?: string;
  password?: string;
  fullname?: string;
  status?: string;
  token?: string;
  roles?: Roles[];
  checked?: boolean;
}

export class Roles {
  roleCode?: string;
  roleName?: string;
  isShow?: string;
  lookupCodeId?: string;
  features?: Features[];
  checked?: boolean;
}

export class Features {
  featureCode?: string;
  featureName?: string;
  isRead?: string;
  isWrite?: string;
  endpoint?: string;
  remarks?: string;
  isShow?: string;
  checked?: boolean;
}
