export class Refund {
  refDate: string = '';
  bankCode: string = '';
  loanNo: string = '';
  customerName: string = '';
  crAmt: number = 0;
  cusBankAcc: string = '';
  cusBankCode: string = '';
  cusBankName: string = '';
  branch: string = '';
  transferFee: number = 0;
  civil: string = '';
}
