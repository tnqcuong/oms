export class Registrantion {
  loanNo: string = '';
  sentDate: string = '';
  signedLocation: string = '';
}
export class searchRegistrantion {
  id?: string;
  value?: string;
}

export class RegistrantionList{
  adType?: string;
  authorizeDt?: string;
  bankName?: string;
  branch?: string;
  customerName?: string;
  doc36?: string;
  firstDt?: string;
  roUser?: string;
  autosalDay?: string;
  loanNo?: string;
  firstDueDt?: string;
  checked?: boolean;
}
export class GetPushRegistrx{
  loanNo?: string;
}
export class GetRegistrx{
  loanNo?: string;
  customerName?: string;
  authorizeDt?: string;
  firstDt?: string;
  branch?: string;
  roUser?: string;
  bankName?: string;
  adType?: string;
  autosalDay?: string;
  sendDt?: string;
  signedLocation?: string;
  sendUser?: string;
  checked?: boolean;
}
export class GetRegistrxReceivedHard{
  loanNo?: string;
  customerName?: string;
  authorizeDt?: string;
  firstDt?: string;
  branch?: string;
  roUser?: string;
  bankName?: string;
  adType?: string;
  autosalDay?: string;
  sendDt?: string;
  sendUser?: string;
  receiveDt?: string;
  receiveUser?: string;

  bankResultDt?: string;
  registrationResult?: string;
  reason?: string;
  smsADDt?: string;
  checked?: boolean;
  smsADDtStatus?: string;
}
export class GetRegistrxRegistrantionBank{
  loanNo?: string;
  customerName?: string;
  authorizeDt?: string;
  firstDt?: string;
  branch?: string;
  roUser?: string;
  bankName?: string;
  adType?: string;
  autosalDay?: string;
  sendDt?: string;
  receiveDt?: string;
  sendBankDt?: string;
}
export class GetSMS{
  loanNo?: string;
  customerName?: string;
  authorizeDt?: string;
  firstDt?: string;
  branch?: string;
  roUser?: string;
  bankName?: string;
  adType?: string;
  autosalDay?: string;
  doc36?: string;
  sendDt?: string;
  signedLocation?: string;
  sendUser?: string;
  statusCode?: string;
  receiveDt?: string;
  receiveUser?: string;
  sendBankDt?: string;
  smsDueDt?: string;
  checked?: boolean;
  smsDueDtStatus?: string;
}
export class GetRegistrxRegistrantionBankDone{
  loanNo?: string;
  customerName?: string;
  authorizeDt?: string;
  firstDt?: string;

  bankResultDt?:string;
  registrationResult?:string;

  failReason?:string;
  smsAdFail?:string;
}
export class ResultImportFile{
  loanNo?:string;
  effectiveDt?:string;
  location?:string;
  errorMessage?:string;
  No?:string;
}
export class ResultImportFileBank{
  loanNo?:string;
  result?:string;
  reason?:string;
  errorMessage?:string;
}
