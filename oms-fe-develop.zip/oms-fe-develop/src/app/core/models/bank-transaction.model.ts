export class BankTransaction {
  id: number = 0;
  refNo: string = '';
  trxDt: string = '';
  bankCode: string = '';
  drAmt: number = 0;
  crAmt: number = 0;
  loanNo: string = '';
  statusCode: number = 0;
  subStatusCode: number = 0;
  remark: string = '';
  remarkNote: string = '';
  selected?:boolean = false;
}
