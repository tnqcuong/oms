import { Role, Url_OMS } from "src/environments/environmentAPI";

export class User {
  userName?: string;
  token?: string;
  fullname?: string;
  // roles?: Roles[];
  roles?: Roles[];
  role?: Role[];
  feature?: Url_OMS[];
}

export enum Feature {
  OMS_USER_FEATURE_REG = 'OMS_USER_FEATURE_REG',
}

export class Roles {
  roleCode?: string;
  roleName?: string;
  isShow?: string;
  features?: Features[];
}

export class Features{
  featureCode?: string;
  featureName?: string;
  isRead?: string;
  isWrite?: string;
  url?: string;
  endpoint?: string;
}

