export class User {
  userName?: string;
  token?: string;
  roles?: Roles[];
}

export class Roles {
  roleCode?: string;
  roleName?: string;
  features?: Features[];
}

export class Features{
  featureCode?: string;
  featureName?: string;
  isRead?: string;
  isWrite?: string;
}
