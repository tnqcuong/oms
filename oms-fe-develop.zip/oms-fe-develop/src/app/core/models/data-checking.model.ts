export class DataChecking {
  uploadDt: string = '';
  bankCode: string = '';
  bankName: string = '';
  fileName: string = '';
  openBalance: number = 0;
  closeBalance: number = 0;
  processStatus: number = 0;
  fileStatus: number = 0;
  totalCount: number = 0;
  successCount: number = 0;
  fileValidCount: number = 0;
  remark: string = '';
  isBank: string = '';
  isRepayment: string = '';
  fileCnt: number = 0;
}
