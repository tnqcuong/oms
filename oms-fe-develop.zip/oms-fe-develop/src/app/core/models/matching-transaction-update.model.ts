export class MatchingTransactionUpdate {
  bankStatemenTrxInfo: TransactionUpdate = new TransactionUpdate();
  lmsTrxInfo: TransactionUpdate = new TransactionUpdate()
}

export class TransactionUpdate {
  id: number = 0;
  refNo: string = '';
  statusCode: number = 0;
  remarkNote?: string;
}

