import { BankTransaction } from './bank-transaction.model';
import { LMSTransaction } from './lms-transaction.model';

export class CommonInfo {
  headerData: CommonInfoHeader = new CommonInfoHeader();
  totalRecordMatching: CommonInfoTotalRecordMatching = new CommonInfoTotalRecordMatching();
  totalRecordUnMatching: CommonInfoTotalRecordUnMatching = new CommonInfoTotalRecordUnMatching();
  totalRecordGrandData: CommonInfoTotalRecordGrandData = new CommonInfoTotalRecordGrandData();
}

export class CommonInfoTotalRecordMatching {
  bankStatemenTrxInfo: BankTransaction = new BankTransaction();
  lmsTrxInfo: LMSTransaction = new LMSTransaction();
  errorMessage: string = '';
}

export class CommonInfoTotalRecordUnMatching {
  bankStatemenTrxInfo: BankTransaction = new BankTransaction();
  lmsTrxInfo: LMSTransaction = new LMSTransaction();
  errorMessage: string = '';
}

export class CommonInfoTotalRecordGrandData {
  bankStatemenTrxInfo: BankTransaction = new BankTransaction();
  lmsTrxInfo: LMSTransaction = new LMSTransaction();
  errorMessage: string = '';
}

export class CommonInfoHeader {
  uploadDt: string = '';
  bankCode: string = '';
  bankName: string = '';
  fileName: string = '';
  openBalance: number = 0;
  closeBalance: number = 0;
  processStatus: number = 0;
  fileStatus: number = 0;
  totalCount: number = 0;
  successCount: number = 0;
  fileValidCount: number = 0;
  remark: string = '';
  isBank: string = 'Y';
  isRepayment: string = '';
  fileCnt: number = 0;
}
