import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from '@angular/router';
import { UserContextService } from 'src/app/core/services/user-context.service';
import { ToastService } from 'src/app/core/services/toast.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private userContextService: UserContextService,
    private toastService: ToastService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    // var user = this.userContextService.user$.getValue();
    var currentUserValue = this.userContextService.userValue;
    let check_role = false;
    let check_feature = false;
    if (currentUserValue) {
      if (route.data.roles) {
        // const abc = currentUserValue;
        // const bcv = route.data.roles;
        if (
          Array.isArray(route.data.roles) &&
          Array.isArray(currentUserValue.role)
        ) {
          for (let i = 0; i < route.data.roles.length; i++) {
            for (let j = 0; j < currentUserValue.role.length; j++) {
              if (route.data.roles[i] === currentUserValue.role[j]) {
                check_role = true;
                break;
              }
            }
          }
        }

        if (check_role) {
          return true;
        } else {
          this.toastService.addSingle('error', 'Authorized', `The User ${currentUserValue.userName} can not access this resource.`);
          this.router.navigate(['main/dashboard'], {
            queryParams: { returnUrl: state.url },
          });
          return false;
        }
      }
      if (route.data.feature) {
        const abc = currentUserValue.feature;
        const bcv = route.data.feature;
        if (
          Array.isArray(route.data.feature) &&
          Array.isArray(currentUserValue.feature)
        ) {
          for (let i = 0; i < route.data.feature.length; i++) {
            for (let j = 0; j < currentUserValue.feature.length; j++) {
              if (route.data.feature[i] === currentUserValue.feature[j]) {
                check_feature = true;
                break;
              }
            }
          }
          if (check_feature) {
            return true;
          } else {
            this.toastService.addSingle('error', 'Authorized', `The User ${currentUserValue.userName} can not access this resource.`);
            this.router.navigate(['main/dashboard'], {
              queryParams: { returnUrl: state.url },
            });
            return false;
          }
        }
      }
      // logged in so return true
      return true;
    }

    // not logged in so redirect to login page with the return url and return false
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
}
