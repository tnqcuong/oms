import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
/**
 * loader service
 * toggle loader gif in website
 */
export class LoaderService {
    public status: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    public header: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    loadingCount: number = 0;

    show() {
        this.status.next(true);
    }

    hide() {
        this.status.next(false);
    }

    onLoading(){
      this.loadingCount++;
      this.status.next(this.isLoading());
    }

    offLoading(){
      if(this.loadingCount > 0){
        this.loadingCount--;
      }
      this.status.next(this.isLoading());
    }

    isLoading(){
      if(this.loadingCount === 0){
        return false
      }
      return true;
    }

    resetLoading(){
      this.loadingCount = 0;
      this.status.next(this.isLoading());
    }

    showHeader() {
      this.header.next(false);
    }

    hideHeader() {
      this.header.next(true);
    }
}
