import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { SessionService } from 'src/app/core/services/session.service';
import { User } from '../models/user.model';

const defaultUser = null;

@Injectable({
  providedIn: 'root',
})
export class UserContextService {
  // public user$ = BehaviorSubject<User>;
  private user$: BehaviorSubject<User>;
  public user: Observable<User>;

  constructor(private sessionService: SessionService) {
    var data = this.sessionService.getItem('currentUser');
    this.user$ = new BehaviorSubject<User>(
      sessionService.getItem('currentUser')
    );
    this.user = this.user$.asObservable();
    if (this.user) {
      this.user$.next(data);
    }
  }

  public get userValue(): User {
    return this.user$.value;
  }

  public setUser(user: any) {
    this.sessionService.setItem('currentUser', user);
    this.user$.next(user);
  }

  public logout() {
    this.sessionService.removeItem('currentUser');
    this.user$.next({});
  }
}
