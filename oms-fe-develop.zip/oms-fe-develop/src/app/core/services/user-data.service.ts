import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { SessionService } from 'src/app/core/services/session.service';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
/**
 * user service class
 */
export class UserDataService {
  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {}

  /**
   * get user by user name and password
   * @param userName
   * @param password
   */
  getUserByUserNameAndPassword(
    userName: string,
    password: string
  ): Observable<any> {
    const DataUser = {
      userName: userName,
      password: password,
    };
    const body = JSON.stringify(DataUser);
    return this.http.post<any>(
      environment.apiUrl_Authentication + environmentAPI.login,
      body
    );
  }
  GetRoleUser(token: string): Observable<any> {
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', token)
      .set('Authorization', token);
    return this.http.post<any>(
      environment.apiUrl_Authentication + environmentAPI.profile,
      {},
      {
        headers: headers,
      }
    );
  }
}
