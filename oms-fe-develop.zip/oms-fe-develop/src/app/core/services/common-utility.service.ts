import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { MetaData } from '../models/meta-data.model';
import { SearchType } from '../models/searchType.model';
import { SessionService } from './session.service';

@Injectable({
  providedIn: 'root',
})
export class CommonUtilityService {
  bankList: MetaData[] = [];
  EXPORT_AD_REPORT_NAME_LIST: MetaData[] = [];
  bankDisbList: MetaData[] = [];
  bankTrxStatusList: MetaData[] = [];
  lmsTrxStatusList: MetaData[] = [];
  nonBankTrxStatusList: MetaData[] = [];
  nonLmsTrxStatusList: MetaData[] = [];
  disbBankTrxStatusList: MetaData[] = [];
  disbLmsTrxStatusList: MetaData[] = [];
  uploadFileStatusList: MetaData[] = [];
  suspenseStatusList: MetaData[] = [];
  reconSubStatusList: MetaData[] = [];
  allPartnerList: MetaData[] = [];
  searchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_payMode', searchValue: 'Payment Mode' },
    // { searchKey: '_des', searchValue: 'Description' },
  ];

  disbMatchingSearchType: SearchType[] = [
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    // { searchKey: '_des', searchValue: 'Description' },
  ];

  bankSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    // { searchKey: '_des', searchValue: 'Description' },
  ];

  lmsSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_payMode', searchValue: 'Payment Mode' },
    // { searchKey: '_des', searchValue: 'Description' },
  ];

  bankDisbSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
  ];

  lmsDisbSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
  ];
  reconReportSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
  ];

  constructor(private http: HttpClient, private sessionService: SessionService,) {}

  user = this.sessionService.getItem('currentUser');

  getHeaderParams() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'access-token': this.user.token,
    });
  }

  isEmptyObj(obj : object) {
    for(let prop in obj) {
      if(obj.hasOwnProperty(prop)) {
        return false;
      }
    }
    return JSON.stringify(obj) === JSON.stringify({});
  }

  isDisbPartner(codeId: string){
    for(let i = 0; i < this.bankDisbList.length; i++){
      if(this.bankDisbList[i].lookupCodeId == codeId){
        return true;
      }
    }
    return false;
  }

  getStartDateOfMonth(_today : Date){
    return new Date( _today.getFullYear(), _today.getMonth(), 1);
  }

  getEndDateOfMonth(_today : Date){
    return new Date( _today.getFullYear(), _today.getMonth() + 1, 0);
  }

  GetMetaDataBank(): Observable<any> {
    let headerParams = this.getHeaderParams();
    return this.http.get<any>(environment.apiUrl_Authentication + environmentAPI.metadata,{ headers: headerParams});
  }

}
