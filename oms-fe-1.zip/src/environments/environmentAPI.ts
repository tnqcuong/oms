export const environmentAPI = {
  login: 'shinhan/common/authentication',
  metadata: 'shinhan/common/metadata',
  dataChecking: 'shinhan/service/reconcile/statementFileMas',
  repaymentMatchingTrx: 'shinhan/service/reconcile/matchingtrx',
  repaymentUnMatchingTrx: 'shinhan/service/reconcile/unmatchingtrx',
  unMatchingLMSTrx: 'shinhan/service/reconcile/unmatchinglmstrx',
  partnerCommonInfo: 'shinhan/service/reconcile/common',
  report: 'shinhan/service/reconcile/report',
  disbursalMatchingTrx: 'shinhan/service/reconcile/matchingdisbtrx',
  disbursalUnMatchingTrx: 'shinhan/service/reconcile/unmatchingdisbtrx',
  reTry: 'shinhan/service/reconcile/retry',
  reconDailyReport: 'shinhan/service/reconcile/repmtopsreport',
  reconPendingReport: 'shinhan/service/reconcile/pendingReport'
};

export const environmentAPI_Auto = {
  importFile: 'shinhan/service/autodebit/importregistrx',
  importFileBank: 'shinhan/service/autodebit/importbankresult',
  unregistrx: 'shinhan/service/autodebit/unregistrx',
  registrx: 'shinhan/service/autodebit/registrx',
  importhardcopy: 'shinhan/service/autodebit/importhardcopy',
  downloadTemplate: 'shinhan/service/autodebit/template',
  exportbankdata: 'shinhan/service/autodebit/exportbankdata',
  export_unregistrx: 'shinhan/service/autodebit/unregistrx/export',
  updateBankResutl: 'shinhan/service/autodebit/updatebankresult',
  export_hard: 'shinhan/service/autodebit/registrx/export',
  metadata: 'shinhan/common/metadata',
  sms: 'shinhan/service/autodebit/registrx/sms',
  sms_export: 'shinhan/service/autodebit/registrx/sms/export',
  sms_send_unregistrx: 'shinhan/service/autodebit/unregistrx/sensms',
  sms_send_registrx: 'shinhan/service/autodebit/registrx/sensms',
  report: 'shinhan/service/autodebit/exportreport',
};
