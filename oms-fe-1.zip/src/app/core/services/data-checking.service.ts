import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { SessionService } from './session.service';
@Injectable({
  providedIn: 'root',
})
export class DataCheckingService {

  constructor(private http: HttpClient, private sessionService: SessionService) {}

  getDataCheckingList(): Observable<any>{
    let user = this.sessionService.getItem("currentUser");
    const headerParams = {headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      "access-token": user.token
    })};

    return this.http.get<any>(environment.apiUrl + environmentAPI.dataChecking, headerParams);
  }

}
