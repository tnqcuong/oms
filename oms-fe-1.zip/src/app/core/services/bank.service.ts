import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { SessionService } from './session.service';
@Injectable({
  providedIn: 'root',
})
export class BankService {
  user = this.sessionService.getItem('currentUser');

  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {}

  GetMetaDataBank(): Observable<any> {
    return this.http.get<any>(environment.apiUrl + environmentAPI.metadata);
  }

  getHeaderParams() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'access-token': this.user.token,
    });
  }

  getMatchingTransactionByBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.repaymentMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getUnMatchingTransactionForBank(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.repaymentUnMatchingTrx,
      { headers: headerParams, params: params }
    );
  }

  getUnMatchingTransactionForLMS(
    _startDt: string,
    _endDt: string,
    _bankCode: string,
    _number: string,
    _start: string,
    searchType: string,
    searchingValue: string,
    statusFilterValue: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);
    params = params.set('_number', _number);
    params = params.set('_start', _start);
    params = params.set('_statusCode', statusFilterValue);

    if (searchType === '_ref') {
      params = params.set('_ref', searchingValue);
    } else if (searchType === '_loanNo') {
      params = params.set('_loanNo', searchingValue);
    } else if (searchType === '_cif') {
      params = params.set('_cif', searchingValue);
    } else if (searchType === '_payMode') {
      params = params.set('_payMode', searchingValue);
    } else if (searchType === '_des') {
      params = params.set('_des', searchingValue);
    }


    return this.http.get<any>(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      { headers: headerParams, params: params }
    );
  }

  getPartnerCommonInfo(
    _startDt: string,
    _endDt: string,
    _bankCode: string
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_bankCode', _bankCode);

    return this.http.get<any>(
      environment.apiUrl + environmentAPI.partnerCommonInfo,
      { headers: headerParams, params: params }
    );
  }

  updateMatchingTrxStatus(
    isUnMatch: string,
    dataUpdate: any[]
  ): Observable<any> {
    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_isUnmatch', isUnMatch);

    const body = JSON.stringify(dataUpdate);

    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.repaymentMatchingTrx,
      body,
      { headers: headerParams, params: params }
    );
  }

  updateUnMatchingTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.repaymentUnMatchingTrx,
      body,
      { headers: headerParams }
    );
  }

  updateUnMatchingLMSTrxStatus(dataUpdate: any[]): Observable<any> {
    let headerParams = this.getHeaderParams();

    const body = JSON.stringify(dataUpdate);
    return this.http.patch<any>(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      body,
      { headers: headerParams }
    );
  }
}
