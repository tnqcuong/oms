import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { MetaData } from '../models/meta-data.model';
import { SearchType } from '../models/searchType.model';

@Injectable({
  providedIn: 'root',
})
export class CommonUtilityService {
  bankList: MetaData[] = [];
  bankDisbList: MetaData[] = [];
  bankTrxStatusList: MetaData[] = [];
  lmsTrxStatusList: MetaData[] = [];
  nonBankTrxStatusList: MetaData[] = [];
  nonLmsTrxStatusList: MetaData[] = [];
  disbBankTrxStatusList: MetaData[] = [];
  disbLmsTrxStatusList: MetaData[] = [];
  uploadFileStatusList: MetaData[] = [];
  searchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_payMode', searchValue: 'Payment Mode' },
    { searchKey: '_des', searchValue: 'Description' },
  ];

  disbMatchingSearchType: SearchType[] = [
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_des', searchValue: 'Description' },
  ];

  bankSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_des', searchValue: 'Description' },
  ];

  lmsSearchType: SearchType[] = [
    { searchKey: '_ref', searchValue: 'Ref' },
    { searchKey: '_loanNo', searchValue: 'Loan No' },
    { searchKey: '_cif', searchValue: 'CIF' },
    { searchKey: '_payMode', searchValue: 'Payment Mode' },
    { searchKey: '_des', searchValue: 'Description' },
  ];


  constructor(private http: HttpClient) {}

  isEmptyObj(obj : object) {
    for(let prop in obj) {
      if(obj.hasOwnProperty(prop)) {
        return false;
      }
    }
    return JSON.stringify(obj) === JSON.stringify({});
  }

  private getMetaDataBank(): Observable<any> {
    return this.http.get<any>(environment.apiUrl + environmentAPI.metadata);
  }
  getMetadata(){
    this.getMetaDataBank().subscribe(
      (data) => {
        this.bankList = [];
        this.bankDisbList = [];
        this.bankTrxStatusList = [];
        this.lmsTrxStatusList = [];
        this.nonBankTrxStatusList = [];
        this.nonLmsTrxStatusList = [];
        this.disbBankTrxStatusList = [];
        this.disbLmsTrxStatusList = [];
        this.uploadFileStatusList = [];

        for (let i = 0; i < data.result.data.length; i++) {
          if (data.result.data[i].lookupCode === 'BANK_CODE') {
            this.bankList.push(data.result.data[i]);
          }
          if (data.result.data[i].lookupCode === 'BANK_STATEMENT_TRX_STATUS') {
            this.bankTrxStatusList.push(
              data.result.data[i]
            );
          }
          if (data.result.data[i].lookupCode === 'NONBANK_STATEMENT_TRX_STATUS') {
            this.nonBankTrxStatusList.push(
              data.result.data[i]
            );
          }
          if (data.result.data[i].lookupCode === 'LMS_TRX_STATUS') {
            this.lmsTrxStatusList.push(
              data.result.data[i]
            );
          }
          if (data.result.data[i].lookupCode === 'NON_LMS_TRX_STATUS') {
            this.nonLmsTrxStatusList.push(
              data.result.data[i]
            );
          }
          if (data.result.data[i].lookupCode === 'UPLOAD_FILE_STATUS') {
            this.uploadFileStatusList.push(
              data.result.data[i]
            );
          }
          if (data.result.data[i].lookupCode === 'BANK_CODE_DISB') {
            this.bankDisbList.push(
              data.result.data[i]
            );
          }
          if (data.result.data[i].lookupCode === 'BANK_DISBURSAL_STATUS') {
            this.disbBankTrxStatusList.push(
              data.result.data[i]
            );
          }
          if (data.result.data[i].lookupCode === 'LMS_DISB_TRX_STATUS') {
            this.disbLmsTrxStatusList.push(
              data.result.data[i]
            );
          }
        }
      },
      (error) => {}
    );
  }
}
