export class MetaData {
  id:number = 0;
  lookupCode: string = '';
  lookupCodeId: string = '';
  value: string = '';
  orderBy: string = '';
}
