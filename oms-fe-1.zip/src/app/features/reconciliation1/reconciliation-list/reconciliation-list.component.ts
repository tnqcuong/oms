import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-reconciliation-list',
  templateUrl: './reconciliation-list.component.html',
  styleUrls: ['./reconciliation-list.component.sass']
})
export class ReconciliationListComponent implements OnInit {

  constructor(private routeStateService: RouteStateService,) { }

  ngOnInit(): void {
  }

  goToDataChecking(department: number) {
    this.routeStateService.add(
      'DataChecking',
      '/main/reconciliation1/dataChecking',
      department,
      false
    );
  }
  goToRepayment(department: number) {
    this.routeStateService.add(
      'Repayment',
      '/main/reconciliation1/repayment',
      department,
      false
    );
  }
  goToDisbursement(department: number) {
    this.routeStateService.add(
      'Disbursement',
      '/main/reconciliation1/disbursement',
      department,
      false
    );
  }
  goToReports(department: number) {
    this.routeStateService.add(
      'Reports',
      '/main/reconciliation1/reports',
      department,
      false
    );
  }
  goToTransactionConfirmation(department: number) {
    this.routeStateService.add(
      'TransactionConfirmation',
      '/main/reconciliation1/transactionConfirmation',
      department,
      false
    );
  }
}
