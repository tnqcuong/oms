import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Reconciliation1RoutingModule } from './reconciliation1-routing.module';
import { Reconciliation1Component } from './reconciliation1.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { DataCheckingComponent } from './data-checking/data-checking.component';
import { TransactionConfirmationComponent } from './transaction-confirmation/transaction-confirmation.component';
import { ReconciliationListComponent } from './reconciliation-list/reconciliation-list.component';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [Reconciliation1Component, DataCheckingComponent, TransactionConfirmationComponent, ReconciliationListComponent],
  imports: [
    CommonModule,
    AppCommonModule,
    Reconciliation1RoutingModule,
  ]
})
export class Reconciliation1Module { }
