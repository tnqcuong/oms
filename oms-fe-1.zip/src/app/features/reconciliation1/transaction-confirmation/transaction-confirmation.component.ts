import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaction-confirmation',
  templateUrl: './transaction-confirmation.component.html',
  styleUrls: ['./transaction-confirmation.component.sass']
})
export class TransactionConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
