import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Reconciliation1Component } from './reconciliation1.component';

describe('Reconciliation1Component', () => {
  let component: Reconciliation1Component;
  let fixture: ComponentFixture<Reconciliation1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Reconciliation1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Reconciliation1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
