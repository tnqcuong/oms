import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DataCheckingComponent } from './data-checking/data-checking.component';
import { ReconciliationListComponent } from './reconciliation-list/reconciliation-list.component';
import { Reconciliation1Component } from './reconciliation1.component';
import { TransactionConfirmationComponent } from './transaction-confirmation/transaction-confirmation.component';

const routes: Routes = [
  {
    path: '',
    component: ReconciliationListComponent,
    children: [
      {
        path: 'dataChecking',
        component: DataCheckingComponent,
      },
      {
        path: 'repayment',
        loadChildren: () =>
          import('./repayment/repayment.module').then((m) => m.RepaymentModule),
      },
      {
        path: 'disbursement',
        loadChildren: () =>
          import('./disbursement/disbursement.module').then(
            (m) => m.DisbursementModule
          ),
      },
      {
        path: 'reports',
        loadChildren: () =>
          import('./reports/reports.module').then((m) => m.ReportsModule),
      },
      {
        path: 'transactionConfirmation',
        component: TransactionConfirmationComponent,
      },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Reconciliation1RoutingModule {}
