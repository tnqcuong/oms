import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';
import { PendingReportComponent } from './pending-report/pending-report.component';
import { DailyReportComponent } from './daily-report/daily-report.component';
import { SuspenseReportComponent } from './suspense-report/suspense-report.component';
import { WriteoffReportComponent } from './writeoff-report/writeoff-report.component';
import { AppCommonModule } from 'src/app/app.common.module';


@NgModule({
  declarations: [ReportsComponent, PendingReportComponent, DailyReportComponent, SuspenseReportComponent, WriteoffReportComponent],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    AppCommonModule,
  ]
})
export class ReportsModule { }
