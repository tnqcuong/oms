import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DailyReportComponent } from './daily-report/daily-report.component';
import { PendingReportComponent } from './pending-report/pending-report.component';
import { ReportsComponent } from './reports.component';
import { SuspenseReportComponent } from './suspense-report/suspense-report.component';
import { WriteoffReportComponent } from './writeoff-report/writeoff-report.component';

const routes: Routes = [
  { path: '', component: ReportsComponent },
  {
    path: 'pendingReport',
    component: PendingReportComponent,
  },
  {
    path: 'dailyReport',
    component: DailyReportComponent,
  },
  {
    path: 'suspenseReport',
    component: SuspenseReportComponent,
  },
  {
    path: 'writeoffReport',
    component: WriteoffReportComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReportsRoutingModule {}
