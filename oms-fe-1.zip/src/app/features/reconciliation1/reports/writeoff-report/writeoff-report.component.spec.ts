import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WriteoffReportComponent } from './writeoff-report.component';

describe('WriteoffReportComponent', () => {
  let component: WriteoffReportComponent;
  let fixture: ComponentFixture<WriteoffReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WriteoffReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WriteoffReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
