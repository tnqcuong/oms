import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-writeoff-report',
  templateUrl: './writeoff-report.component.html',
  styleUrls: ['./writeoff-report.component.sass']
})
export class WriteoffReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
