import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { SessionService } from 'src/app/core/services/session.service';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';

@Injectable({
  providedIn: 'root',
})

export class ReportsService {

  user = this.sessionService.getItem('currentUser');

  constructor(
    private http: HttpClient,
    private sessionService: SessionService
    ) {}

  getHeaderParams() {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'access-token': this.user.token,
    });
  }

  getReconSummary(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{

    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_trxDt', _trxDt);
    params = params.set('_type', '1');

    return this.http.get<any>(environment.apiUrl + environmentAPI.reconDailyReport,
      { headers: headerParams, params: params });
  }

  getOPSRepaymentDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{

    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_trxDt', _trxDt);
    params = params.set('_type', '2');

    return this.http.get<any>(environment.apiUrl + environmentAPI.reconDailyReport,
      { headers: headerParams, params: params });
  }

  getOPSDisbursalDailyReport(
    _startDt: string,
    _endDt: string,
    _trxDt: string,
  ): Observable<any>{

    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _startDt);
    params = params.set('_endDt', _endDt);
    params = params.set('_trxDt', _trxDt);
    params = params.set('_type', '3');

    return this.http.get<any>(environment.apiUrl + environmentAPI.reconDailyReport,
      { headers: headerParams, params: params });
  }

  getPendingReport(
    _today: string,
    _bankCode: string,
  ): Observable<any>{

    let headerParams = this.getHeaderParams();

    let params = new HttpParams();
    params = params.set('_startDt', _today);
    params = params.set('_bankCode', _bankCode);

    return this.http.get<any>(environment.apiUrl + environmentAPI.reconPendingReport,
      { headers: headerParams, params: params });
  }
}
