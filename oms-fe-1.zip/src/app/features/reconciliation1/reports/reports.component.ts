import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.sass']
})
export class ReportsComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }

  ngOnInit(): void {
  }

  goToPendingReport(department: number) {
    this.routeStateService.add(
      'PendingReport',
      '/main/reconciliation1/reports/pendingReport',
      department,
      false
    );
  }

  goToDailyReport(department: number) {
    this.routeStateService.add(
      'DailyReport',
      '/main/reconciliation1/reports/dailyReport',
      department,
      false
    );
  }

  goToSuspenseReport(department: number) {
    this.routeStateService.add(
      'SuspenseReport',
      '/main/reconciliation1/reports/suspenseReport',
      department,
      false
    );
  }

  goToWriteoffReport(department: number) {
    this.routeStateService.add(
      'WriteoffReport',
      '/main/reconciliation1/reports/writeoffReport',
      department,
      false
    );
  }
}
