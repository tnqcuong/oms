import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suspense-report',
  templateUrl: './suspense-report.component.html',
  styleUrls: ['./suspense-report.component.sass']
})
export class SuspenseReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
