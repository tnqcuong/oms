import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { CommonInfo } from 'src/app/core/models/common-info.model';
import { MatchingTransactionUpdate } from 'src/app/core/models/matching-transaction-update.model';
import { MatchingTransaction } from 'src/app/core/models/matching-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';
import { ReportsService } from '../reports.service';

@Component({
  selector: 'app-pending-report',
  templateUrl: './pending-report.component.html',
  styleUrls: ['./pending-report.component.sass']
})
export class PendingReportComponent implements OnInit {

  _today = new Date();


  _bankList: MetaData[] = [];
  _searchTypeList: SearchType[] = [];
  selectedBank: string = '';

  pendingReport: any[] = [];


  constructor(
    private reportsService: ReportsService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService
  ) {
    this._bankList = commonUtilityService.bankList;
    this._searchTypeList = commonUtilityService.searchType;
  }

  ngOnInit(): void {}

  fetchMatchingTransaction(){
    this.loaderService.onLoading();
    this.reportsService
    .getPendingReport(
      moment(this._today).format('DD/MM/YYYY'),
      this.selectedBank
    )
    .subscribe(
      (data) => {

      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }
}
