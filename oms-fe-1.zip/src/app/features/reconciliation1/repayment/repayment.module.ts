import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RepaymentRoutingModule } from './repayment-routing.module';
import { RepaymentComponent } from './repayment.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { RepaymentReportComponent } from './repayment-report/repayment-report.component';
import { RepaymentUnmatchingComponent } from './repayment-unmatching/repayment-unmatching.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { RepaymentMatchingComponent1 } from './repayment-matching/repayment-matching.component';


@NgModule({
  declarations: [RepaymentComponent, RepaymentReportComponent, RepaymentMatchingComponent1, RepaymentUnmatchingComponent],
  imports: [
    CommonModule,
    AppCommonModule,
    RepaymentRoutingModule,
    NgxPaginationModule,
    HeaderBreadCrumbModule
  ]
})
export class RepaymentModule { }
