import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RepaymentMatchingComponent1 } from './repayment-matching/repayment-matching.component';
import { RepaymentReportComponent } from './repayment-report/repayment-report.component';
import { RepaymentUnmatchingComponent } from './repayment-unmatching/repayment-unmatching.component';
import { RepaymentComponent } from './repayment.component';

const routes: Routes = [
  { path: '', component: RepaymentComponent,},
  {
    path: 'report',
    component: RepaymentReportComponent,
  },
  {
    path: 'matching',
    component: RepaymentMatchingComponent1,
  },
  {
    path: 'unmatching',
    component: RepaymentUnmatchingComponent,
  },
]



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RepaymentRoutingModule {}
