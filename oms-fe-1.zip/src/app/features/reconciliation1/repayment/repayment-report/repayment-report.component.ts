import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { CommonInfo } from 'src/app/core/models/common-info.model';
import { LMSTransaction } from 'src/app/core/models/lms-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ReconciliationService } from '../../reconciliation.service';
import * as file from 'file-saver';

@Component({
  selector: 'app-repayment-report',
  templateUrl: './repayment-report.component.html',
  styleUrls: ['./repayment-report.component.sass']
})
export class RepaymentReportComponent implements OnInit {

  constructor(
    private reconciliationService: ReconciliationService,
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private loaderService: LoaderService,
    private commonUtilityService: CommonUtilityService
  ) {}
  _arrBank: MetaData[] = [];

  _arrBANK_STATEMENT_TRX_STATUS: MetaData[] = [];

  _arrLMS_TRX_STATUS: MetaData[] = [];

  _arrFinance_Dept_Book: BankTransaction[] = [];

  _arrRefund: BankTransaction[] = [];

  _arrRevert: BankTransaction[] = [];

  _arrPendingLMS: BankTransaction[] = [];

  _arrPendingBanks: BankTransaction[] = [];

  _arrPedingBank: BankTransaction[] = [];

  _arrRemainPendingBank: BankTransaction[] = [];

  _arrLMSCancelledTrx: LMSTransaction[] = [];

  _arrLMSMoneyInTransit: LMSTransaction[] = [];

  _arrLMSUploadedThePendingCases: LMSTransaction[] = [];

  _arrCaseHandledBank: LMSTransaction[] = [];

  _lookupCodeId = '';

  _page_pending_lms = 1;

  _page_pending_bank = 1;

  loading: boolean = false;

  loadingPending: boolean = false;

  loadingPendingBANKS: boolean = false;

  dateValue: Date = new Date();

  DayNow = new Date();

  // day select
  _startOf = moment(this.dateValue).startOf('month').format('DD/MM/YYYY');
  _endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');
  _DayNow = moment(this.DayNow).format('DD/MM/YYYY');
  isDay = false;
  isEnd = false;

  GET_Matching: any;
  page_Matching = 1;
  count_Matching = 0;
  tableSize_Matching = 10;

  // Pending Bank
  page_PendingBank = 1;
  count_PendingBank = 0;
  tableSize_PendingBank = 10;

  // Pending LMS
  page_PendingLMS = 1;
  count_PendingLMS = 0;
  tableSize_PendingLMS = 10;

  total_page: string[] = [];

  total_page_banks: string[] = [];

  // pagination
  _page = 1;
  _cant_go_prev = false;
  _cant_go_next = false;
  _nPages = 3;
  _page_items = [
    {
      value: 1,
      href: 1,
      isActive: true,
    },
  ];

  // Partner Common Info
  partnerCommonInfo: CommonInfo = new CommonInfo();

  ngOnInit(): void {
    this._arrBank = this.commonUtilityService.bankList;
    // this._arrBANK_STATEMENT_TRX_STATUS = this.commonUtilityService.bankTrxStatusList;
    // this._arrLMS_TRX_STATUS = this.commonUtilityService.lmsTrxStatusList;
  }

  onChangePagePedingLMS(page: any) {
    this._page_pending_lms = page;
    this.fetchGetPendingLMS();
  }
  onChangePagePedingBANKS(page: any) {
    this._page_pending_bank = page;
    this.fetchGetPendingBank();
  }
  getDataBank() {
    this._startOf = moment(this.dateValue)
      .startOf('month')
      .format('DD/MM/YYYY');
    this._endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');

    let DayOf = this._endOf;

    this._endOf = this._DayNow;

    if (moment(this.dateValue).endOf('month').isBefore(moment(this.DayNow))) {
      this.isDay = true;
      this._endOf = DayOf;
    } else {
      this.isDay = false;
    }

    if (this._lookupCodeId) {
      this.fetchgetPartnerCommonInfo();
      //this.fetchGetMatching();
      //this.fetchGetPendingBank();
      //this.fetchGetPendingLMS();
    } else {
      this.toastService.addSingle('info', 'Select Partner', 'Please select a partner.');
    }
  }

  fetchGetMatching(): void {
    this.loaderService.onLoading();
    this.reconciliationService
      .getMatchingTransactionByBank(
        this._startOf,
        this._endOf,
        this._lookupCodeId,
        this.tableSize_Matching.toString(),
        this.page_Matching.toString(),
        '',
        ''
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this.GET_Matching = [];
            this.loading = false;
          } else {
            this.GET_Matching = data.result.data;
            this.loading = true;
            this.count_Matching = data.result.count;
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'info',
            'Error',
            'Server No Data Matching'
          );
        }
      );
  }
  fetchGetPendingLMS(): void {
    this.loaderService.onLoading();
    this.reconciliationService
      .getUnMatchingTransactionForLMS(
        this._startOf,
        this._endOf,
        this._lookupCodeId,
        this.tableSize_PendingLMS.toString(),
        this._page_pending_lms.toString(),
        '',
        '',
        ''
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this.loadingPending = false;
            this._arrLMSCancelledTrx = [];
            this._arrLMSMoneyInTransit = [];
            this._arrLMSUploadedThePendingCases = [];
          } else {
            this._arrLMSCancelledTrx = [];
            this._arrLMSMoneyInTransit = [];
            this._arrLMSUploadedThePendingCases = [];

            this.loadingPending = true;
            // pagination
            this._arrPendingLMS = data.result.data;
            this.count_PendingLMS = data.result.count;

            const total_page =
              this.count_PendingLMS / this.tableSize_PendingLMS;
            this.total_page = [];
            for (let i = 0; i < total_page; i++) {
              const page = i + 1;
              this.total_page.push(page.toString());
            }
            // pagination
            for (let i = 0; i < data?.result?.data.length; i++) {
              if (data.result.data[i].statusCode == '2' || data.result.data[i].statusCode == '4') {
                this._arrLMSCancelledTrx.push(data.result.data[i]);
              } else {
                this._arrLMSUploadedThePendingCases.push(data.result.data[i]);
              }
            }
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'info',
            'Error',
            'Server No Data PendingLMS'
          );
        }
      );
  }
  fetchGetPendingBank(): void {
    this.loaderService.onLoading();
    this.reconciliationService
      .getUnMatchingTransactionForBank(
        this._startOf,
        this._endOf,
        this._lookupCodeId,
        this.tableSize_PendingBank.toString(),
        this._page_pending_bank.toString(),
        '',
        '',
        ''
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this.loadingPendingBANKS = false;
            this._arrFinance_Dept_Book = [];
            this._arrRefund = [];
            this._arrRevert = [];
            this._arrPedingBank = [];
            // this._arrRemainPendingBank = [];
            this._arrCaseHandledBank = [];
          } else {
            this._arrFinance_Dept_Book = [];
            this._arrRefund = [];
            this._arrRevert = [];
            this._arrPedingBank = [];
            // this._arrRemainPendingBank = [];
            this._arrCaseHandledBank = [];
            this.loadingPendingBANKS = true;
            this.count_PendingBank = data.result.count;
            const total_page_banks =
              this.count_PendingBank / this.tableSize_PendingBank;

            this.total_page_banks = [];

            for (let i = 0; i < total_page_banks; i++) {
              const page = i + 1;
              this.total_page_banks.push(page.toString());
            }
            for (let i = 0; i < data?.result?.data.length; i++) {
              const row = this.checkStatus(data.result.data[i].statusCode);
              if (row == 'Finance Dept Book') {
                this._arrFinance_Dept_Book.push(data.result.data[i]);
              } else if (row == 'Refund') {
                this._arrRefund.push(data.result.data[i]);
              } else if (row == 'Revert') {
                this._arrRevert.push(data.result.data[i]);
              } else if (row == 'Case Handled') {
                this._arrCaseHandledBank.push(data.result.data[i]);
              } else {
                this._arrPedingBank.push(data.result.data[i]);
              }
            }
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'info',
            'Error',
            'Server No Data PendingBank'
          );
        }
      );
  }
  fetchgetPartnerCommonInfo(): void {
    this.loaderService.onLoading();
    this.reconciliationService
      .getPartnerCommonInfo(this._startOf, this._endOf, this._lookupCodeId)
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this.partnerCommonInfo = new CommonInfo();
          } else {
            this.partnerCommonInfo = data.result;
          }

          if(this.partnerCommonInfo.headerData.isBank == 'Y'){
            this._arrBANK_STATEMENT_TRX_STATUS = this.commonUtilityService.bankTrxStatusList;
            this._arrLMS_TRX_STATUS = this.commonUtilityService.lmsTrxStatusList;
          }
          else {
            this._arrBANK_STATEMENT_TRX_STATUS = this.commonUtilityService.nonBankTrxStatusList;
            this._arrLMS_TRX_STATUS = this.commonUtilityService.nonLmsTrxStatusList;
          }

          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'error',
            'Error',
            'No Partner Common Info.'
          );
        }
      );
  }

  onPageChangeTable(event: any) {
    this.page_Matching = event;
    this.fetchGetMatching();
  }

  confirm1() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Excel',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (this._lookupCodeId) {
          this.ExpportExcel();
          this.fetchgetPartnerCommonInfo();
          this.toastService.addSingle(
            'success',
            'Confirmed',
            'You have accepted'
          );
        } else {
          this.toastService.addSingle('info', 'Select Partner', 'Please select a partner.');
        }
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  ExpportExcel() {
    this.download();
  }
  confirm2() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Re-try',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.toastService.addSingle(
          'success',
          'Confirmed',
          'You have accepted'
        );
        this.ReTry();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  ReTry() {
    if (this._lookupCodeId) {
      this.loaderService.onLoading();
      this.reconciliationService.PostRetryBank(this._lookupCodeId).subscribe(
        (data) => {
          this.loaderService.offLoading();
          this.toastService.addSingle('success', 'Re-try', data?.result);
          this.fetchgetPartnerCommonInfo();
          //this.fetchGetMatching();
          //this.fetchGetPendingLMS();
          //this.fetchGetPendingBank();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'error',
            'Re-try',
            error?.error?.exceptionMessage
          );
        }
      );
    } else {
      this.toastService.addSingle('info', 'Select Partner', 'Please select a partner.');
    }
  }
  download() {
    this.loaderService.onLoading();
    this.reconciliationService
      .downloadFile(this._startOf, this._endOf, this._lookupCodeId)
      .subscribe(
        (response) => {
          this.downloadFile(response.body);
          this.loaderService.offLoading();
        },
        (error) => {
          console.log(error);
          this.loaderService.offLoading();
        }
      );
  }

  downloadFile(data: any) {
    // const buftype = 'application/vnd.ms-excel;charset=utf-8';
    // const blob = new Blob([data], { type: buftype });
    // const url = window.URL.createObjectURL(blob);
    // window.open(url);
    const fileName = this.partnerCommonInfo.headerData.bankName || 'Export';
    // import('file-saver').then((FileSaver) => {
    //   let EXCEL_TYPE = 'application/vnd.ms-excel;charset=utf-8';
    //   const blob = new Blob([data], { type: EXCEL_TYPE });
    //   FileSaver.saveAs(blob, fileName + '_' + this._DayNow);
    // });
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + this._DayNow);
  }

  checkStatusLMS(statusCode: any) {
    for (let i = 0; i < this._arrLMS_TRX_STATUS?.length; i++) {
      if (this._arrLMS_TRX_STATUS[i]?.lookupCodeId == statusCode) {
        return this._arrLMS_TRX_STATUS[i].value || '';
      }
    }
    return '';
  }
  checkStatus(statusCode: any) {
    for (let i = 0; i < this._arrBANK_STATEMENT_TRX_STATUS?.length; i++) {
      if (this._arrBANK_STATEMENT_TRX_STATUS[i]?.lookupCodeId == statusCode) {
        return this._arrBANK_STATEMENT_TRX_STATUS[i].value || '';
      }
    }
    return '';
  }
  log(val: any) {
    console.log(val);
  }

}
