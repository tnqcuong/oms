import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepaymentReportComponent } from './repayment-report.component';

describe('RepaymentReportComponent', () => {
  let component: RepaymentReportComponent;
  let fixture: ComponentFixture<RepaymentReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepaymentReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepaymentReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
