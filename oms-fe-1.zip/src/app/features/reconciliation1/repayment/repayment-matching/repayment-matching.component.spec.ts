import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepaymentMatchingComponent1 } from './repayment-matching.component';

describe('RepaymentMatchingComponent', () => {
  let component: RepaymentMatchingComponent1;
  let fixture: ComponentFixture<RepaymentMatchingComponent1>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepaymentMatchingComponent1 ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepaymentMatchingComponent1);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
