import { Component, OnInit } from '@angular/core';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ReconciliationService } from '../reconciliation.service';

@Component({
  selector: 'app-repayment',
  templateUrl: './repayment.component.html',
  styleUrls: ['./repayment.component.sass']
})
export class RepaymentComponent implements OnInit {

  constructor(private routeStateService: RouteStateService,
    private commonUtilityService: CommonUtilityService,
    private reconciliationService: ReconciliationService) { }

  ngOnInit(): void {}

  goToRepaymentReport(department: number) {
    this.routeStateService.add(
      'repaymentReport',
      '/main/reconciliation1/repayment/report',
      department,
      false
    );
  }

  goToRepaymentMatching(department: number) {
    this.routeStateService.add(
      'repaymentReport',
      '/main/reconciliation1/repayment/matching',
      department,
      false
    );
  }

  goToRepaymentUnmatching(department: number) {
    this.routeStateService.add(
      'repaymentReport',
      '/main/reconciliation1/repayment/unmatching',
      department,
      false
    );
  }

}
