import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { CommonInfo } from 'src/app/core/models/common-info.model';
import { LMSTransaction } from 'src/app/core/models/lms-transaction.model';
import { MatchingTransactionUpdate, TransactionUpdate } from 'src/app/core/models/matching-transaction-update.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { DisbursalService } from 'src/app/core/services/disbursal.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-disbursement-unmatching',
  templateUrl: './disbursement-unmatching.component.html',
  styleUrls: ['./disbursement-unmatching.component.sass']
})
export class DisbursementUnmatchingComponent implements OnInit {

  _endDt = new Date();
  _startDt = new Date(this._endDt.getFullYear(), this._endDt.getMonth(), 1);

  _number: number = 10;

  _startBank: number = 1;
  _totalTrxBank: number = 0;

  _startLMS: number = 1;
  _totalTrxLMS: number = 0;

  _bankList: MetaData[] = [];
  _bankTrxStatusList: MetaData[] = [];
  _lmsTrxStatusList: MetaData[] = [];
  _searchTypeList: SearchType[] = [];
  selectedBank: string = '';
  bankSelectedSearchType: string = '_ref';
  bankSearchingValue: string = '';
  lmsSelectedSearchType: string = '_ref';
  lmsSearchingValue: string = '';
  hasBankList: boolean = false;
  hasLMSList: boolean = false;
  isBankCheckAll: boolean = false;
  isLMSCheckAll: boolean = false;
  _showDialog = false;

  //partner common info
  partnerCommonInfo = new CommonInfo()

  _unMatchBankTrnxList: BankTransaction[] = [];
  _unMatchLMSTrnxList: LMSTransaction[] = [];

  lmsStatusFilterValue: string = '';
  bankStatusFilterValue: string = '';

  bankTrxUpdateList: any[] = [];
  lmsTrxUpdateList: any[] = [];

  startIndex: number = 0;
  endIndex: number = 0;

  constructor(
    //private bankService: BankService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService,
    private disbursalService: DisbursalService,
    private confirmationService: ConfirmationService
  ) {
    this._bankList = commonUtilityService.bankDisbList;
    this._searchTypeList = commonUtilityService.searchType;
    this._bankTrxStatusList = commonUtilityService.disbBankTrxStatusList;
    this._lmsTrxStatusList = commonUtilityService.disbLmsTrxStatusList;
  }

  ngOnInit(): void {}

  fetchPartnerCommonInfo() {
    this.loaderService.onLoading();
    this.disbursalService
      .getPartnerCommonInfo(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        this.selectedBank
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this.partnerCommonInfo = new CommonInfo();
          } else {
            this.partnerCommonInfo = data.result
          }

          if(this.partnerCommonInfo.headerData.isBank == 'Y'){
            this._bankTrxStatusList = this.commonUtilityService.bankTrxStatusList;
            this._lmsTrxStatusList = this.commonUtilityService.lmsTrxStatusList;
          }
          else {
            this._bankTrxStatusList = this.commonUtilityService.nonBankTrxStatusList;
            this._lmsTrxStatusList = this.commonUtilityService.nonLmsTrxStatusList;
          }

          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle('error', '', 'Server Error');
          this.loaderService.offLoading();
        }
      );
  }

  fetchUnMatchingTrxForBank() {
    this.loaderService.onLoading();
    this.disbursalService
      .getDisbUnMatchingTransactionForBank(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        this.selectedBank,
        this._number.toString(),
        this._startBank.toString(),
        this.bankSelectedSearchType,
        this.bankSearchingValue,
        this.bankStatusFilterValue
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this._unMatchBankTrnxList = [];
            this._totalTrxBank = 0;
            this.hasBankList = false;
            this.toastService.addSingle('info', 'Bank', data.exceptionMessage);
          } else {
            this._unMatchBankTrnxList = this._unMatchBankTrnxList.concat(data.result.data);
            this._totalTrxBank = data.result.count;
            this.hasBankList = true;
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle('error', '', 'Server Error.');
          this.loaderService.offLoading();
        }
      );
  }

  fetchUnMatchingTrxForLMS() {
    this.loaderService.onLoading();
    this.disbursalService
      .getUnMatchingTransactionForLMS(
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY'),
        this.selectedBank,
        this._number.toString(),
        this._startLMS.toString(),
        this.lmsSelectedSearchType,
        this.lmsSearchingValue,
        this.lmsStatusFilterValue
      )
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this._unMatchLMSTrnxList = [];
            this._totalTrxLMS = 0;
            this.hasLMSList = false;
            this.toastService.addSingle('info', 'LMS', data.exceptionMessage);
          } else {
            this._unMatchLMSTrnxList = this._unMatchLMSTrnxList.concat(data.result.data);
            this._totalTrxLMS = data.result.count;
            this.hasLMSList = true;
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.toastService.addSingle('error', '', 'Server Error.');
          this.loaderService.offLoading();
        }
      );
  }

  searchBankTransaction() {
    if (this.selectedBank === '') {
      this.toastService.addSingle('warn', '', 'Please select partner');
    } else {
      this._startBank = 1;
      //Reset transaction list
      this._unMatchBankTrnxList = [];
      this.fetchPartnerCommonInfo();
      this.fetchUnMatchingTrxForBank();
    }
  }

  searchLMSTransaction() {
    if (this.selectedBank === '') {
      this.toastService.addSingle('warn', '', 'Please select partner');
    } else {
      this._startLMS = 1;
      this._unMatchLMSTrnxList = [];
      this.fetchPartnerCommonInfo();
      this.fetchUnMatchingTrxForLMS();
    }
  }

  getUnMatchingTransactionByBank() {
    if (this.selectedBank === '') {
      this.toastService.addSingle('warn', '', 'Please select partner');
    } else {
      this._startBank = 1;
      this._startLMS = 1;
      //Reset transaction list
      this._unMatchBankTrnxList = [];
      this._unMatchLMSTrnxList = [];
      this.fetchPartnerCommonInfo();
      this.fetchUnMatchingTrxForBank();
      this.fetchUnMatchingTrxForLMS();
    }
  }

  onBankTableDataChange(event: any) {
    this._startBank = event;
    this.fetchUnMatchingTrxForBank();
  }

  onLMSTableDataChange(event: any) {
    this._startLMS = event;
    this.fetchUnMatchingTrxForLMS();
  }
  // onBankTableSizeChange(event: any): void {
  //   this._totalTrxBank = event.target.value;
  //   this._startBank = 1;
  //   this.fetchUnMatchingTrxForBank();
  // }
  // onLMSTableSizeChange(event: any): void {
  //   this._totalTrxLMS = event.target.value;
  //   // this._startLMS = 1;
  //   this.fetchUnMatchingTrxForLMS();
  // }

  updateUnMatchingTrxStatus(body: any[]) {
    this.loaderService.onLoading();
    this.disbursalService.updateUnMatchingTrxStatus(body).subscribe(
      (data) => {
        this.toastService.addSingle('info', '', 'Transaction is updated.');
        this.loaderService.offLoading();
      },
      (error) => {
        this.toastService.addSingle('error', '', 'Server Error.');
        this.loaderService.offLoading();
      }
    );
    //refresh table
    this._startBank = 1;
    this._unMatchBankTrnxList = [];
    this.fetchPartnerCommonInfo();
    this.fetchUnMatchingTrxForBank();
  }

  updateUnMatchingLMSTrxStatus(body: any[]) {
    this.loaderService.onLoading();
    this.disbursalService.updateUnMatchingLMSTrxStatus(body).subscribe(
      (data) => {
        this.toastService.addSingle('info', '', 'Transaction is updated.');
        this.loaderService.offLoading();
      },
      (error) => {
        this.toastService.addSingle('error', '', 'Server Error.');
        this.loaderService.offLoading();
      }
    );
    //refresh Data
    this._startLMS = 1;
    this._unMatchLMSTrnxList = [];
    this.fetchPartnerCommonInfo();
    this.fetchUnMatchingTrxForLMS();
  }

  updateBankTrxStatus(item: any) {
    this._unMatchBankTrnxList.forEach((unMatchtrx) => {
      if (unMatchtrx.selected) {
        unMatchtrx.statusCode = item.statusCode;
      }
    });
  }

  updateLMSTrxStatus(item: any) {
    this._unMatchLMSTrnxList.forEach((unMatchtrx) => {
      if (unMatchtrx.selected) {
        unMatchtrx.statusCode = item.statusCode;
      }
    });
  }

  buildDataBody(trxList: any[]) {
    let bodyList: any[] = [];
    trxList.forEach((trx) => {
      if (trx.selected) {
        bodyList.push({
          id: trx.id,
          refNo: trx.refNo,
          statusCode: trx.statusCode,
          remarkNote: trx.remarkNote,
        });
      }
    });

    return bodyList;
  }

  updateBankRemarkNoteValue(item: any, event: any) {
    this._unMatchBankTrnxList.forEach((trx) => {
      if (trx.id === item.id) {
        trx.remarkNote = event.target.value;
      } else if (trx.selected) {
        trx.remarkNote = event.target.value;
      }
    });
  }

  updateLMSRemarkNoteValue(item: any, event: any) {
    this._unMatchLMSTrnxList.forEach((trx) => {
      if (trx.id === item.id) {
        trx.remarkNote = event.target.value;
      } else if (trx.selected) {
        trx.remarkNote = event.target.value;
      }
    });
  }

  bankStatusChange(selectedItem: any) {
    let body: any[] = [];
    selectedItem.selected = true;
    this.updateBankTrxStatus(selectedItem);

    body = this.buildDataBody(this._unMatchBankTrnxList);
    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        statusCode: selectedItem.statusCode,
      });
    }
    this.updateUnMatchingTrxStatus(body);
  }

  lmsStatusChange(selectedItem: any) {
    let body: any[] = [];

    selectedItem.selected = true;
    this.updateLMSTrxStatus(selectedItem);
    body = this.buildDataBody(this._unMatchLMSTrnxList);
    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        statusCode: selectedItem.statusCode,
      });
    }
    this.updateUnMatchingLMSTrxStatus(body);
  }

  bankRemarkNoteChange(selectedItem: any, event: any) {
    let body: any[] = [];
    this.updateBankRemarkNoteValue(selectedItem, event);
    body = this.buildDataBody(this._unMatchBankTrnxList);
    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        statusCode: selectedItem.statusCode,
        remarkNote: event.target.value,
      });
    }

    this.updateUnMatchingTrxStatus(body);
  }

  lmsRemarkNoteChange(selectedItem: any, event: any) {
    let body: any[] = [];
    this.updateLMSRemarkNoteValue(selectedItem, event);
    body = this.buildDataBody(this._unMatchLMSTrnxList);
    if (body.length == 0) {
      body.push({
        id: selectedItem.id,
        statusCode: selectedItem.statusCode,
        remarkNote: event.target.value,
      });
    }
    this.updateUnMatchingLMSTrxStatus(body);
  }

  selectBankTransaction(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this._unMatchBankTrnxList[i].selected = true;
        }
      }
      else {
        this._unMatchBankTrnxList.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._unMatchBankTrnxList.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  selectLMSTransaction(item: any, event: any, i: any) {
    if (event.target.checked) {
      if(event.shiftKey){
        this.endIndex = i;
        if(this.startIndex > this.endIndex){
          [this.startIndex, this.endIndex] = [this.endIndex, this.startIndex]
        }
        for(let i = this.startIndex; i <= this.endIndex; i++){
          this._unMatchLMSTrnxList[i].selected = true;
        }
      }
      else {
        this._unMatchLMSTrnxList.forEach((trx) => {
          if (trx.id === item.id) {
            trx.selected = true;
          }
        });
      }
      this.startIndex = i;
    } else {
      this._unMatchLMSTrnxList.forEach((trx) => {
        if (trx.id === item.id) {
          trx.selected = false;
        }
      });
    }
  }

  validateUpdateTrxList(bankTrxList: TransactionUpdate[], lmsTrxList: TransactionUpdate[]) {
    let flag = false;

    let trxList = bankTrxList.concat(lmsTrxList);
    let initStatus = trxList[0].statusCode;

    if(initStatus == 1 || initStatus == 6 || initStatus == 8) {
      flag = true;
    }

    for(let i = 1; i < trxList.length; i++){
      if(trxList[i].statusCode != initStatus){
        flag = false;
        break;
      }
    }

    return flag;
  }

  updateMatchingTransaction(trxUpdateList: any[]){
    this.loaderService.onLoading();
    this.disbursalService.updateMatchingTrxStatus('false', trxUpdateList).subscribe(
      (data) => {
        this.toastService.addSingle(
          'info',
          '',
          'Transactions is updated.'
        );
        this._startBank = 1;
        this._startLMS = 1;
        this._unMatchBankTrnxList = [];
        this._unMatchLMSTrnxList = [];
        this.fetchPartnerCommonInfo();
        this.fetchUnMatchingTrxForBank();
        this.fetchUnMatchingTrxForLMS();
        this.loaderService.offLoading();
        this.hideDialog();
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          '',
          'Server Error.'
        );
        this.loaderService.offLoading();
      }
    );
  }

  updateTrxList() {

    let trxUpdate = new MatchingTransactionUpdate();
    let trxUpdateList = [];

    for(let i = 0; i < this.bankTrxUpdateList.length; i++){
      for(let j = 0; j < this.lmsTrxUpdateList.length; j++){
        trxUpdate.bankStatemenTrxInfo.id = this.bankTrxUpdateList[i].id;
        trxUpdate.bankStatemenTrxInfo.statusCode = this.bankTrxUpdateList[i].statusCode;
        trxUpdate.bankStatemenTrxInfo.remarkNote = this.bankTrxUpdateList[i].remarkNote;
        trxUpdate.lmsTrxInfo.id = this.lmsTrxUpdateList[j].id;
        trxUpdate.lmsTrxInfo.statusCode = this.lmsTrxUpdateList[j].statusCode;
        trxUpdate.lmsTrxInfo.remarkNote = this.lmsTrxUpdateList[j].remarkNote;
        trxUpdateList.push(trxUpdate);
      }
    }

    if (!this.validateUpdateTrxList(this.bankTrxUpdateList, this.lmsTrxUpdateList)) {
      this.toastService.addSingle('warn', '', 'Transaction status must be similar.');
    } else {
      this.confirmUpdateTrx(trxUpdateList);
    }
  }

  confirmUpdateTrx(trxUpdateList: any) {
    this.confirmationService.confirm({
      message: 'Are you sure to update Matching Transaction?',
      header: 'Confirmation Update',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.updateMatchingTransaction(trxUpdateList);
      },
      reject: () => {
      },
    });
  }

  checkBankAll(event: any) {
    if (event.target.checked) {
      this.isBankCheckAll = true;
      this._unMatchBankTrnxList.forEach((trx) => (trx.selected = true));
    } else {
      this.isBankCheckAll = false;
      this._unMatchBankTrnxList.forEach((trx) => (trx.selected = false));
    }
  }

  checkLMSAll(event: any) {
    if (event.target.checked) {
      this.isLMSCheckAll = true;
      this._unMatchLMSTrnxList.forEach((trx) => (trx.selected = true));
    } else {
      this.isLMSCheckAll = false;
      this._unMatchLMSTrnxList.forEach((trx) => (trx.selected = false));
    }
  }

  hideDialog(){
    this._showDialog = false;
  }

  changeToMatchedStatus(trxList: TransactionUpdate[]){
    trxList.forEach((trx) => {
      trx.statusCode = 1;
    })
  }

  showDialog(){
    this.bankTrxUpdateList = [];
    this.lmsTrxUpdateList = [];
    this.bankTrxUpdateList = this.buildDataBody(this._unMatchBankTrnxList);
    this.lmsTrxUpdateList = this.buildDataBody(this._unMatchLMSTrnxList);
    this.changeToMatchedStatus(this.bankTrxUpdateList);
    this.changeToMatchedStatus(this.lmsTrxUpdateList);

    if (this.bankTrxUpdateList.length === 0) {
      this.toastService.addSingle(
        'error',
        '',
        'Bank Transaction needs to select also.'
      );
    } else if (this.lmsTrxUpdateList.length === 0) {
      this.toastService.addSingle(
        'error',
        '',
        'LMS Transaction needs to select also.'
      );
    }
    else {
      this._showDialog = true;
    }

  }

  filterBankTrx(){
    this._startBank = 1;
    this._unMatchBankTrnxList = [];
    this.fetchUnMatchingTrxForBank();
  }

  filterLMSTrx(){
    this._startLMS = 1;
    this._unMatchLMSTrnxList = [];
    this.fetchUnMatchingTrxForLMS();
  }

  onScrollBank(event: any){
    if (event.target.offsetHeight + event.target.scrollTop >= event.target.scrollHeight) {
      if(this._startBank < (this._totalTrxBank/this._number)){
        this._startBank++;
        this.fetchUnMatchingTrxForBank();
      }
    }
  }

  onScrollLMS(event: any){
    if (event.target.offsetHeight + event.target.scrollTop >= event.target.scrollHeight) {
      if(this._startLMS < (this._totalTrxLMS/this._number)){
        this._startLMS++;
        this.fetchUnMatchingTrxForLMS();
      }
    }
  }

}
