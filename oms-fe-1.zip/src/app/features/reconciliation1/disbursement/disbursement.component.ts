import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app/core/services/route-state.service';

@Component({
  selector: 'app-disbursement',
  templateUrl: './disbursement.component.html',
  styleUrls: ['./disbursement.component.sass']
})
export class DisbursementComponent implements OnInit {

  constructor(private routeStateService: RouteStateService) { }

  ngOnInit(): void {
  }

  goToDisbursementReport(department: number) {
    this.routeStateService.add(
      'repaymentReport',
      '/main/reconciliation1/disbursement/report',
      department,
      false
    );
  }

  goToDisbursementMatching(department: number) {
    this.routeStateService.add(
      'repaymentReport',
      '/main/reconciliation1/disbursement/matching',
      department,
      false
    );
  }

  goToDisbursementUnmatching(department: number) {
    this.routeStateService.add(
      'repaymentReport',
      '/main/reconciliation1/disbursement/unmatching',
      department,
      false
    );
  }

}
