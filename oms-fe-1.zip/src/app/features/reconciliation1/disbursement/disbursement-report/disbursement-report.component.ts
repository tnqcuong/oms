import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ConfirmationService } from 'primeng/api';
import { BankTransaction } from 'src/app/core/models/bank-transaction.model';
import { CommonInfo } from 'src/app/core/models/common-info.model';
import { LMSTransaction } from 'src/app/core/models/lms-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { ToastService } from 'src/app/core/services/toast.service';
import * as file from 'file-saver';
import { DisbursementService } from 'src/app/features/reconciliation1/disbursement/disbursement.service'

@Component({
  selector: 'app-disbursement-report',
  templateUrl: './disbursement-report.component.html',
  styleUrls: ['./disbursement-report.component.sass']
})
export class DisbursementReportComponent implements OnInit {

  constructor(
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private disbursementService: DisbursementService
  ) {}
  _arrBank: MetaData[] = [];

  //_arrBANK_STATEMENT_TRX_STATUS: MetaData[] = [];

  //_arrLMS_TRX_STATUS: MetaData[] = [];

  _arrFinancial: BankTransaction[] = [];

  _arrReDisbursed: BankTransaction[] = [];

  _arrCreditShield: BankTransaction[] = [];

  _arrPendingBanks: BankTransaction[] = [];

  _arrRevert: BankTransaction[] = [];

  _arrPendingLMS: BankTransaction[] = [];

  _arrLMSPendingTransaction: LMSTransaction[] = [];

  _arrLMSExcessMoney: LMSTransaction[] = [];

  _lookupCodeId = '';

  _page_pending_lms = 1;

  _page_pending_bank = 1;

  loading: boolean = false;

  loadingPending: boolean = false;

  loadingPendingBANKS: boolean = false;

  dateValue: Date = new Date();

  DayNow = new Date();

  // day select
  _startOf = moment(this.dateValue).startOf('month').format('DD/MM/YYYY');
  _endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');
  _DayNow = moment(this.DayNow).format('DD/MM/YYYY');
  isDay = false;
  isEnd = false;

  GET_Matching: any;
  page_Matching = 1;
  count_Matching = 0;
  tableSize_Matching = 20;

  // Pending Bank
  page_PendingBank = 1;
  count_PendingBank = 0;
  tableSize_PendingBank = 20;

  // Pending LMS
  page_PendingLMS = 1;
  count_PendingLMS = 0;
  tableSize_PendingLMS = 20;

  total_page: string[] = [];

  total_page_banks: string[] = [];

  //partner common info
  partnerCommonInfo: CommonInfo = new CommonInfo();

  ngOnInit(): void {
    this._arrBank = this.commonUtilityService.bankDisbList;
    //this._arrBANK_STATEMENT_TRX_STATUS = this.commonUtilityService.disbBankTrxStatusList;
    //this._arrLMS_TRX_STATUS = this.commonUtilityService.disbLmsTrxStatusList;
  }
  onChangePagePedingLMS(page: any) {
    this._page_pending_lms = page;
    this.fetchPendingLMS();
  }
  onChangePagePedingBANKS(page: any) {
    this._page_pending_bank = page;
    this.fetchPendingBank();
  }
  getDataBank() {
    this._startOf = moment(this.dateValue)
      .startOf('month')
      .format('DD/MM/YYYY');
    this._endOf = moment(this.dateValue).endOf('month').format('DD/MM/YYYY');

    let DayOf = this._endOf;

    this._endOf = this._DayNow;

    if (moment(this.dateValue).endOf('month').isBefore(moment(this.DayNow))) {
      this.isDay = true;
      this._endOf = DayOf;
    } else {
      this.isDay = false;
    }
    if (this._lookupCodeId) {
      this.fetchPartnerCommonInfo();
      // this.fetchMatching();
      // this.fetchPendingBank();
      // this.fetchPendingLMS();
    } else {
      this.toastService.addSingle('info', 'Change Bank', 'Please Change Bank');
    }
  }

  fetchMatching(): void {
    this.disbursementService
      .getMatchingTransaction(
        this._startOf,
        this._endOf,
        this._lookupCodeId,
        this.tableSize_Matching.toString(),
        this.page_Matching.toString(),
        '',
        ''
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data.result)) {
            this.GET_Matching = [];
            this.loading = false;
          } else {
            this.GET_Matching = data.result.data;
            this.loading = true;
            this.count_Matching = data.result.count;
          }
        },
        (error) => {
          this.toastService.addSingle(
            'info',
            'Error',
            'Server No Data Matching'
          );
        }
      );
  }
  fetchPendingLMS(): void {
    this.disbursementService
      .getDisbTransactionPendingLMS(
        this._startOf,
        this._endOf,
        this._lookupCodeId,
        this.tableSize_PendingLMS,
        this._page_pending_lms
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data.result)) {
            this.loadingPending = false;
            this._arrLMSPendingTransaction = [];
            this._arrLMSExcessMoney = [];
          } else {
            this._arrLMSPendingTransaction = [];
            this._arrLMSExcessMoney = [];

            this.loadingPending = true;
            // pagination
            this._arrPendingLMS = data.result.data;
            this.count_PendingLMS = data.result.count;

            const total_page =
              this.count_PendingLMS / this.tableSize_PendingLMS;
            this.total_page = [];
            for (let i = 0; i < total_page; i++) {
              const page = i + 1;
              this.total_page.push(page.toString());
            }
            // pagination
            for (let i = 0; i < data?.result?.data.length; i++) {
              if (data.result.data[i].statusCode == '10') {
                this._arrLMSExcessMoney.push(data.result.data[i]);
              } else {
                this._arrLMSPendingTransaction.push(data.result.data[i]);
              }
            }
          }
        },
        (error) => {
          this.toastService.addSingle(
            'info',
            'Error',
            'Server No Data PendingLMS'
          );
        }
      );
  }
  fetchPendingBank(): void {
    this.disbursementService
      .getDisbUnMatchingTransactionForBank(
        this._startOf,
        this._endOf,
        this._lookupCodeId,
        this.tableSize_PendingBank.toString(),
        this._page_pending_bank.toString(),
        '',
        '',
        ''
      )
      .subscribe(
        (data) => {
          if (this.isEmptyObject(data.result)) {
            this.loadingPendingBANKS = false;
            this._arrFinancial = [];
            this._arrReDisbursed = [];
            this._arrCreditShield = [];
            this._arrRevert = [];
            this._arrPendingBanks = [];
          } else {
            this._arrFinancial = [];
            this._arrReDisbursed = [];
            this._arrCreditShield = [];
            this._arrRevert = [];
            this._arrPendingBanks = [];
            this.loadingPendingBANKS = true;
            this.count_PendingBank = data.result.count;
            const total_page_banks =
              this.count_PendingBank / this.tableSize_PendingBank;

            this.total_page_banks = [];

            for (let i = 0; i < total_page_banks; i++) {
              const page = i + 1;
              this.total_page_banks.push(page.toString());
            }
            for (let i = 0; i < data?.result?.data.length; i++) {
              if (data.result.data[i].statusCode == '3') {
                this._arrRevert.push(data.result.data[i]);
              } else if (data.result.data[i].statusCode == '4') {
                this._arrCreditShield.push(data.result.data[i]);
              } else if (data.result.data[i].statusCode == '5') {
                this._arrFinancial.push(data.result.data[i]);
              } else if (data.result.data[i].statusCode == '7') {
                this._arrReDisbursed.push(data.result.data[i]);
              } else {
                this._arrPendingBanks.push(data.result.data[i]);
              }
            }
          }
        },
        (error) => {
          this.toastService.addSingle(
            'info',
            'Error',
            'Server No Data PendingBank'
          );
        }
      );
  }
  fetchPartnerCommonInfo(): void {
    this.disbursementService
      .getPartnerCommonInfo(this._startOf, this._endOf, this._lookupCodeId)
      .subscribe(
        (data) => {
          if (this.commonUtilityService.isEmptyObj(data.result)) {
            this.partnerCommonInfo  = new CommonInfo();
          } else {
            this.partnerCommonInfo  = data.result;
          }
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'No Partner Common Info.'
          );
        }
      );
  }

  onPageChangeTable(event: any) {
    this.page_Matching = event;
    this.fetchMatching();
  }

  // utily
  isEmptyObject(obj: any) {
    return JSON.stringify(obj) === '{}';
  }

  confirm1() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Excel',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (this._lookupCodeId) {
          this.ExpportExcel();
          this.fetchPartnerCommonInfo();
          this.toastService.addSingle(
            'success',
            'Confirmed',
            'You have accepted'
          );
        } else {
          this.toastService.addSingle(
            'info',
            'Change Bank',
            'Please Change Bank'
          );
        }
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  ExpportExcel() {
    this.download();
  }
  confirm2() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation Re-try',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.toastService.addSingle(
          'success',
          'Confirmed',
          'You have accepted'
        );
        this.ReTry();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  ReTry() {
    if (this._lookupCodeId) {
      this.disbursementService.PostRetryBank(this._lookupCodeId).subscribe(
        (data) => {
          this.toastService.addSingle('success', 'Re-try', data?.result);
          this.fetchPartnerCommonInfo();
          // this.fetchPendingLMS();
          // this.fetchMatching();
          // this.fetchPendingBank();
        },
        (error) => {;
          this.toastService.addSingle('error', 'Re-try', error?.error?.exceptionMessage);
        }
      );
    }
    else
    {
      this.toastService.addSingle('info', 'Change Bank', 'Please Change Bank');
    }
  }
  download() {
    this.disbursementService
      .downloadFile(this._startOf, this._endOf, this._lookupCodeId)
      .subscribe(
        (response) => {
          this.downloadFile(response.body);
        },
        (error) => {
          console.log(error);
        }
      );
  }

  downloadFile(data: any) {
    // const buftype = 'application/vnd.ms-excel;charset=utf-8';
    // const blob = new Blob([data], { type: buftype });
    // const url = window.URL.createObjectURL(blob);
    // window.open(url);
    const fileName = this.partnerCommonInfo.headerData.bankName || 'Export';
    // import('file-saver').then((FileSaver) => {
    //   let EXCEL_TYPE = 'application/vnd.ms-excel;charset=utf-8';
    //   const blob = new Blob([data], { type: EXCEL_TYPE });
    //   FileSaver.saveAs(blob, fileName + '_' + this._DayNow);
    // });
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8';
    const blob = new Blob([data], { type: EXCEL_TYPE });
    file.saveAs(blob, fileName + '_' + this._DayNow);
  }

  log(val: any) {
    console.log(val);
  }

}
