import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { CommonInfo } from 'src/app/core/models/common-info.model';
import { MatchingTransactionUpdate } from 'src/app/core/models/matching-transaction-update.model';
import { MatchingTransaction } from 'src/app/core/models/matching-transaction.model';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { SearchType } from 'src/app/core/models/searchType.model';
import { CommonUtilityService } from 'src/app/core/services/common-utility.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { DisbursementService } from 'src/app/features/reconciliation1/disbursement/disbursement.service';

@Component({
  selector: 'app-disbursement-matching',
  templateUrl: './disbursement-matching.component.html',
  styleUrls: ['./disbursement-matching.component.sass']
})
export class DisbursementMatchingComponent implements OnInit {

  _endDt = new Date();
  _startDt = new Date(this._endDt.getFullYear(), this._endDt.getMonth(), 1);

  _number: number = 20;
  _start: number = 1;
  _totalTrx: number = 0;

  _bankList: MetaData[] = [];
  _bankTrxStatusList: MetaData[] = [];
  _lmsTrxStatusList: MetaData[] = [];
  _searchTypeList: SearchType[] = [];
  selectedBank: string = '';
  selectedSearchType: string = '_loanNo';
  searchingValue: string = '';


  //partner common info
  partnerCommonInfo = new CommonInfo();

  _reconTrnxList: MatchingTransaction[] = [];
  loading:boolean = false;

  show: boolean = false;
  _showDialog:boolean=false;

  _reconUpdateTrxList: MatchingTransactionUpdate[] = [];

  constructor(
    private toastService: ToastService,
    private commonUtilityService: CommonUtilityService,
    private loaderService: LoaderService,
    private disbursementService: DisbursementService
  ) {
    this._bankList = commonUtilityService.bankDisbList;
    this._searchTypeList = commonUtilityService.disbMatchingSearchType;
    this._bankTrxStatusList = commonUtilityService.disbBankTrxStatusList;
    this._lmsTrxStatusList = commonUtilityService.disbLmsTrxStatusList;
  }

  ngOnInit(): void {}

  fetchPartnerCommonInfo() {
    this.loaderService.onLoading();
    this.disbursementService
    .getPartnerCommonInfo(moment(this._startDt).format('DD/MM/YYYY'), moment(this._endDt).format('DD/MM/YYYY'), this.selectedBank)
      .subscribe(
        (data) => {
          if(this.commonUtilityService.isEmptyObj(data.result)){
            this.partnerCommonInfo = new CommonInfo();
          }
          else{
            this.partnerCommonInfo = data.result
          }
          this.loaderService.offLoading();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'error',
            'Error',
            'Server Error.'
          );
        }
      );
  }

  fetchMatchingTransaction(){
    this.loaderService.onLoading();
    this.disbursementService
    .getMatchingTransaction(
      moment(this._startDt).format('DD/MM/YYYY'),
      moment(this._endDt).format('DD/MM/YYYY'),
      this.selectedBank,
      this._number.toString(),
      this._start.toString(),
      this.selectedSearchType,
      this.searchingValue
    )
    .subscribe(
      (data) => {
        if(this.commonUtilityService.isEmptyObj(data.result)){
          this._reconTrnxList = [];
          this._totalTrx = 0;
          this.loading = false;
          this.toastService.addSingle(
            'info',
            '',
            data.exceptionMessage
          );
        }
        else{
          this._reconTrnxList = data.result.data;
          this._totalTrx = data.result.count;

          this.loading = true;
        }
        this.fetchPartnerCommonInfo();
        this.loaderService.offLoading();
      },
      (error) => {
        this.loaderService.offLoading();
        this.toastService.addSingle(
          'error',
          '',
          'Server Error'
        );
      }
    );
  }

  searchTransaction() {
    if (this.selectedBank === '') {
      this.toastService.addSingle('warn', '', 'Please select partner');
    } else {
      this._start = 1;
      this.fetchMatchingTransaction()
    }
  }

  getMatchingTransactionByBank() {
    this._start = 1;
    if (this.selectedBank === '') {
      this.toastService.addSingle('warn', '', 'Please select partner');
    } else {
      this.fetchMatchingTransaction();
    }
  }

  fetchPosts(): void {
    this.fetchMatchingTransaction();
  }

  onTableDataChange(event: any) {
    this._start = event;
    this.fetchPosts();
  }

  onTableSizeChange(event: any): void {
    this._totalTrx = event.target.value;
    this._start = 1;
    this.fetchPosts();
  }

  deploymentName = '';

  hideDialog(){
    this._showDialog = false;
  }
  updateTransaction(){
    if(this.validateStatus(this._reconUpdateTrxList)){
      this.toastService.addSingle(
        'warn',
        '',
        'Status cannot be Matched.'
      );
    }
    else{
      this.loaderService.onLoading();
      this.disbursementService.updateMatchingTrxStatus('true', this._reconUpdateTrxList).subscribe(
        (data) => {
          this.toastService.addSingle(
            'info',
            '',
            'Transactions is updated.'
          );
          this.loaderService.offLoading();
          this._showDialog = false;
          this.fetchMatchingTransaction();
        },
        (error) => {
          this.loaderService.offLoading();
          this.toastService.addSingle(
            'error',
            '',
            'Server Error.'
          );
        }
      );
    }

  }

  validateStatus(trxList:MatchingTransactionUpdate[]){
    console.log(trxList);
    for(let i = 0; i < trxList.length; i++){
      //Check if status === matching
      if(trxList[i].bankStatemenTrxInfo.statusCode.toString() === '1'
      || trxList[i].lmsTrxInfo.statusCode.toString() === '1'){
        return true;
      }
    }
    return false;
  }

  showDialog(ref:any){
    this._reconUpdateTrxList = [];
    let _reconUpdateTrx: MatchingTransactionUpdate = new MatchingTransactionUpdate();
    for(let i = 0; i < this._reconTrnxList.length; i++){
      if(this._reconTrnxList[i].bankStatemenTrxInfo.refNo === ref){
        _reconUpdateTrx.bankStatemenTrxInfo.id = this._reconTrnxList[i].bankStatemenTrxInfo.id;
        _reconUpdateTrx.bankStatemenTrxInfo.refNo = this._reconTrnxList[i].bankStatemenTrxInfo.refNo;
        _reconUpdateTrx.bankStatemenTrxInfo.statusCode = this._reconTrnxList[i].bankStatemenTrxInfo.statusCode;
        _reconUpdateTrx.bankStatemenTrxInfo.remarkNote = this._reconTrnxList[i].bankStatemenTrxInfo.remarkNote;
        _reconUpdateTrx.lmsTrxInfo.id = this._reconTrnxList[i].lmsTrxInfo.id;
        _reconUpdateTrx.lmsTrxInfo.refNo = this._reconTrnxList[i].lmsTrxInfo.refNo;
        _reconUpdateTrx.lmsTrxInfo.statusCode = this._reconTrnxList[i].lmsTrxInfo.statusCode;
        _reconUpdateTrx.lmsTrxInfo.remarkNote = this._reconTrnxList[i].lmsTrxInfo.remarkNote;
      }
    }
    this._reconUpdateTrxList.push(_reconUpdateTrx);
    this._showDialog = true;
  }
}
