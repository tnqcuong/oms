import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DisbursementRoutingModule } from './disbursement-routing.module';
import { DisbursementComponent } from './disbursement.component';
import { DisbursementReportComponent } from './disbursement-report/disbursement-report.component';
import { DisbursementMatchingComponent } from './disbursement-matching/disbursement-matching.component';
import { DisbursementUnmatchingComponent } from './disbursement-unmatching/disbursement-unmatching.component';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';


@NgModule({
  declarations: [DisbursementComponent, DisbursementReportComponent, DisbursementMatchingComponent, DisbursementUnmatchingComponent],
  imports: [
    CommonModule,
    DisbursementRoutingModule,
    AppCommonModule,
    NgxPaginationModule,
  ]
})
export class DisbursementModule { }
