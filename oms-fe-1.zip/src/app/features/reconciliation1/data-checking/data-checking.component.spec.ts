import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataCheckingComponent } from './data-checking.component';

describe('DataCheckingComponent', () => {
  let component: DataCheckingComponent;
  let fixture: ComponentFixture<DataCheckingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DataCheckingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DataCheckingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
