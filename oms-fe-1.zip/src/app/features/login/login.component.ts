import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Validators, FormControl, FormGroup } from '@angular/forms';
import { UserDataService } from 'src/app/core/services/user-data.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { SessionService } from 'src/app/core/services/session.service';
import { UserContextService } from 'src/app/core/services/user-context.service';
import { environment } from 'src/environments/environment';
import { User } from 'src/app/core/models/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass'],
  providers: [MessageService],
})
export class LoginComponent implements OnInit {
  locale: string = '';

  version: string = '';

  msgs: any[] = [];
  loginForm: FormGroup;

  showPassword: boolean = false;

  constructor(
    private userService: UserDataService,
    private toastService: ToastService,
    private routeStateService: RouteStateService,
    private userContextService: UserContextService,
    private sessionService: SessionService
  ) {
    this.loginForm = new FormGroup({
      userName: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
    });
  }

  ngOnInit(): void {
    this.version = environment.version;
  }
  onClickLogin() {
    const user: User = {
      userId: 0,
      userName: this.loginForm.value.userName,
      password: '',
      birthDate: new Date(),
      token: '',
      emailId: '',
    };
    this.userService
      .getUserByUserNameAndPassword(
        this.loginForm.value.userName,
        this.loginForm.value.password
      )
      .subscribe(
        (data) => {
          (user.token = data.result.token),
            (user.userName = this.loginForm.value.userName);
          this.userContextService.setUser(user);
          this.routeStateService.add(
            'Dashboard',
            '/main/dashboard',
            null,
            true
          );
          return;
        },
        (error) => {
          this.toastService.addSingle(
            'error',
            '',
            error.error.exceptionMessage? error.error.exceptionMessage : 'Error Server'
          );
          // console.log(error.error.exceptionMessage);
          return;
        }
      );

    // if (this.sessionService.getItem('token')) {
    //   this.userContextService.setUser(user);
    //   this.routeStateService.add('Dashboard', '/main/dashboard', null, true);
    //   return;
    // }
    // this.toastService.addSingle('error', '', 'Invalid user.');
    // return;
  }
  toggleEys() {
    this.showPassword = !this.showPassword;
  }
}
