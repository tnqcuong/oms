import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutoDebitResistrantionComponent } from './auto-debit-resistrantion.component';

const routes: Routes = [
  {
    path: '',
    component: AutoDebitResistrantionComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AutoDeBitRegistrantionRoutingModule {}
