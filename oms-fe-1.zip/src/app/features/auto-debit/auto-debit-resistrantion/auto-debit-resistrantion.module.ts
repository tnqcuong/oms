import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoDebitResistrantionComponent } from './auto-debit-resistrantion.component';
import { AutoDeBitRegistrantionRoutingModule } from './auto-debit-resistrantion.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    AutoDeBitRegistrantionRoutingModule,
    AppCommonModule,
    NgxPaginationModule,
  ],
  declarations: [AutoDebitResistrantionComponent],

})
export class AutoDebitRegistrantionModule {}
