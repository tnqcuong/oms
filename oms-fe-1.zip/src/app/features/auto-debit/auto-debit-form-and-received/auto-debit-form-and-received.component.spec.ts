import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitFormAndReceivedComponent } from './auto-debit-form-and-received.component';

describe('AutoDebitFormAndReceivedComponent', () => {
  let component: AutoDebitFormAndReceivedComponent;
  let fixture: ComponentFixture<AutoDebitFormAndReceivedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitFormAndReceivedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitFormAndReceivedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
