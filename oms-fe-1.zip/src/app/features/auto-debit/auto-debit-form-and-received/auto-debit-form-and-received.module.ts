import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoDebitFormAndReceivedComponent } from './auto-debit-form-and-received.component';
import { AutoDebitFormAndReceivedRoutingModule } from './auto-debit-form-and-received.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';
@NgModule({
  imports: [
    CommonModule,
    AutoDebitFormAndReceivedRoutingModule,
    AppCommonModule,
    NgxPaginationModule
  ],
  declarations: [AutoDebitFormAndReceivedComponent],
})
export class AutoDebitFormAndReceivedModule {}
