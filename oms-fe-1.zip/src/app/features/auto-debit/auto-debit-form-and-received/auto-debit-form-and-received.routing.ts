import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutoDebitFormAndReceivedComponent } from './auto-debit-form-and-received.component';

const routes: Routes = [
  {
    path: '',
    component: AutoDebitFormAndReceivedComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AutoDebitFormAndReceivedRoutingModule {}
