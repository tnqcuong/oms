import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutoDebitFormAndHardComponent } from './auto-debit-form-and-hard.component';

const routes: Routes = [
  {
    path: '',
    component: AutoDebitFormAndHardComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AutoDebitFormAndHardRoutingModule {}
