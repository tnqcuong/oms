import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitReportComponent } from './auto-debit-report.component';

describe('AutoDebitReportComponent', () => {
  let component: AutoDebitReportComponent;
  let fixture: ComponentFixture<AutoDebitReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoDebitReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
