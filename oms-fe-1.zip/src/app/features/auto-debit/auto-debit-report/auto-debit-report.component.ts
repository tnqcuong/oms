import { Component, OnInit } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { MetaData } from 'src/app/core/models/meta-data.model';
import { AutoDeBitService } from 'src/app/features/auto-debit/auto-debit.service';
import * as moment from 'moment';
import { ExcelService } from 'src/app/core/services/excel.service';
import { LoaderService } from 'src/app/core/services/loader.service';
@Component({
  selector: 'app-auto-debit-report',
  templateUrl: './auto-debit-report.component.html',
  styleUrls: ['./auto-debit-report.component.sass'],
  providers: [ConfirmationService],
})
export class AutoDebitReportComponent implements OnInit {
  constructor(
    private confirmationService: ConfirmationService,
    private toastService: ToastService,
    private AutoDeBitService: AutoDeBitService,
    private exclesev: ExcelService,
    private loaderService: LoaderService
  ) {}
  _ArrEXPORT_AD_REPORT_NAME: MetaData[] = [];

  _lookupCodeId = '';

  DayNow = new Date();

  _endDt = new Date(moment(this.DayNow).endOf('month').format('MM/DD/YYYY'));
  _startDt = new Date(
    moment(this.DayNow).startOf('month').format('MM/DD/YYYY')
  );

  ngOnInit(): void {
    this.loaderService.onLoading();
    this.AutoDeBitService.GetMetaData().subscribe(
      (data) => {
        for (let i = 0; i < data.result.data.length; i++) {
          if (data.result.data[i]?.lookupCode === 'EXPORT_AD_REPORT_NAME') {
            this._ArrEXPORT_AD_REPORT_NAME.push(data.result.data[i]);
          }
        }
        this.loaderService.offLoading();
      },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Type Export',
          error.error.exceptionMessage
            ? error.error.exceptionMessage
            : 'Disconnect Server'
        );
        this.loaderService.offLoading();
      }
    );
  }
  confirm2() {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.Export();
      },
      reject: () => {
        this.toastService.addSingle('info', 'Rejected', 'You have rejected');
      },
    });
  }
  Export() {
    this.loaderService.onLoading();
    if (this._lookupCodeId) {
      this.AutoDeBitService.downloadFileAPI_Report(
        this._lookupCodeId,
        moment(this._startDt).format('DD/MM/YYYY'),
        moment(this._endDt).format('DD/MM/YYYY')
      ).subscribe(
        (data) => {
          // export api file
          this.exclesev.exportToFileExcleFromAPI(
            this._lookupCodeId,
            data?.body,
            moment(this.DayNow).format('DD/MM/YYYY')
          );
          this.toastService.addSingle(
            'success',
            'Export',
            'Success Export File'
          );
          this.loaderService.offLoading();
        },
        (error) => {
          var byteArray = new Uint8Array(error.error);
          let base64String = btoa(
            String.fromCharCode(...new Uint8Array(byteArray))
          );
          var actual = JSON.parse(atob(base64String));

          this.toastService.addSingle(
            'error',
            'Export',
            actual.exceptionMessage
              ? actual.exceptionMessage
              : 'Error Export File'
          );
          this.loaderService.offLoading();
        }
      );
    } else {
      this.toastService.addSingle('info', 'Change Export', 'Change Export');
      this.loaderService.offLoading();
    }
  }
}
