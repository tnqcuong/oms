import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoDebitSmsSendingListComponent } from './auto-debit-sms-sending-list.component';
import { AutoDeBitSmsRoutingModule } from './auto-debit-sms-sending-listrouting';
import { AppCommonModule } from 'src/app/app.common.module';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    AutoDeBitSmsRoutingModule,
    AppCommonModule,
    NgxPaginationModule,
  ],
  declarations: [AutoDebitSmsSendingListComponent],

})
export class AutoDebitSmsModule {}
