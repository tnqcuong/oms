import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutoDebitSmsSendingListComponent } from './auto-debit-sms-sending-list.component';

const routes: Routes = [
  {
    path: '',
    component: AutoDebitSmsSendingListComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AutoDeBitSmsRoutingModule {}
