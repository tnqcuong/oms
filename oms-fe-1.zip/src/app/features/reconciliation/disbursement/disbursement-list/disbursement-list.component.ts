import { Component, OnInit } from '@angular/core';
import { RouteStateService } from 'src/app//core/services/route-state.service';

@Component({
  selector: 'app-disbursement-list',
  templateUrl: './disbursement-list.component.html',
  styleUrls: ['./disbursement-list.component.sass'],
})
export class DisbursementListComponent implements OnInit {
  constructor(private routeStateService: RouteStateService) {}

  ngOnInit(): void {}
  goToDepartmentALL(department: number) {
    this.routeStateService.add(
      'All',
      '/main/reconciliation/list/disbursement/all',
      department,
      false
    );
  }
  goToDepartmentMatching(department: number) {
    this.routeStateService.add(
      'Matching',
      '/main/reconciliation/list/disbursement/matching',
      department,
      false
    );
  }
  goToDepartmentUnMatching(department: number) {
    this.routeStateService.add(
      'UnMatching',
      '/main/reconciliation/list/disbursement/unMatching',
      department,
      false
    );
  }
}
