import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisbursementAllComponent } from './disbursement-all.component';

describe('DisbursementAllComponent', () => {
  let component: DisbursementAllComponent;
  let fixture: ComponentFixture<DisbursementAllComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisbursementAllComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisbursementAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
