import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisbursementAllComponent } from './disbursement-all.component';

const routes: Routes = [
  {
    path: '',
    component: DisbursementAllComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DisbursementAllRoutingModule {}
