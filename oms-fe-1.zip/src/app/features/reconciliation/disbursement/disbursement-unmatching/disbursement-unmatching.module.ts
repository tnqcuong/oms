import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisbursementUnMatchingComponent } from './disbursement-unmatching.component';
import { DisbursementUnMatchingRoutingModule } from './disbursement-unmatching.routing';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    DisbursementUnMatchingRoutingModule,
    AppCommonModule,
    HeaderBreadCrumbModule,
    NgxPaginationModule
  ],
  declarations: [DisbursementUnMatchingComponent],
})
export class DisbursementUnMatchingModule {}
