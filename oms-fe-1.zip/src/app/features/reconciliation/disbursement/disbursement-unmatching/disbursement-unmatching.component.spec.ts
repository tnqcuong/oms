import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisbursementUnMatchingComponent } from './disbursement-unmatching.component';

describe('DisbursementUnMatchingComponent', () => {
  let component: DisbursementUnMatchingComponent;
  let fixture: ComponentFixture<DisbursementUnMatchingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisbursementUnMatchingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisbursementUnMatchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
