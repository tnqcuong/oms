import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisbursementUnMatchingComponent } from './disbursement-unmatching.component';

const routes: Routes = [
  {
    path: '',
    component: DisbursementUnMatchingComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DisbursementUnMatchingRoutingModule {}
