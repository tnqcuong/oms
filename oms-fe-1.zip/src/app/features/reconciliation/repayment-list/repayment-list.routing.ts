import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RepaymentListComponent } from 'src/app/features/reconciliation/repayment-list/repayment-list.component';

const routes: Routes = [
  {
    path: '',
    component: RepaymentListComponent,
  },
  {
    path: 'bank',
    loadChildren: () =>
      import(
        'src/app/features/reconciliation/repayment-list/repayment-bank/repayment-bank.module'
      ).then((m) => m.RepaymentBankModule)
  },
  {
    path: 'matching',
    loadChildren: () =>
      import(
        'src/app/features/reconciliation/repayment-list/repayment-matching/repayment-matching.module'
      ).then((m) => m.RepaymentMatchingModule),
  },
  {
    path: 'unMatching',
    loadChildren: () =>
      import(
        'src/app/features/reconciliation/repayment-list/repayment-unmatching/repayment-unmatching.module'
      ).then((m) => m.RepaymentUnMatchingModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RepaymentListRoutingModule {}
