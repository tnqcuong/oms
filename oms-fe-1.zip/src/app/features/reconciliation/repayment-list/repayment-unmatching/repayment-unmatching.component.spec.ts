import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RepaymentUnMatchingComponent } from './repayment-unmatching.component';


describe('RepaymentUnMatchingComponent', () => {
  let component: RepaymentUnMatchingComponent;
  let fixture: ComponentFixture<RepaymentUnMatchingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepaymentUnMatchingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepaymentUnMatchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
