import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RepaymentUnMatchingComponent } from './repayment-unmatching.component';

const routes: Routes = [
  {
    path: '',
    component: RepaymentUnMatchingComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RepaymentUnMatchingRoutingModule {}
