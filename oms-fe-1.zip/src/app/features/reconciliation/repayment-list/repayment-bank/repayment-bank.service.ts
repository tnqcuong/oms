import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { environmentAPI } from 'src/environments/environmentAPI';
import { SessionService } from 'src/app/core/services/session.service';

@Injectable({
  providedIn: 'root',
})
export class RepaymentBankService {
  constructor(
    private http: HttpClient,
    private sessionService: SessionService
  ) {}

  getTransactionMatching(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);
    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl + environmentAPI.repaymentMatchingTrx,
      {
        headers: headers,
        params: params,
      }
    );
  }
  getTransactionPendingBank(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl + environmentAPI.repaymentUnMatchingTrx,
      {
        headers: headers,
        params: params,
      }
    );
  }
  getTransactionPendingLMS(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any,
    params_number: any,
    params_start: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    params = params.set('_number', params_number);
    params = params.set('_start', params_start);

    return this.http.get(
      environment.apiUrl + environmentAPI.unMatchingLMSTrx,
      {
        headers: headers,
        params: params,
      }
    );
  }

  getPartnerCommonInfo(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    return this.http.get(environment.apiUrl + environmentAPI.partnerCommonInfo, {
      headers: headers,
      params: params,
    });
  }
  PostRetryBank(params_bankCode: any): Observable<any> {
    var data = this.sessionService.getItem('currentUser');

    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI.reTry,
      {},
      {
        headers: headers,
        params: params,
      }
    );
  }

  downloadFile(
    params_startDt: any,
    params_endDt: any,
    params_bankCode: any
  ): Observable<any> {
    var data = this.sessionService.getItem('currentUser');
    let headers = new HttpHeaders()
      .set('Content-Type', '')
      .set('access-token', data.token)
      .set('Authorization', data.token);

    let params = new HttpParams();
    params = params.set('_startDt', params_startDt);
    params = params.set('_endDt', params_endDt);
    params = params.set('_bankCode', params_bankCode);
    return this.http.post(
      environment.apiUrl + environmentAPI.report,
      {},
      {
        params: params,
        headers: headers,
        responseType: 'arraybuffer',
        observe: 'response',
      }
    );
  }
}
