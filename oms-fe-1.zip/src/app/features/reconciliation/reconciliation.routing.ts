import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReconciliationComponent } from 'src/app/features/reconciliation/reconciliation.component';

const routes: Routes = [
  {
    path: '',
    component: ReconciliationComponent,
    loadChildren: () => import('src/app/features/reconciliation/reconciliation-list/reconciliation-list.module').then(m => m.ReconciliationListModule)
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReconciliationRoutingModule {}
