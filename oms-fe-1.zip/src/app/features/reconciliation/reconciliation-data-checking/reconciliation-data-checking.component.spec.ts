import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReconciliationDataCheckingComponent } from './reconciliation-data-checking.component';

describe('ReconciliationDataCheckingComponent', () => {
  let component: ReconciliationDataCheckingComponent;
  let fixture: ComponentFixture<ReconciliationDataCheckingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReconciliationDataCheckingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReconciliationDataCheckingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
