import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReconciliationDataCheckingComponent } from 'src/app/features/reconciliation/reconciliation-data-checking/reconciliation-data-checking.component';

const routes: Routes = [
  {
    path: '',
    component: ReconciliationDataCheckingComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReconciliationDataCheckingRoutingModule {}
