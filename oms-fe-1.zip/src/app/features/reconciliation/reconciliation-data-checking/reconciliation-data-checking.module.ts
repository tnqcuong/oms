import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/layout/header-breadcrumb/header-breadcrumb.module';
import { ReconciliationDataCheckingComponent } from '../reconciliation-data-checking/reconciliation-data-checking.component';
import { ReconciliationDataCheckingRoutingModule } from 'src/app/features/reconciliation/reconciliation-data-checking/reconciliation-data-checking.routing';

@NgModule({
  imports: [
    CommonModule,
    AppCommonModule,
    HeaderBreadCrumbModule,
    ReconciliationDataCheckingRoutingModule,
  ],
  declarations: [ReconciliationDataCheckingComponent],
})
export class ReconciliationDataCheckingModule {}
