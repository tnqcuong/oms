import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './layout/error/error.component';
import { LayoutComponent } from './layout/layout.component';
import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';
import { ReconciliationListComponent } from './features/reconciliation1/reconciliation-list/reconciliation-list.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'login',
    loadChildren: () =>
      import('src/app/features/login/login.module').then((m) => m.LoginModule),
  },
  {
    path: 'main',
    component: LayoutComponent,
    children: [
      {
        path: 'dashboard',
        loadChildren: () =>
          import('src/app/features/dashboard/dashboard.module').then(
            (m) => m.DashboardModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 'reconciliation',
        loadChildren: () =>
          import('src/app/features/reconciliation/reconciliation.module').then(
            (m) => m.ReconciliationModule
          ),
        canActivate: [AuthGuard],
        // data: {roles: [Role.]}
      },
      {
        path: 'auto-debit',
        loadChildren: () =>
          import('src/app/features/auto-debit/auto-debit.module').then(
            (m) => m.ReconciliationListModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 'reconciliation1',
        loadChildren: () =>
          import('src/app/features/reconciliation1/reconciliation1.module').then(
            (m) => m.Reconciliation1Module
          ),
        canActivate: [AuthGuard],
      }
    ],
  },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: '**',
    redirectTo: 'error',
  },
  // {
  //   path: 'error',
  //   component: ErrorComponent,
  // },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
