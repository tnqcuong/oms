import { Component, OnInit } from '@angular/core';
import { ApplicationStateService } from 'src/app/core/services/application-state.service';
import { BankService } from '../core/services/bank.service';
import { CommonUtilityService } from '../core/services/common-utility.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.sass'],
})
export class LayoutComponent implements OnInit {
  isMenuVisible: boolean = false;

  constructor(
    private applicationStateService: ApplicationStateService,
    private commonUtilityService: CommonUtilityService,
    private BankService: BankService,
  ) {}

  ngOnInit() {
    if (this.applicationStateService.getIsMobileResolution()) {
      this.isMenuVisible = false;
    } else {
      this.isMenuVisible = true;
    }

    // if(this.commonUtilityService.bankList.length === 0){
    //   this.BankService.GetMetaDataBank().subscribe(
    //     (data) => {
    //       //clear all metadata before re add
    //       // this.commonUtilityService.bankList = [];
    //       // this.commonUtilityService.bankTrxStatusList = [];
    //       // this.commonUtilityService.lmsTrxStatusList = [];
    //       // this.commonUtilityService.uploadFileStatusList = [];

    //       for (let i = 0; i < data.result.data.length; i++) {
    //         if (data.result.data[i].lookupCode === 'BANK_CODE') {
    //           this.commonUtilityService.bankList.push(data.result.data[i]);
    //         }
    //         if (data.result.data[i].lookupCode === 'BANK_STATEMENT_TRX_STATUS') {
    //           this.commonUtilityService.bankTrxStatusList.push(
    //             data.result.data[i]
    //           );
    //         }
    //         if (data.result.data[i].lookupCode === 'NONBANK_STATEMENT_TRX_STATUS') {
    //           this.commonUtilityService.nonBankTrxStatusList.push(
    //             data.result.data[i]
    //           );
    //         }
    //         if (data.result.data[i].lookupCode === 'LMS_TRX_STATUS') {
    //           this.commonUtilityService.lmsTrxStatusList.push(
    //             data.result.data[i]
    //           );
    //         }
    //         if (data.result.data[i].lookupCode === 'NON_LMS_TRX_STATUS') {
    //           this.commonUtilityService.nonLmsTrxStatusList.push(
    //             data.result.data[i]
    //           );
    //         }
    //         if (data.result.data[i].lookupCode === 'UPLOAD_FILE_STATUS') {
    //           this.commonUtilityService.uploadFileStatusList.push(
    //             data.result.data[i]
    //           );
    //         }
    //         if (data.result.data[i].lookupCode === 'BANK_CODE_DISB') {
    //           this.commonUtilityService.bankDisbList.push(
    //             data.result.data[i]
    //           );
    //         }
    //         if (data.result.data[i].lookupCode === 'BANK_DISBURSAL_STATUS') {
    //           this.commonUtilityService.disbBankTrxStatusList.push(
    //             data.result.data[i]
    //           );
    //         }
    //         if (data.result.data[i].lookupCode === 'LMS_DISB_TRX_STATUS') {
    //           this.commonUtilityService.disbLmsTrxStatusList.push(
    //             data.result.data[i]
    //           );
    //         }
    //       }
    //     },
    //     (error) => {}
    //   );
    // }
  }
  ngOnDestroy() {}
}
